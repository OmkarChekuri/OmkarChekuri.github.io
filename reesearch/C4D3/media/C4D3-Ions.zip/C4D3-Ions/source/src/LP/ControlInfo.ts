
//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Control } from "./Control.js";

import { ControlProxy } from "./ControlProxy.js";
import {ControlListener} from "./ControlListener.js"
import { LivePropertyListener } from "./LivePropertyListener.js";
import { LiveProperty } from "./LiveProperty.js";
import { Variable } from "./Variable.js";
import { typeOfValue } from "../index.js";
//type typeOfValue = string | number | boolean | undefined | null;



	export class ControlInfo
	{
		//**********************************************************************
		// Public Class Methods
		//**********************************************************************
	
		public static bind( control:Control, tag:string,  variable:Variable):void
		{
			control.describe().getLiveProperty(tag).setVariable(variable);
		}
	
		public static 	unbind( control:Control,  tag:string):void
		{
			control.describe().getLiveProperty(tag).setVariable(null);
		}
	
		public static 	transduce( src:Control,  dst:Control,  srcTag?:string, dstTag?:string):void
		{
			
			if(src && dst && srcTag && dstTag){

				var srcProperty:LiveProperty = src.describe().getLiveProperty(srcTag);
				var variable:Variable|null = srcProperty.getVariable();
		
				if (variable == null)
					ControlInfo.unbind(dst, dstTag);
				else
					ControlInfo.bind(dst, dstTag, variable);
			}
			else if( (src && dst && srcTag)){
				ControlInfo.transduce(src, dst, srcTag, srcTag);
			}
			else if((src && dst && dstTag)){
				ControlInfo.transduce(src, dst, dstTag, dstTag);
			}
			else if(src &&  dst){
				var tags:string[] = src.describe().getTags();
				var i:number;
				for ( i=0; i<tags.length; i++){
					ControlInfo.transduce(src, dst, tags[i]);
				}
			}
			
			
			
			
			

		}
	

		
		//**********************************************************************
		// Private Members
		//**********************************************************************
	
		// State (internal) variables
		private  proxy:ControlProxy;
	
		//**********************************************************************
		// Constructors and Finalizer
		//**********************************************************************
	
		public constructor( proxy:ControlProxy)
		{
			this.proxy = proxy;
		}
	
		//**********************************************************************
		// Getters and Setters
		//**********************************************************************
	
		public getControl():Control
		{
			return this.proxy.getControl();
		}
	
		//**********************************************************************
		// Public Methods (Properties)
		//**********************************************************************
	
		/**
		 * Returns a vector of all LiveProperty tags, in the order added.
		 */
		public getTags():string[]
		{
			return this.proxy.getTags();
		}
	
		/**
		 * Returns the number of LiveProperty tags.
		 */
		public getTagCount():number
		{
			return this.proxy.getTagCount();
		}
	
		/**
		 * Returns the LiveProperty tag at the specified index.
		 */
		public 	getTagAt(index:number):string
		{
			return this.proxy.getTagAt(index);
		}
	
		/**
		 * Returns where a tag is in the vector of all tags, or -1 if absent.
		 */
		public 	getIndexOfTag(tag:string):number
		{
			return this.proxy.getIndexOfTag(tag);
		}
	
		/**
		 * Returns the LiveProperty associated with the specified tag, or null if
		 * none exists.
		 *
		 * @param		tag		the name of the LiveProperty to retrieve
		 */
		public getLiveProperty( tag:string):LiveProperty
		{
			return this.proxy.getLiveProperty(tag);
		}
	
		/**
		 * Returns a vector of all LiveProperties, in the order added.
		 */
		public 	getLiveProperties():LiveProperty[]
		{
			return this.proxy.getLiveProperties();
		}
	
		/**
		 * Returns the property at the specified index.
		 */
		public getPropertyAt(index:number):LiveProperty
		{
			return this.proxy.getPropertyAt(index);
		}
	
		/**
		 * Convenience method to register a listener with all current properties.
		 * This method does NOT automatically handle addition and removal of
		 * properties to the control. (Use ControlListener to detect such changes.)
		 */
		public addLivePropertyListener( l:LivePropertyListener):void
		{
			this.proxy.addLivePropertyListener(l);
		}
	
		/**
		 * Convenience method to deregister a listener with all current properties.
		 * This method does NOT automatically handle addition and removal of
		 * properties to the control. (Use ControlListener to detect such changes.)
		 */
		public removeLivePropertyListener( l:LivePropertyListener):void
		{
			this.proxy.removeLivePropertyListener(l);
		}
	
		//**********************************************************************
		// Public Methods (Properties, Variable Access)
		//**********************************************************************
	
		public getVariable(tag:string):Variable|null
		{
			return this.proxy.getVariable(tag);
		}
	
		public setVariable(tag:string, variable:Variable):void
		{
			this.proxy.setVariable(tag, variable);
		}
	
		public 	getName( tag:string):String
		{
			return this.proxy.getName(tag);
		}
	
		public setName(tag:string, name:string):void
		{
			this.proxy.setName(tag, name);
		}
	
		public 	getValue( tag:string):typeOfValue
		{
			return this.proxy.getValue(tag) as typeOfValue;
		}
	
		public setValue(tag:string, object:number):void
		{
			this.proxy.setValue(tag, object);
		}
	
		//**********************************************************************
		// Public Methods (Properties, Locking)
		//**********************************************************************
	
		public isLocked():boolean
		{
			return this.proxy.isLocked();
		}
	
		
		//**********************************************************************
		// Public Methods (Events)
		//**********************************************************************
	
		/**
		 * Registers the specified ControlListener to receive ControlEvents
		 * whenever a LiveProperty is added to or removed from this ControlInfo.
		 */
		public addControlListener(l:ControlListener):void
		{
			this.proxy.addControlListener(l);
		}
	
		/**
		 * Unregisters the specified ControlListener.
		 */
		public removeControlListener( l:ControlListener):void
		{
			this.proxy.removeControlListener(l);
		}
	

	}
	
	//******************************************************************************

