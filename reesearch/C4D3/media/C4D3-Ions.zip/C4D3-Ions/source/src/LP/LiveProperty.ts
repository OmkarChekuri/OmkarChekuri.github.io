//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Disposable } from "./Disposable.js";
import { Control } from "./Control.js";
import { Variable } from "./Variable.js";
import { LivePropertyEvent } from "./LivePropertyEvent.js";
import { LivePropertyListener } from "./LivePropertyListener.js";
import { VariableEvent } from "./VariableEvent.js";
import { VariableListener } from "./VariableListener.js";
import { Prototype } from "./Prototype.js";
//import { typeOfValue } from "../index.js";
import {printClass} from "./printClass.js";
type typeOfValue = string | number | boolean | undefined | null|Array<any>|any;
	export class LiveProperty implements Disposable, VariableListener
	{
		//**********************************************************************
		// Private Members
		//**********************************************************************

		// State (internal) variables
		private readonly  control: Control;
		private readonly  tag: string;
		private readonly prototype: Prototype;		// Variable type
		private readonly interactive: boolean;

		public variable: Variable|null = null;		// Active value																	// omkar note: changed this to public to access in controlslider method to overcome some error.
		private inFocus: boolean= true;
		private inEdit: boolean = true;

		//private status:boolean = printClass.printStatus; 

		// Event Multicasters
		private readonly listeners: LivePropertyListener[];

		//**********************************************************************
		// Constructors and Finalizer
		//**********************************************************************

		constructor(control: Control, tag: string, prototype: Prototype, interactive?: boolean)
		{
			//if(printClass.printStatus) console.log("I am in constructor method of LiveProperty with tag: " + tag );
			this.control = control;
			this.tag = tag;
			this.prototype = prototype;
			if(interactive != undefined){
				this.interactive = interactive;
				
			}
			else{
				this.interactive = false; 
				
			}
			
			//if(printClass.printStatus) console.log("I am in end of constructor method of LiveProperty");
			this.listeners = [];


			//if(printClass.printStatus) console.log(this.status);
		}


		//**********************************************************************
		// Getters and Setters
		//**********************************************************************

		public getControl(): Control
		{
			return this.control;
		}

		public getTag(): string
		{
			return this.tag;
		}

		public getPrototype(): Prototype
		{
			return this.prototype;
		}

		public getInteractive(): boolean
		{
			return this.interactive;
		}

		public getVariable(): Variable|null
		{
			return this.variable;
		}

		public setVariable(variable: Variable|null): void
		{
			if(printClass.printStatus) console.log("setVariable Method of LiveProperty");
			//printClass.myprint(variable); 
			if(printClass.printStatus) console.log(variable);
			if (this.variable == variable)
				return;

			
			
			if(printClass.printStatus) console.log("LiveProperty: Did i reach here on setVariable");
			if(printClass.printStatus) console.log(variable.getPrototype().value);
			if(printClass.printStatus) console.log(Object.getPrototypeOf(variable.getPrototype().value));

			//if ((variable != null) &&  !(variable.getPrototype()).isInstance(LiveProperty.prototype))
			if ((variable != null) &&  !(Object.getPrototypeOf(variable.getPrototype().value) == Object.getPrototypeOf(this.prototype.value))){
				
				throw new Error("\nType mismatch:" + "\n" + this.prototype + "\n" + variable.getPrototype());
			}

			if(printClass.printStatus) console.log("Hello");
			if (this.variable != null)
			{
				if (this.inFocus)
					this.variable.setFocusing(false, this);

				if (this.inEdit)
					this.variable.setEditing(false, this);

				this.variable.removeVariableListener(this);
			}

		
			this.variable = variable;
			
			if(printClass.printStatus) console.log(variable);
			//*********************************************************************************************
			if (this.variable != null)
			{
				variable!.addVariableListener(this);

				if (this.inFocus)
					this.variable.setFocusing(true, this);

				if (this.inEdit)
					this.variable.setEditing(true, this);
			}

			//console.log("LiveProperty: Did i reach here on setVariable");

			//this.fireEvent(new LivePropertyEvent(this, null));
			this.firePropertyChanged(new LivePropertyEvent(this,null));
		}

		//**********************************************************************
		// Public Methods
		//**********************************************************************

		public getType(): string
		{
			return this.prototype.getType;
		}

		public getName(): string
		{
			if (this.variable == null)
				return this.prototype.getName;
			else
				return this.variable.getName();
		}

		public setName(name: string): void
		{
			if (name == null)
				name = this.prototype.getName;

			if (this.variable != null)
				this.variable.setName(name);
		}

		public getValue(): typeOfValue
		{
			if (this.variable == null)
				return this.prototype.getValue();
			else
				return this.variable.getValue();
		}

		public setValue(value: any): void
		{
			//console.log(value);
			if(printClass.printStatus) console.log("setValue of LiveProperty");
			//if(printClass.printStatus) console.log(value);
			if(printClass.printStatus) console.log('SetValue in LiveProperty');
			if (value == null){
				console.log("Object is null");
				value = this.prototype.getValue();
				
			}
			
			//if(printClass.printStatus) console.log(object);	
			if (this.variable != null)
				this.variable.setValue(value);
		}

		public touch(): void
		{
			if (this.variable != null)
				this.variable.touch();
		}

		//**********************************************************************
		// Public Methods (Locking)
		//**********************************************************************

		public isLocked(): boolean
		{
			return ((this.variable == null) || this.variable.isLocked());
		}

		//**********************************************************************
		// Public Methods (Focusing)
		//**********************************************************************

		public isFocusing(): boolean
		{
			//return (inFocus || ((variable != null) && variable.isFocusing()));

			if (this.variable == null)
				return this.inFocus;
			else
				return this.variable.isFocusing();
		}

		public setFocusing(b: boolean): void
		{
			if (this.inFocus == b)
				return;

			this.inFocus = b;

			if (this.variable != null)
				this.variable.setFocusing(this.inFocus, this);
		}

		//**********************************************************************
		// Public Methods (Editing)
		//**********************************************************************

		public isEditing(): boolean
		{
			//return (inEdit || ((variable != null) && variable.isEditing()));

			if (this.variable == null)
				return this.inEdit;
			else
				return this.variable.isEditing();
		}

		public setEditing(b: boolean): void
		{
			if (this.inEdit == b)
				return;

			this.inEdit = b;

			if (this.variable != null)
				this.variable.setEditing(this.inEdit, this);
		}

		//**********************************************************************
		// Public Methods (Events)
		//**********************************************************************

		public  addLivePropertyListener(l:any):void
		{
			if(printClass.printStatus) console.log(l.toString());
			if(printClass.printStatus) console.log(l);
			this.listeners.push(l);
		}

		public  removeLivePropertyListener( l:LivePropertyListener):void
		{
			this.listeners.splice(this.listeners.indexOf(l),1);
		}

		//**********************************************************************
		// Override Methods (Disposable)
		//**********************************************************************

		public dispose():void
		{
			if (this.variable != null)
			{
				if (this.inFocus)
					this.variable.setFocusing(false, this);

				if (this.inEdit)
					this.variable.setEditing(false, this);

				this.variable.removeVariableListener(this);
				this.variable.dispose;
			}
		}

		//**********************************************************************
		// Override Methods (VariableListener)
		//**********************************************************************

		variableChanged(e:VariableEvent):void
		{

			if(printClass.printStatus) console.log(" variableChanged method of liveProperty ")
			
				this.fireEvent(new LivePropertyEvent(this, e));
		}

		//**********************************************************************
		// Private Methods (Events)
		//**********************************************************************

		private  fireEvent(e:LivePropertyEvent):void
		{
			if (Variable.STARTUP)
			{
				var ve:VariableEvent|null = e.getVariableEvent();

				if (ve != null)
					return;

				
			}

			
				this.firePropertyChanged(e);
		}

		public firePropertyChanged(e:LivePropertyEvent):void
		{

			if(printClass.printStatus) console.log("firePropertyChanged of LiveProperty")
			var n:number = this.listeners.length;
			var i:number;
			
			for ( i = 0; i < n; i++)
			{
				if(printClass.printStatus) console.log(this.listeners[i]);
			}

			if(printClass.printStatus) console.log("Number of Listeners:"+n);
			if(printClass.printStatus) console.log(e);

			//if(printClass.printStatus) console.log(this.status);
			
			for ( i = 0; i < n; i++)
			{

				if(printClass.printStatus) console.log("Listener :" +i );
				
				if(printClass.printStatus) console.log(this.listeners[i]);    //not working
				
				this.listeners[i].propertyChanged(e);
				
			}
		}

	
	}

	
