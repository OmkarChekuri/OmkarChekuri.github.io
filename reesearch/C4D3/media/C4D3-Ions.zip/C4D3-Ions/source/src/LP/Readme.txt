notes:

1. Event listener is a tagging interface i.e. An empty interface is known as tag or marker interface.
 For example Serializable, EventListener, Remote(java.rmi.Remote) are tag interfaces, there are few other 
 tag interfaces as well.These interfaces do not have any field and methods in it.

2. Disposable is a interface that lets the class know that it should be able to dispose itself. 


3.Control is an interface for objects, usually views or sliders, whose appearance and
 behavior are defined by LiveProperties. it has a method  that Returns a description of this control as a ControlInfo object.

        Control extends Disposable and LivePropertyListener

4.ControlInfo is a class that provides a immutable copy of ControlProxy object. This is a final class. 
    i.e cannot be inherited and useful for creating a immutablecopy of the class

5. ControlProxy is a proxy class . ControlProxy
	implements Disposable


    ?????????????


6.ControlListener is a interface which is useful only when a property is added or a property is removed.

        controllistener extends EventListener



7. ControlEvent is a final class that Implements Event Object

    ControlEvent extends EventObject


8.LiveProperty is a final class that implements Disposable and VariableListener


9. LivePropertyEvent is a final class that implements EventObject which is The root class from which all event
 state objects shall be derived. All Events are constructed with a reference to the object, the "source",
 that is logically deemed to be the object upon which the Event in questioninitially occurred upon.

        LivePropertyEvent implements EventObject


10. Prototype is a final class .A Prototype object contains programming language metainformation
  bout Variables, consisting of a reference type , name
  label , default value , and  constant flag .
 



 
11.LivePropertyListener is  a interface which is useful only when a property is changed.

        LivePropertyListener extends EventListener




12.VariableListener is  a interface which is useful only when a variable is changed.

        VariableListener extends EventListener


13.Variable is a final Class that implements Disposable
        
        variable implements Disposable

14. Variable Event Extends EventObject


15.  VariableListener  is an interface that extends EventListener

     VariableListener extends EventListener


16. Variant is interface that collectsvariables into an array called bank