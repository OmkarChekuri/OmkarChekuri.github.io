//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

//import { EventObject } from "./Eventing.js";
import { LiveProperty } from "./LiveProperty.js";
import { Control } from "./Control.js";

	export  class ControlEvent 
	{
		//**********************************************************************
		// Private Members
		//**********************************************************************
	
		// State (internal) variables
		private property:LiveProperty;
	
		//**********************************************************************
		// Constructors and Finalizer
		//**********************************************************************
	
		constructor( private source:Control,  property:LiveProperty)
		{
			
			
			this.property = property;
		}
	
		//**********************************************************************
		// Getters and Setters
		//**********************************************************************
	
		public 	getControl():Control
		{
			return this.source;
		}
	
		public 	getLiveProperty():LiveProperty
		{
			return this.property;
		}
	}
	
	//******************************************************************************
	

