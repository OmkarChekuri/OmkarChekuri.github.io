//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.


import { VariableEvent } from "./VariableEvent.js";
import { LiveProperty } from "./LiveProperty.js";
import { printClass } from "./printClass.js";


export class LivePropertyEvent //extends EventObject
{
	//**********************************************************************
	// Private Members
	//**********************************************************************

	// State (internal) variables
	private  e: VariableEvent|null;
	private property:LiveProperty;
	//**********************************************************************
	// Constructors and Finalizer
	//**********************************************************************
	//property:LiveProperty;
	/**
	 * Creates an event triggered by a change to the Variable bound to a
	 * LiveProperty.
	 */
	constructor(property: LiveProperty, e: VariableEvent|null)
	{
		if(printClass.printStatus) console.log("Constructor of liveProperty Event");
		
		
		//super(property)
		this.property = property;
		if (property && e)
		{
			this.e = e;
		}
		else
		{
			this.e =null;
		}



	}



	//**********************************************************************
	// Getters and Setters
	//**********************************************************************

	/**
	 * Returns the LiveProperty that generated this event.
	 */
	public getLiveProperty(): LiveProperty
	{
		return this.property;
	}

	/**
	 * Returns the VariableEvent that triggered this event, or <CODE>null</CODE>
	 * if this event was triggered by the binding of a new <CODE>Variable</CODE>
	 * to a LiveProperty.
	 */
	public getVariableEvent(): VariableEvent|null
	{
		return this.e;
	}
}

	//******************************************************************************
