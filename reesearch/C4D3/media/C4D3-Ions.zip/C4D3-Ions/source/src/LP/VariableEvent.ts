
//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Variable } from "./Variable.js";


export class VariableEvent  
{
	//**********************************************************************
	// Public Class Members
	//**********************************************************************

	public static DISPOSING: number = 0;
	public static NAME_CHANGED: number = 1;
	public static VALUE_CHANGED: number = 2;
	public static FOCUS_CHANGED: number = 3;
	public static EDIT_CHANGED: number = 4;
	public static LOCK_CHANGED: number = 5;
	public static TRACK_CHANGED: number = 6;
	public static SHARE_CHANGED: number = 7;

	public static MIN_TYPE: number = 0;
	public static MAX_TYPE: number = 7;

	//**********************************************************************
	// Private Members
	//**********************************************************************

	// State (internal) variables
	private t_type: number | undefined;
	private value: Object | undefined | null;
	private time: number | undefined;
	private variable: Variable;


	//**********************************************************************
	// Constructors and Finalizer
	//**********************************************************************



	constructor(variable: Variable, t_type: number, type?: string, value?: Object, time?: number)
	{
		//super(type);
		//super(variable)  //need to implement

		this.variable = variable;
		if (variable && type && value && time)
		{
			if ((VariableEvent.MIN_TYPE > t_type) || (t_type > VariableEvent.MAX_TYPE))
				throw new Error("Unknown type");

			this.t_type = t_type;


			if (value == undefined)
			{
				this.value = null;
			}
			else
			{
				this.value = value;
			}

			if (time = undefined)
			{
				this.time = Date.now();

			} else
			{
				this.time = time;

			}



		}

	}




	//**********************************************************************
	// Getters and Setters
	//**********************************************************************

	public getVariable()
	{
		return this.variable; 			//omkar: needs to check 
	}

	public getType()
	{
		return this.t_type;
	}

	public getValue()
	{
		return this.value
	}

	public getTime(): any
	{
		return this.time;
	}
}

	//******************************************************************************

