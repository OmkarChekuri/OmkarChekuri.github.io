
//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import {Control} from "./Control.js"
import {ControlProxy} from "./ControlProxy.js"
import {ControlInfo} from "./ControlInfo.js"
import {LivePropertyEvent} from "./LivePropertyEvent.js"



	export  abstract class AbstractControl implements Control
	{

		//**********************************************************************
		// Private Members
		//**********************************************************************

		// State (internal) variables
		protected  proxy:ControlProxy;


		
		//**********************************************************************
		// Constructors and Finalizer
		//**********************************************************************
		constructor(){
			this.proxy = new ControlProxy(this);
		}
		


		describe(): ControlInfo
		{
			throw new Error("Method not implemented.")
		}		
		
		

		//**********************************************************************
		// Override Methods (Disposable)
		//**********************************************************************

		/**
		 * Disposes of this control. This method is called to release resources used
		 * by this control, in particular its LiveProperties.
		 */
		dispose(): void
		{
			this.proxy.dispose();
		}




		//**********************************************************************
		// Override Methods (LivePropertyListener)
		//**********************************************************************


		propertyChanged(e: LivePropertyEvent): void
		{
			
		}


	}

	//******************************************************************************



