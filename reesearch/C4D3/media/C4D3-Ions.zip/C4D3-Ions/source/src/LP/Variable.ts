//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Disposable } from "./Disposable.js";
import { VariableEvent } from "./VariableEvent.js";
//import { AsyncFireEvent } from "./AsyncFireEvent";
import { Value } from "./Value";
import { SharedFlag } from "./SharedFlag.js";
import { VariableListener } from "./VariableListener.js";
import { LiveProperty } from "./LiveProperty.js";
import { Prototype } from "./Prototype.js";
//import { typeOfValue } from "../index.js";
import { printClass } from "./printClass.js";
type typeOfValue = string | number | boolean | undefined | null|Array<boolean>;

	export  class Variable implements Disposable
	{
		//**********************************************************************
		//  Class Members
		//**********************************************************************

		/**
		 * If true, notify event handlers using Runnable invoked later.
		 */
		static ASYNC_EVENTS: boolean = true;
		static STARTUP: boolean = false;

		//**********************************************************************
		//  Class Methods
		//**********************************************************************

 		static initStartup(): void
		{
			Variable.ASYNC_EVENTS = false;
			Variable.STARTUP = true;
		}

		static termStartup(): void
		{
			Variable.ASYNC_EVENTS = true;
			Variable.STARTUP = false;
		}
 
		//**********************************************************************
		// Private Members
		//**********************************************************************

		// State (internal) variables
		prototype: Prototype;
		name: string | undefined ;
		private value: typeOfValue ;

		private  fflag: SharedFlag;
		private  eflag: SharedFlag;
		private  lflag: SharedFlag;
		private  tflag: SharedFlag;
		private  sflag: SharedFlag; 

		// Event Multicasters
		public  listeners:any[];

		//**********************************************************************
		// Constructors and Finalizer
		//**********************************************************************

		constructor(prototype: Prototype, name:string, _value?:typeOfValue)
		{

			this.prototype = prototype;

			this.fflag = new SharedFlag();
			this.eflag = new SharedFlag();
			this.lflag = new SharedFlag();
			this.tflag = new SharedFlag();
			this.sflag = new SharedFlag(); 

			this.listeners = new Array;
			this.name = name;
			this.value = _value;

			//console.log("Second : Variable " +name+ " created");
			if(printClass.printStatus) console.log(this.prototype.value);
			if(printClass.printStatus) console.log(this.value);
			
		}

		//**********************************************************************
		// Getters and Setters
		//**********************************************************************

		getPrototype(): Prototype
		{
			return this.prototype;
		}

		getName(): string
		{
			return ((name == null) ? this.prototype.getName : name);
		}

		setName(name: string): void
		{
			if ((name != null) && (name == (this.name)))
				return;

			this.name = name;

			this.fireEvent(new VariableEvent(this, VariableEvent.NAME_CHANGED, name));
		}

		getValue(): typeOfValue
		{
			return ((this.value == null) ? Variable.prototype.getValue() : this.value);
		}


		setValue(value: any): void 
		{
			//if(printClass.printStatus) 
			//console.log("SetValue in Variable");
			if (this.prototype.getConstant() || this.isLocked())
				return;
			if(printClass.printStatus) console.log(this.prototype.classType);
			if(printClass.printStatus) console.log(value.__proto__);
			if(printClass.printStatus) console.log(value);


			//console.log("check")
			if ((value != null) && !(this.prototype.classType == value.__proto__))
				 throw new Error(value.__proto__.name);
				 
			//	 console.log("single check")
			if ((value == null) && (this.value == null))
				 return;

			
			this.value = value;
			//console.log(value==(this.value));
			this.prototype.value = value;                //This Step Solved a Major Problem
			
		

			var varEvent = new VariableEvent(this, VariableEvent.VALUE_CHANGED,"dummy", value);
			if(printClass.printStatus) console.log(varEvent);
			if(printClass.printStatus) console.log(this);
			this.fireEvent(varEvent);
		} 

		
		//**********************************************************************
		//  public Methods
		//**********************************************************************

		getType(): Object
		{
			return Variable.prototype.getType();
		}

		isAssignableFrom( variable:Variable): boolean
		{
			return this.prototype.isAssignableFrom(variable.getPrototype());
		}

		touch(): void
		{
			this.fireEvent(new VariableEvent(this, VariableEvent.VALUE_CHANGED));
		}

		getBoundProperties(): any[]
		{
			var properties = new Array();
			var n: number = this.listeners.length;
			var i = 0;
			for (i = 0; i < n; i++)
				if ((this.listeners[i] instanceof LiveProperty) &&
					(this.listeners[i]).getVariable() == this)
			properties.push(this.listeners[i]);

			return properties;
		}


	 	//**********************************************************************
		//  Methods (Focusing)
		//**********************************************************************

		isFocusing(): boolean
		{
			//return fflag.getState();
			return (this.isLocked() ? false : this.fflag.getState());
		}

		setFocusing(b: boolean, object: any): void
		{
			if (this.fflag.setState(b, object))
				this.fireEvent(new VariableEvent(this, VariableEvent.FOCUS_CHANGED));
		}

		isSelfFocusing(): boolean
		{
			return this.fflag.getState(Variable);
		}

		setSelfFocusing(b: boolean): void
		{
			this.setFocusing(b, Variable);
		}

		//**********************************************************************
		//  Methods (Editing)
		//**********************************************************************

		isEditing(): boolean
		{
			//return eflag.getState();
			return (this.isLocked() ? false : this.eflag.getState());
		}

		setEditing(b: boolean, object: any): void
		{
			if (this.eflag.setState(b, object))
				this.fireEvent(new VariableEvent(this, VariableEvent.EDIT_CHANGED));
		}

		isSelfEditing(): boolean
		{
			return this.eflag.getState(Variable);
		}

		setSelfEditing(b: boolean): void
		{
			this.setEditing(b, Variable);
		}

		//**********************************************************************
		//  Methods (Locking)
		//**********************************************************************

		isLocked(): boolean
		{
			return this.lflag.getState();
		}

		setLocked(b: boolean, object: any): void
		{
			if (this.lflag.setState(b, object))
				this.fireEvent(new VariableEvent(this, VariableEvent.LOCK_CHANGED));
		}

		isSelfLocked(): boolean
		{
			return this.lflag.getState(Variable);
		}

		setSelfLocked( b:boolean): void
		{
			this.setLocked(b, Variable);
		}

		//**********************************************************************
		//  Methods (Tracking)
		//**********************************************************************

		isTracked(): boolean
		{
			return this.tflag.getState();
		}

		setTracked(b: boolean, object: any): void
		{
			if (this.tflag.setState(b, object))
				this.fireEvent(new VariableEvent(this, VariableEvent.TRACK_CHANGED));
		}

		isSelfTracked(): boolean
		{
			return this.tflag.getState(Variable);
		}

		setSelfTracked(b: boolean): void
		{
			this.setTracked(b, Variable);
		}

		//**********************************************************************
		//  Methods (Shared)
		//**********************************************************************

		isShared(): boolean
		{
			return this.sflag.getState();
		}

		setShared(b: boolean, object: any): void
		{
			if (this.sflag.setState(b, object))
				this.fireEvent(new VariableEvent(this, VariableEvent.SHARE_CHANGED));
		}

		isSelfShared(): boolean
		{
			return this.sflag.getState(Variable);
		}

		setSelfShared(b: boolean): void
		{
			this.setShared(b, Variable);
		} 

		//**********************************************************************
		//  Methods (Events)
		//**********************************************************************

		addVariableListener(l: VariableListener): void
		{
			this.listeners.push(l);
			if(printClass.printStatus) console.log("addVariableListener of Variable");
			if(printClass.printStatus) console.log(l);
		}

		removeVariableListener(l: VariableListener): void
		{
			this.listeners.splice(this.listeners.indexOf(l),1);
		}

		//**********************************************************************
		// Override Methods (Disposable)
		//**********************************************************************

 		dispose(): void
		{
			//if (this.value instanceof Value)
			//	(this.value).disassociate(this);

			this.fireEvent(new VariableEvent(this, VariableEvent.DISPOSING));
		} 

		
 
		//**********************************************************************
		// Private Methods (Events)
		//**********************************************************************

		fireEvent(e: VariableEvent): void
		{
			
				this.fireVariableChanged(e);
		}

		fireVariableChanged(e: VariableEvent): void
		{
			//if(printClass.printStatus) console.log(this.listeners)
			var n: number = e.getVariable().listeners.length;
			if(printClass.printStatus) console.log("Number of Listeners " + n);
			var i: number = 0;

			for(i=0;i<n;i++)
			{
				
				if(printClass.printStatus) console.log("Listener "+i+" : "+ this.listeners[i].getControl().ControlName);
			}


			for (i = 0; i < n; i++)
			{
				if(printClass.printStatus) console.log("----------------------- Listener :" +i+ "-------------------------------------")
				try
				{
					if(printClass.printStatus) console.log(this.listeners[i]);
					(this.listeners[i]).variableChanged(e);
				}
				catch (error)
				{
					//if(printClass.printStatus) console.log((VariableListener)listeners.at(i));
				}
			}
		}

	
}

