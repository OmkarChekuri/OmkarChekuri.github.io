//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

//import { typeOfValue } from "../index";
import { printClass } from "./printClass.js";
type typeOfValue = string | number | boolean | undefined | null|Array<boolean>;

//create of type of ClassType and metntion what types it needs to have
//Note : null not included on purpose

//we used undefined because it is a optional parameter in constructor

export class Prototype
{

	//**********************************************************************
	// Private Members
	//**********************************************************************

	// State (internal) variables
	//const type:(obj:any)=>string =( obj:any)=>{return (typeof obj)};

	public classType: any;
	public name: string;
	public value: typeOfValue;
	public constant: boolean;

	public  myMap = new Map();

	


	// Optimization (transient) variables
	public hc: number = 0;


	constructor(classType: any, name?: string | null, value?: typeOfValue, constant?: boolean)
	{
		this.myMap.set(Number.prototype,0);
		this.myMap.set(String.prototype,"");
		this.myMap.set(Boolean.prototype,false);
		this.myMap.set(Array.prototype,[]);
		// for (let [key, value] of this.myMap) {
		// 	if(printClass.printStatus) console.log(key + ' = ' + value)
		//   }
		
		//if(printClass.printStatus) console.log();

		if (classType == undefined)
		{ 
			throw Error("Prototype Constructor cannot be initialised with undefined classtype");
		}
		else
		{
			this.classType = ((classType == null) ? Object.getPrototypeOf(value): classType);
		}



		this.name = ((name == null) ? "" : name);
		

		//need to fix this
		if ((value != null) && !(this.classType == Object.getPrototypeOf(value)) )
		{
			throw new Error(" 'Class Type':" + classType + " does not match with 'value type':" + typeof value + " or value is null");
			
		}
		else
		{
			//this.value =  value;
			this.value = this.getDefault(classType);


		}



		//check if constant is provided
		if (constant)
		{
			this.constant = constant;
		}
		else
		{
			this.constant = false;
		}
		if(printClass.printStatus) console.log("First : prototype created" );
		//console.table(this);
		if(printClass.printStatus) console.log(this);

	}

public  getDefault(type:any):typeOfValue
{
	return this.myMap.get(type);
}



	//**********************************************************************
	// Getters and Setters
	//**********************************************************************

	public get getType(): string
	{
		return this.classType;
	}

	public get getName(): string
	{
		return this.name;
	}

	public getValue(): typeOfValue
	{
		return this.value;
	}

	public getConstant(): boolean
	{
		return this.constant;
	}

	//**********************************************************************
	// Public Methods
	//**********************************************************************

	/**
	 * Determines if the reference type of this Prototype is a superclass or
	 * superinterface of the reference type of the specified Prototype. Also
	 * returns false if this Prototype is constant and the specified Prototype
	 * is not.
	 *
	 * @see		java.lang.Class#isAssignableFrom
	 */
	public isAssignableFrom(prototype: Prototype): boolean
	{

		if(printClass.printStatus) console.log("I am in isassignable from of prototype");
		if (this == prototype)
			return true;

		if (this.constant && !prototype.constant)
			return false;
		else
			return (this.classType == (prototype.classType));
	}

	/**
	 * Returns true if the specified value is non-null and can be cast to the
	 * reference type of this Prototype without raising a ClassCastException.
	 * It returns false otherwise.
	 *
	 * @see		java.lang.Class#isInstance
	 */
	public isInstance(value: typeOfValue): boolean
	{
		return this.classType ==typeof value;
	}

	//**********************************************************************
	// Override Methods (Object)
	//**********************************************************************

	public equals(object: any): boolean
	{
		if (this == object)
			return true;

		if (!(object instanceof Prototype))
			return false;

		var that: Prototype = object;

		if ((this.classType != that.classType) ||
			(this.name != that.name) ||
			(this.constant != that.constant))
			return false;

		if (this.value == null)
			return (that.value == null);
		else
			return (this.value == (that.value));
	}

	
}

	//******************************************************************************


