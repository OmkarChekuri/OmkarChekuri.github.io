//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.


import { Variable } from "./LP/Variable.js";
import { Prototype } from "./LP/Prototype.js";


import { printClass } from "./LP/printClass.js";
import { ControlScatterplot } from "./control/ControlScatterplot.js";
import { ControlTable } from "./control/ControlTable.js";

import { ControlParallelCoordinatePlot } from "./control/ControlParallelCoordinatePlot";
import * as d3 from "d3";
import { ControlGradient } from "./control/ControlGradient.js";
import { ControlMap } from "./control/ControlMap.js";
import { ControlBubblechart } from "./control/ControlBubbleChart.js";

export type typeOfValue = string | number | boolean | undefined | null | Array<boolean> | Array<any>;
type controlType = "bubblechart" | "scatterplot" | "gradient" | "map" |  "table" |  "parallelCoordinatePlot";

let sliderCounter: number = 0;
let pixelCounter: number = 0;

function createControl( controlName: controlType, data: Array<any>, name: string, xPos?: number, yPos?: number,
    horizontalAxes?: number, verticalAxes?: number,
    inputWidth?: number, inputHeight?: number, showHoriz?: boolean, showVerti?: boolean, helper?:Array<any>,color?:number,size?:number,text?:number,dims?:Array<any>)
{
    if (printClass.printStatus) console.log("Next Step: Control Creation**************(( " + controlName + " ))**************");
    
    else if (controlName == "scatterplot")
    {
        let scatterplotControl = new ControlScatterplot(name, data, xPos, yPos,  horizontalAxes, verticalAxes, inputWidth, inputHeight, showHoriz, showVerti,helper,color,size,text);
        return scatterplotControl;
    }
    else if (controlName == "map")
    {
        let mapControl = new ControlMap(name, data, xPos, yPos,  inputWidth, inputHeight);
        return mapControl;
    }
    else if (controlName == "bubblechart")
    {
        let bubblechartControl = new ControlBubblechart(name, data, xPos, yPos,  inputWidth, inputHeight, helper,color,size,text);
        return bubblechartControl;
    }
    else if (controlName == "gradient")
    {
        let gradientControl = new ControlGradient(name,data, xPos, yPos,  horizontalAxes, inputWidth, inputHeight, showHoriz, showVerti,helper);
        return gradientControl;
    }
    else if (controlName == "table")
    {
        let tableControl = new ControlTable(name, data, xPos, yPos, inputWidth, inputHeight);
        return tableControl;
    }
    else if (controlName == "parallelCoordinatePlot")
    {
        let parallelCoordinatePlotControl = new ControlParallelCoordinatePlot(name,data, xPos, yPos, horizontalAxes, verticalAxes, inputWidth, inputHeight,helper,color,dims);
        return parallelCoordinatePlotControl;
    }
    else
    {
        throw Error("Control Doesnot exist yet")
    }
}




function createVariable(variableName: string, value: typeOfValue, classtype: any)
{
    if (printClass.printStatus) console.log("Next Step:Variable Creation*************(( " + variableName + " ))***********");
    if (printClass.printStatus) console.log(value);
    let CUR_TAG: string = "Value";

    //if you don't want to pass parameters use placeholder undefined
    let CUR_VALUE: Prototype = new Prototype(classtype, CUR_TAG, undefined, undefined);
    if (printClass.printStatus) console.log(CUR_VALUE);
    let variable = new Variable(CUR_VALUE, variableName, value);

    return variable;

}


function bindVariable(control:  ControlSlider | ControlBubblechart| ControlScatterplot | ControlGradient | ControlTable |  ControlParallelCoordinatePlot | ControlMap, property: string, variable: Variable)
{
   
    if (printClass.printStatus) console.log(control);
    //if (printClass.printStatus) console.log("Next step:*************************** Binding (( " + variable.name + " )) to (( " + control.ControlName + " ))******************");
    control.proxy.setVariable(property, variable);
   
}



//Define Control Types

let Scatterplot_type: controlType = "scatterplot";

let Gradient_type: controlType = "gradient";

let Table_type: controlType = "table";

let ParallelCoordinatePlot_type: controlType = "parallelCoordinatePlot";




//Load Data
Promise.all([
    d3.csv("./data/ions.csv", ({ T, X, Y, Z }, index) =>
        ({
    
            Index: +index,
            T: +(T.replace(/,/g, "")),
            X: +(X.replace(/,/g, "")),
            Y: +(Y.replace(/,/g, "")),
            Z: +(Z.replace(/,/g, "")),
    
        })
    
    )
]).then(
([ionsData]) =>
{

    

    let IonsVariables = { Index:0, T: 1, X: 2, Y: 3, Z: 4 };

    //lookup for items
    function IonsAxes(d: {Index:number,T: number, X: number,Y: number, Z: number}, idx: number)
    {
    if (idx == 0){ return d.Index }
    else if (idx == 1) {return d.T}
    else if (idx == 2) {return d.X}
    else if (idx == 3) {return d.Y}
    else if (idx == 4) {return d.Z}
    }




   
    

   function ionsExample(){
    // let variable1 = createVariable("variable1", 50, Number.prototype);
    let Selection_4 = createVariable("Selection_4", [], Array.prototype);
    let Selection_5 = createVariable("Selection_5", [], Array.prototype);
    let Selection_6 = createVariable("Selection_6", [], Array.prototype);
    let Selection_7 = createVariable("Selection_7", [], Array.prototype);
    let Selection_8 = createVariable("Selection_8", [], Array.prototype);
    let Indication_2 = createVariable("Indication_2", [], Array.prototype);
    let Data_2 = createVariable("Data_2", ionsData, Array.prototype);
                    
    //variables for axis
    let Translation_4 = createVariable("Translation_4", [0], Array.prototype);
    let Translation_5 = createVariable("Translation_5", [0], Array.prototype);
    let Translation_6 = createVariable("Translation_6", [0], Array.prototype);
    let Translation_7 = createVariable("Translation_7", [0], Array.prototype);



    let Range_1 = createVariable("Range1", [null,null], Array.prototype);
    let Range_2 = createVariable("Range2", [null,null], Array.prototype);
    let Range_3 = createVariable("Range3", [null,null], Array.prototype);
    let Range_4 = createVariable("Range4", [null,null], Array.prototype);
    let Range_5 = createVariable("Range5", [null,null], Array.prototype);
    let Range_6 = createVariable("Range6", [null,null], Array.prototype);

    let lPW = 280;
    let lPH = 180;
    let lPL = 50;
    let lPT = 150;
    let off = 5;
    var parentName = "ionsViz";
    




    let scatterplot01 = createControl(Scatterplot_type,ionsData, "SP-01",lPL, lPT,  IonsVariables.T , IonsVariables.Z, lPW, lPH,
    false,true, [IonsAxes],IonsVariables.T,null,null);
    bindVariable(scatterplot01, "xTranslate", Translation_4);
    bindVariable(scatterplot01, "yTranslate", Translation_5);
    bindVariable(scatterplot01, "Selection", Selection_4);
   
    
    
    // //x = T Y = Y
     let scatterplot02 = createControl(Scatterplot_type,ionsData, "SP-02",lPL,lPT + lPH ,  IonsVariables.T , IonsVariables.Y, lPW, lPH,
     false,true, [IonsAxes],IonsVariables.T,null,null);
    bindVariable(scatterplot02, "xTranslate", Translation_4);
    bindVariable(scatterplot02, "yTranslate", Translation_6);
    bindVariable(scatterplot02, "Selection", Selection_4);
   
    
    
    // //x = T, y=X
     let scatterplot03 = createControl(Scatterplot_type, ionsData, "SP-03",lPL,lPT + 2*lPH ,  IonsVariables.T , IonsVariables.X,lPW, lPH,
     true,true, [IonsAxes],IonsVariables.T,null,null);
    
    bindVariable(scatterplot03, "xTranslate", Translation_4);
    bindVariable(scatterplot03, "yTranslate", Translation_7);
    bindVariable(scatterplot03, "Selection", Selection_4);
    
    
           
     let SPH = lPH + lPH/2;
     let SPW = lPH +lPH/2;
    
    
    // //x = X, y= Z
     let scatterplot04 = createControl(Scatterplot_type,ionsData, "SP-04", lPL + lPW ,lPT, IonsVariables.X , IonsVariables.Z,SPW,SPH -5,
     true,true,[IonsAxes],IonsVariables.T,null,null);
    
    bindVariable(scatterplot04, "xTranslate", Translation_5);
    bindVariable(scatterplot04, "yTranslate", Translation_7);
    bindVariable(scatterplot04, "brushX", Range_1);
    bindVariable(scatterplot04, "brushY", Range_2);
  
    
    
    // //x = X, y= Z
     let scatterplot05 = createControl(Scatterplot_type,ionsData, "SP-05",lPL + lPW,lPT + SPH,  IonsVariables.X , IonsVariables.Y,SPW,SPH,
     true,true,[IonsAxes],IonsVariables.T,null,null);
    
    bindVariable(scatterplot05, "xTranslate", Translation_5);
    bindVariable(scatterplot05, "yTranslate", Translation_6);
    bindVariable(scatterplot05, "brushX", Range_3);
    bindVariable(scatterplot05, "brushY", Range_4);
   
    
    // //x = Z, y= Y
     let scatterplot06 = createControl(Scatterplot_type,ionsData, "SP-06",lPL + lPW + SPW ,lPT + SPH,  IonsVariables.Z , IonsVariables.Y,SPW,SPH,
     true,false,[IonsAxes],IonsVariables.T,null,null);
    
    bindVariable(scatterplot06, "xTranslate", Translation_7);
    bindVariable(scatterplot06, "yTranslate", Translation_6);
    bindVariable(scatterplot06, "brushX", Range_5);
    bindVariable(scatterplot06, "brushY", Range_6);
   
    
    
    
    
    // //x = X, y= Z
    let insetScatterplot1 = createControl(Scatterplot_type,ionsData, "ISP-1", lPL + lPW + 3*SPW ,lPT, IonsVariables.X , IonsVariables.Z,SPW,SPH-5,
    true,true,[IonsAxes],IonsVariables.T,null,null);
     bindVariable(insetScatterplot1, "xRange", Range_1);
    bindVariable(insetScatterplot1, "yRange", Range_2);
    
   
    
    let insetScatterplot2 = createControl(Scatterplot_type, ionsData,"ISP-2",lPL + lPW + 2*SPW,lPT + SPH,  IonsVariables.X , IonsVariables.Y,SPW,SPH,
     true,true,[IonsAxes],IonsVariables.T,null,null);
     bindVariable(insetScatterplot2, "xRange", Range_3);
     bindVariable(insetScatterplot2, "yRange", Range_4);
    
    // //x = Z, y= Y
     let insetScatterplot3 = createControl(Scatterplot_type, ionsData,"ISP-3",lPL + lPW + SPW + 2*SPW ,lPT + SPH,  IonsVariables.Z , IonsVariables.Y,SPW,SPH,
      true,true,[IonsAxes],IonsVariables.T,null,null);
     bindVariable(insetScatterplot3, "xRange", Range_5);
     bindVariable(insetScatterplot3, "yRange", Range_6);
    
    let TW = lPW+ 20 ;
    let TH = 3*lPH -50; 
    
    let table01 = createControl(Table_type,[ionsData], "TableView-01",lPL + lPW + 4*SPW ,lPT, null,null,
    TW,TH,null,null, null,null,null,null );
    bindVariable(table01, "Selection", Selection_4);
     
    
    let parallelCoordinatePlot1 = createControl(ParallelCoordinatePlot_type,ionsData,"PCP-1",lPL + lPW + SPW,lPT, null , null,
     2*SPW,SPH -12,null,null, [IonsAxes],IonsVariables.T,null,null, ["T","X","Y","Z"]);
    bindVariable(parallelCoordinatePlot1, "Selection", Selection_8);

    let gradient1 = createControl(Gradient_type,ionsData, "Gradient1",lPL + lPW + 4*SPW ,lPT + 3*lPH -50 ,  IonsVariables.T , null, lPW-10, 50,false,false,[IonsAxes]);
    bindVariable(gradient1, "Selection", Selection_8);
    


}

    ionsExample();
    
}
);



