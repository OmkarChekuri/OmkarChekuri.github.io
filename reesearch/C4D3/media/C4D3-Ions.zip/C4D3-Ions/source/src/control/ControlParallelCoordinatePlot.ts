//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Prototype } from "../LP/Prototype.js";
import { Control } from "../LP/Control.js";
import { ControlProxy } from "../LP/ControlProxy.js";
import { LiveProperty } from "../LP/LiveProperty.js";
import { LivePropertyEvent } from "../LP/LivePropertyEvent.js";
import { VariableEvent } from "../LP/VariableEvent.js";

//import { typeOfValue } from "../index.js";
import { printClass } from "../LP/printClass.js";
import { ControlInfo } from "../LP/ControlInfo.js";
import { ParallelCoordinatePlotClass } from "../view/parallelCoordinatePlot.js";
type typeOfValue = string | number | boolean | undefined | null;

//******************************************************************************
// class ControlSlider
//******************************************************************************

export class ControlParallelCoordinatePlot implements Control
{
  
   
   
   
    public CTAG_xTranslate: string = "xTranslate";  
    public CTAG_yTranslate: string = "yTranslate"; 
    public CTAG_Size: string = "Size"; 
    public CTAG_Opacity: string = "Opacity";  
    public CTAG_Selection: string = "Selection"; 
    public CTAG_Indication: string = "Indication"; 
      


    public TYPE_xTranslate: Prototype = new Prototype(Array.prototype, this.CTAG_xTranslate, [null,null]);
    public TYPE_yTranslate: Prototype = new Prototype(Array.prototype, this.CTAG_yTranslate, [null,null]);
    public TYPE_Size: Prototype = new Prototype(Number.prototype, this.CTAG_Size, 0);
    public TYPE_Opacity: Prototype = new Prototype(Number.prototype, this.CTAG_Opacity, 0);
    public TYPE_Selection: Prototype = new Prototype(Array.prototype, this.CTAG_Selection, [false]);
    public TYPE_Indication: Prototype = new Prototype(Array.prototype, this.CTAG_Indication, [false]);

    public proxy: ControlProxy;

    public parallelCoordinatePlot: ParallelCoordinatePlotClass;

    public live_property1:LiveProperty;
    public live_property2:LiveProperty;
    public live_property3:LiveProperty;
    public live_property4:LiveProperty;
    public live_property5:LiveProperty;
    public live_property6:LiveProperty;

    public ControlName: string ;


   

    //**********************************************************************
    // Constructors and Finalizer
    //**********************************************************************

    constructor(name: string, data: Array<any>, xPos:number,yPos:number, horizontal:number, vertical:number,inputWidth:number,inputHeight:number,helper:Array<any>,
        color:number,dims:Array<any>)
    {
        if(printClass.printStatus) console.log("I am in constructor of ControlParallelCoordinatePlot");
        //Create Control Proxy
        //if(printClass.printStatus) console.log(this.TYPE_VALUE);
        this.proxy = new ControlProxy(this);

        
        
        //create live property
        this.live_property1 = this.proxy.add(this.CTAG_xTranslate, this.TYPE_xTranslate, true);
        this.live_property2 = this.proxy.add(this.CTAG_yTranslate, this.TYPE_yTranslate, true);  
        this.live_property3 = this.proxy.add(this.CTAG_Opacity, this.TYPE_Opacity, true); 
        this.live_property4 = this.proxy.add(this.CTAG_Selection, this.TYPE_Selection, true);  
        this.live_property5 = this.proxy.add(this.CTAG_Size, this.TYPE_Size, true);
        this.live_property6 = this.proxy.add(this.CTAG_Indication, this.TYPE_Indication, true);              
        
        if(printClass.printStatus) console.log(this.live_property1);
        if(printClass.printStatus) console.log(this.live_property2);
        
        this.ControlName = name;
        this.parallelCoordinatePlot = new ParallelCoordinatePlotClass(this, data, name,xPos,yPos,horizontal,vertical,inputWidth,inputHeight,helper,color,dims);
        if(printClass.printStatus) console.log(name);

        

        
    }




    //**********************************************************************
    // Public Methods (Properties)
    //**********************************************************************



    public getTranslateX(): Array<any>
    {
        return (this.proxy.getValue(this.CTAG_xTranslate) as Array<any>);
    }

    public setTranslateX(value: typeOfValue): void
    {
       console.log("setTranslateX method of ControlParallelCoordinatePlot")
        this.proxy.setValue(this.CTAG_xTranslate, value);
        //this.canvas.setValue(value);
    }


    public getColor(): string
    {
        return (this.proxy.getValue(this.CTAG_Opacity) as string);
    }

    public getProxy():ControlProxy
    {
        return this.proxy;
    }

    public setColor(value: typeOfValue): void
    {
        if(printClass.printStatus) console.log("setColor method of ControlParallelCoordinatePlot")
        this.proxy.setValue(this.CTAG_Opacity, value);
        //this.canvas.setValue(value);
    }



    public getTranslateY(): Array<any>
    {
        return (this.proxy.getValue(this.CTAG_yTranslate) as Array<any>);
    }

    public setTranslateY(value: typeOfValue): void
    {
        console.log("setTranslateY method of ControlParallelCoordinatePlot")
        this.proxy.setValue(this.CTAG_yTranslate, value);
        //this.canvas.setValue(value);
    }

    

    //**********************************************************************
    // Override Methods (LivePropertyListener)
    //**********************************************************************

    public propertyChanged(e: LivePropertyEvent): void
    {

        if(printClass.printStatus) console.log("propertyChanged method of controlParallelCoordinatePlot");
        if(printClass.printStatus) console.log(e);
        var	tag:string = e.getLiveProperty().getTag();
        if(printClass.printStatus) console.log(tag);

        var    ve:VariableEvent = e.getVariableEvent()!;
                    
            if (tag == this.CTAG_xTranslate)
            {
                if(printClass.printStatus) console.log("controlParallelCoordinatePlot height")
                
                   this.parallelCoordinatePlot.translateX(e.getLiveProperty().getVariable().getValue() as Array<any>);
                   
            }
            else if(tag == this.CTAG_yTranslate)
            {
                if(printClass.printStatus)  console.log(" controlParallelCoordinatePlot Width")
              
                   this.parallelCoordinatePlot.translateY(e.getLiveProperty().getVariable().getValue() as Array<any>) ;
                  
            }
            else if(tag == this.CTAG_Opacity)
            {
                if(printClass.printStatus) console.log(" controlParallelCoordinatePlot opacity")
                
                   this.parallelCoordinatePlot.setOpacity(e.getLiveProperty().getVariable().getValue());
                 
            }
            else if(tag == this.CTAG_Selection)
            {
                if(printClass.printStatus) console.log(" ControlParallelCoordinatePlot Selection")
                
                   this.parallelCoordinatePlot.setSelection(e.getLiveProperty().getVariable().getValue() as Array<any>);
                   
            }
            else if(tag == this.CTAG_Indication)
            {
                if(printClass.printStatus) console.log(" ControlParallelCoordinatePlot Size")
                
                   this.parallelCoordinatePlot.setIndication(e.getLiveProperty().getVariable().getValue() as Array<any>);
                  
            }
            
  

    }




    //**********************************************************************
    // Private Methods (Graphics)
    //**********************************************************************



    describe(): ControlInfo
    {
        throw new Error("Method not implemented.");
    }
    dispose(): void
    {
        throw new Error("Method not implemented.");
    }



    
    



}

//******************************************************************************


