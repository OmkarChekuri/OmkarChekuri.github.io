//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Prototype } from "../LP/Prototype.js";
import { Control } from "../LP/Control.js";
import { ControlProxy } from "../LP/ControlProxy.js";
import { LiveProperty } from "../LP/LiveProperty.js";
import { LivePropertyEvent } from "../LP/LivePropertyEvent.js";
import { VariableEvent } from "../LP/VariableEvent.js";

//import { typeOfValue } from "../index.js";
import { printClass } from "../LP/printClass.js";
import { ControlInfo } from "../LP/ControlInfo.js";
import { ScatterplotClass } from "../view/scatterplot.js";
type typeOfValue = string | number | boolean | undefined | null;

//******************************************************************************
// class ControlSlider
//******************************************************************************

export class ControlScatterplot implements Control
{

   
   
   
    public CTAG_xTranslate: string = "xTranslate";  
    public CTAG_yTranslate: string = "yTranslate"; 
    public CTAG_Size: string = "Size"; 
    public CTAG_Opacity: string = "Opacity";  
    public CTAG_Selection: string = "Selection"; 
    public CTAG_Indication: string = "Indication";       
    public CTAG_Data: string = "Data"; 
    public CTAG_Zoom: string = "Zoom"; 
    public CTAG_xRange: string = "xRange"; 
    public CTAG_yRange: string = "yRange"; 
    public CTAG_brushX: string = "brushX"; 
    public CTAG_brushY: string = "brushY"; 
    
      

    public TYPE_xTranslate: Prototype = new Prototype(Array.prototype, this.CTAG_xTranslate, [null,null]);
    public TYPE_yTranslate: Prototype = new Prototype(Array.prototype, this.CTAG_yTranslate, [null,null]);
    public TYPE_Size: Prototype = new Prototype(Number.prototype, this.CTAG_Size, 0);
    public TYPE_Opacity: Prototype = new Prototype(Number.prototype, this.CTAG_Opacity, 0);
    public TYPE_Selection: Prototype = new Prototype(Array.prototype, this.CTAG_Selection, [false]);
    public TYPE_Indication: Prototype = new Prototype(Array.prototype, this.CTAG_Indication, [false]);
    public TYPE_Data: Prototype = new Prototype(Array.prototype, this.CTAG_Data, []);
    public TYPE_Zoom: Prototype = new Prototype(Array.prototype, this.CTAG_Zoom, [null,null]);
    public TYPE_xRange: Prototype = new Prototype(Array.prototype, this.CTAG_xRange, [null,null]);
    public TYPE_yRange: Prototype = new Prototype(Array.prototype, this.CTAG_yRange, [null,null]);
    public TYPE_brushX: Prototype = new Prototype(Array.prototype, this.CTAG_brushX, [null,null]);
    public TYPE_brushY: Prototype = new Prototype(Array.prototype, this.CTAG_brushY, [null,null]);
    

    public proxy: ControlProxy;

    public scatterplot: ScatterplotClass;

    public live_property_xTranslate:LiveProperty;
    public live_property_yTranslate:LiveProperty;
    public live_property_Size:LiveProperty;
    public live_property_Opacity:LiveProperty;
    public live_property_Selection:LiveProperty;
    public live_property_Indication:LiveProperty;
    public live_property_Data:LiveProperty;
    public live_property_Zoom:LiveProperty;
    public live_property_xRange:LiveProperty;
    public live_property_yRange:LiveProperty;
    public live_property_brushX:LiveProperty;
    public live_property_brushY:LiveProperty;

    public ControlName: string ;


   

    //**********************************************************************
    // Constructors and Finalizer
    //**********************************************************************

    constructor(name: string, data:Array<any> ,xPos:number,yPos:number, 
         horizontal:number, vertical:number,inputWidth:number,inputHeight:number,
         showHoriz:boolean,showVerti:boolean, helper:Array<any>,color:number,size:number,text:number )
    {
        if(printClass.printStatus) console.log("I am in constructor of ControlScatterplot");
        //Create Control Proxy
        //if(printClass.printStatus) console.log(this.TYPE_VALUE);
        this.proxy = new ControlProxy(this);

        
        
        //create live property
        this.live_property_xTranslate = this.proxy.add(this.CTAG_xTranslate, this.TYPE_xTranslate, true);
        this.live_property_yTranslate = this.proxy.add(this.CTAG_yTranslate, this.TYPE_yTranslate, true);  
        this.live_property_Opacity = this.proxy.add(this.CTAG_Opacity, this.TYPE_Opacity, true); 
        this.live_property_Selection = this.proxy.add(this.CTAG_Selection, this.TYPE_Selection, true);  
        this.live_property_Indication = this.proxy.add(this.CTAG_Indication, this.TYPE_Indication, true);  
        this.live_property_Size = this.proxy.add(this.CTAG_Size, this.TYPE_Size, true);
        this.live_property_Data = this.proxy.add(this.CTAG_Data, this.TYPE_Data, true);
        this.live_property_Zoom = this.proxy.add(this.CTAG_Zoom, this.TYPE_Zoom, true); 
        this.live_property_xRange = this.proxy.add(this.CTAG_xRange, this.TYPE_xRange, true); 
        this.live_property_yRange = this.proxy.add(this.CTAG_yRange, this.TYPE_yRange, true);      
        this.live_property_brushX = this.proxy.add(this.CTAG_brushX, this.TYPE_brushX, true); 
        this.live_property_brushY = this.proxy.add(this.CTAG_brushY, this.TYPE_brushY, true);              
        
        
        
        this.ControlName = name;
        //console.log(data)
        this.scatterplot = new ScatterplotClass(this,data, name,xPos,yPos,horizontal,vertical,inputWidth,inputHeight,showHoriz,showVerti,helper,color,size,text);
        if(printClass.printStatus) console.log(name);

        

        
    }




    //**********************************************************************
    // Public Methods (Properties)
    //**********************************************************************



    public getTranslateX(): typeOfValue
    {
        return (this.proxy.getValue(this.CTAG_xTranslate) as typeOfValue ) ;
    }

    public setTranslateX(value: typeOfValue): void
    {
       console.log("setTranslateX method of ControlScatterplot")
        this.proxy.setValue(this.CTAG_xTranslate, value);
        //this.canvas.setValue(value);
    }


    public getColor(): typeOfValue
    {
        return (this.proxy.getValue(this.CTAG_Opacity) as typeOfValue) ;
    }

    public getProxy():ControlProxy
    {
        return this.proxy;
    }

    public setColor(value: typeOfValue): void
    {
        if(printClass.printStatus) console.log("setColor method of ControlScatterplot")
        this.proxy.setValue(this.CTAG_Opacity, value);
        //this.canvas.setValue(value);
    }



    public getTranslateY(): typeOfValue
    {
        return (this.proxy.getValue(this.CTAG_yTranslate) as typeOfValue);
    }

    public setTranslateY(value: typeOfValue): void
    {
        console.log("setTranslateY method of ControlScatterplot")
        this.proxy.setValue(this.CTAG_yTranslate, value);
        //this.canvas.setValue(value);
    }

   

    //**********************************************************************
    // Override Methods (LivePropertyListener)
    //**********************************************************************

    public propertyChanged(e: LivePropertyEvent): void
    {

        if(printClass.printStatus) console.log("propertyChanged method of controlScatterPlot");
        if(printClass.printStatus) console.log(e);
        var	tag:string = e.getLiveProperty().getTag();
        if(printClass.printStatus) console.log(tag);

        var    ve:VariableEvent = e.getVariableEvent()!;
                   
            if (tag == this.CTAG_xTranslate)
            {
                if(printClass.printStatus) console.log("Property Changed controlScatterPlot height")
                       this.scatterplot.translateX(e.getLiveProperty().getVariable().getValue() as Array<any>);
                             }
            else if(tag == this.CTAG_yTranslate)
            {
                if(printClass.printStatus)  console.log("Property Changed controlScatterPlot Width")
                
                   this.scatterplot.translateY(e.getLiveProperty().getVariable().getValue() as Array<any>);
                  
            }
            else if(tag == this.CTAG_Opacity)
            {
                if(printClass.printStatus) console.log("Property Changed controlScatterPlot opacity")
                this.scatterplot.setOpacity(e.getLiveProperty().getVariable().getValue());
            }
            else if(tag == this.CTAG_Selection)
            {
                if(printClass.printStatus) console.log("Property Changed ControlScatterplot Selection")
                 this.scatterplot.setSelection(e.getLiveProperty().getVariable().getValue() as Array<any>);
             }
            else if(tag == this.CTAG_Indication)
            {
                if(printClass.printStatus) console.log("Property Changed ControlScatterplot Indication")
                 this.scatterplot.setIndication(e.getLiveProperty().getVariable().getValue() as Array<any>);
            }
            else if(tag == this.CTAG_Size)
            {
                if(printClass.printStatus) console.log("Property Changed ControlScatterplot Size")
                 this.scatterplot.setSize(e.getLiveProperty().getVariable().getValue());
            }
            else if(tag == this.CTAG_Data)
            {
                if(printClass.printStatus) console.log("Property Changed ControlScatterplot Size")
                 this.scatterplot.setHoverSelection(e.getLiveProperty().getVariable().getValue());
            }
            else if(tag == this.CTAG_Zoom)
            {
                if(printClass.printStatus) console.log("Property Changed ControlScatterplot Zoom")
                   this.scatterplot.setZoom(e.getLiveProperty().getVariable().getValue() as Array<any>);
            }
            else if(tag == this.CTAG_xRange)
            {
                if(printClass.printStatus) console.log("Property Changed ControlScatterplot xRange")
                   this.scatterplot.setxRange(e.getLiveProperty().getVariable().getValue() as Array<any>);
            }
            else if(tag == this.CTAG_yRange)
            {
                if(printClass.printStatus) console.log("Property Changed ControlScatterplot yRange")
                   this.scatterplot.setyRange(e.getLiveProperty().getVariable().getValue() as Array<any>);
            }
            else if(tag == this.CTAG_brushX)
            {
                if(printClass.printStatus) console.log("Property Changed ControlScatterplot brushX")
                   this.scatterplot.setBrushX(e.getLiveProperty().getVariable().getValue() as Array<any>);
            }
            else if(tag == this.CTAG_brushY)
            {
                if(printClass.printStatus) console.log("Property Changed ControlScatterplot brushY")
                   this.scatterplot.setBrushY(e.getLiveProperty().getVariable().getValue() as Array<any>);
            }
         


    }



    //**********************************************************************
    // Private Methods (Graphics)
    //**********************************************************************



    describe(): ControlInfo
    {
        throw new Error("Method not implemented.");
    }
    dispose(): void
    {
        throw new Error("Method not implemented.");
    }



    
    



}

//******************************************************************************


