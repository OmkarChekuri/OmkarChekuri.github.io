//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.



import * as d3 from 'd3';
import { Draggable } from '../miscellaneous/Draggable.js';
import { printClass } from '../LP/printClass.js';
import { ControlMap } from '../control/ControlMap.js';
import { D3ZoomEvent, geoPath, geoMercator, json, geoNaturalEarth1, geoEqualEarth } from 'd3';
import { feature } from "topojson";
import { Topology, Objects } from 'topojson-specification';
type typeOfValue = string | number | boolean | undefined | null | Array<boolean> | Array<any>;

export class MapClass
{
  private width: number = 960;
  private height: number = 480;
  mapControlName: string;

  private LocalData: d3.DSVParsedArray<{
    Index: number;
    selectionStatus: boolean;
    T: number;
    X: number;
    Y: number;
    Z: number;
  }>;
  //private static xAxis;
  //private static Axis;
  public parentControl: ControlMap;
  inputWidth: number;
  inputHeight: number;

  //plotWidth: number;
  //plotHeight: number;
  canvasWidth: number;
  yAxis: d3.Selection<SVGGElement, unknown, null, undefined>;
  xAxis: d3.Selection<SVGGElement, unknown, null, undefined>;
  glyph: d3.SymbolType;
  innerWidth: number;
  innerHeight: number;
  xTrans: number;
  yTrans: number;
  previousX: number;
  previousY: any;
  horizontal: number;
  vertical: number;
  xPos: number;
  yPos: number;
 
  yScale: d3.ScaleLinear<number, number>;
  xScale: d3.ScaleLinear<number, number>;
  Data:Array<any>;
  //margin: { top: number; right: number; bottom: number; left: number; };


  SelectionArray:any;
  IndicationArray:any;
  parentDocument: HTMLDivElement;

  constructor(control: ControlMap, name: string, data:Array<any>, xPos: number, yPos: number,  inputWidth: number, inputHeight: number)
  {
    if (printClass.printStatus) console.log("I am in constructor of MapClass");
    this.mapControlName = name;
    
    this.inputWidth = inputWidth;
    this.inputHeight = inputHeight;
    this.mapControlName = name;
    this.parentControl = control;
    
    this.previousX = 0;
    this.previousY = 0;
    this.xPos = xPos;
    this.yPos = yPos;
    
    this.Data = data;

    //console.log(data[2]);
    this.SelectionArray = new Array(data[2].length);
    this.SelectionArray.fill(false,0);

    this.IndicationArray = new Array(data[2].length);
    this.IndicationArray.fill(false,0);




    this.render(control);

  }
  makeDraggable()
  {
    //create instance of a Draggable class
    var D1 = new Draggable();
    var temp = this.mapControlName;
        
    try
    {

      document.getElementById(this.mapControlName + "header")!
        .addEventListener('mousedown', function ()
        { D1.dragElement(document.getElementById(temp)); }, false);
    }
    catch (error)
    {
      throw Error("The Element by id " + this.mapControlName + " do not exist");
    }
  }

  //************************
  // Getters and Setters
  //************************

  getTranslateX(): typeOfValue
  {
    return this.height;
  }

  getTranslateY(): typeOfValue
  {
    return this.width;
  }

  setSize(value: typeOfValue)
  {
    //console.log("set Size method of Map");
    if (printClass.printStatus) console.log(value);

    var temp = value as number;
    //console.log();
    d3.select(`#${this.mapControlName}`)
      .select("svg")
      .select("g")
      .selectAll("circle")
      .attr("r", temp / 10);

    if (printClass.printStatus) console.log("successfully updated the variable");
    /*  else{
         throw Error("Value not in bounds")
     } */
  }




  setOpacity(value: typeOfValue)
  {

    //console.log("setOpacity of map");
    var temp = value as number;
    //console.log(temp);

    d3.selectAll("circle").attr("fill-opacity", `${temp / 100}`);


  }

 
  setSelection(data:any)
  {
    
    
    var MapCountries = this.Data[2];

    var temp = MapCountries.map(d => [d.CountryOfInterest,data[d.Index]]);
    

    let mapSelection = new Map();
    
    temp.map(d => mapSelection.set(d[0],d[1]));

    var paths =  d3.select(`#${this.mapControlName}`).select("svg").selectAll("path");

      paths     
      .style("fill", function(d) {
        if(mapSelection.get(  d.properties.name  ) == true){
                return  "grey";
        }
        else{
          return null
        }  
    })
     
  }


  setIndication(data:any)
  {
    var MapCountries = this.Data[2];
    var temp = MapCountries.map(d => [d.CountryOfInterest,data[d.Index]]);
    let mapIndication = new Map();
    temp.map(d => mapIndication.set(d[0],d[1]));

    var paths =  d3.select(`#${this.mapControlName}`).select("svg").selectAll("path");
    paths     
    .style("stroke", function(d) {
      if(mapIndication.get(  d.properties.name  ) == true){
        return "blue"
      }
      else{
        return "black"
      }  
    })
    .style("stroke-width", function(d) {
      if(mapIndication.get(  d.properties.name  ) == true){
        return 3
      }
      else{
        return 0.2
      }  
    })
    .style("opacity", function(d) {
      if(mapIndication.get(  d.properties.name  ) == true){
        return 1
      }
      else{
        return 1;
      }  
    });
    

  }

  setHoverSelection(data: any)
  {

   

  let mapHover = new Map();
  let mapSelection = new Map(); 

  data.map(d => mapHover.set(d.CountryOfInterest,d.Hover));
  data.map(d => mapSelection.set(d.CountryOfInterest,d.Selection));
  


 var paths =  d3.select(`#${this.mapControlName}`).select("svg").selectAll("path");

      paths     
      .style("fill", function(d) {

      if(mapHover.get(  d.properties.name  ) == true){
        //console.log(data)
        return  "red";
      }
      else if(mapSelection.get(  d.properties.name  ) == true){
        return "blue"
      }
      else{
        return null
      }  
     
      })
      .style("stroke", function(d) {

         
        if(mapSelection.get(  d.properties.name  ) == true){
          return 5
        }
        else if(mapHover.get(  d.properties.name  ) == true){
          return 5
        }
        else{
          return 1
        }  
       
        });





    
  }

  private render(parentControl: ControlMap): void
  {
    var localParentControl = parentControl;

    var parentDocument = this.parentDocument;
    //create a div element to hold map
    var div1: HTMLDivElement = document.createElement("div");
    div1.id = this.mapControlName;
    div1.className = "map"
    var numberPattern = /\d+/g;
    var offset = 20;
   
    div1.style.left = this.xPos + "px";
    div1.style.top = this.yPos + "px";

    

    //create a div header for the map
    var div2 = document.createElement("div");
    div2.id = div1.id + "header";
    div2.className = "mapheader";
    //div2.textContent = div1.id;

    //make the div header a child to the div element
    div1.appendChild(div2);

    //console.log("I am printing D3 Object in MapClass");
    var d3obj = d3;
    //console.log(d3obj);




    var count = -1;
    function indexnumber()
    {
      count++;
      return count;
    }

    
    var tsvData = this.Data[0];
    var worldMapTopoJson = this.Data[1];
    var coronaData = this.Data[2];
    //console.log(coronaData);
    
    const renderPlot = (tsvData: any[], worldMapTopoJson: Topology<Objects<{ [name: string]: any; }>>, CoronaData:any[]) =>
    {


      var margin = { top: 30, right: 15, bottom: 30, left: 60 };
      var plotWidth = this.inputWidth - margin.left - margin.right;
      var plotHeight = this.inputHeight - margin.top - margin.bottom;
      this.innerWidth = plotWidth + margin.left + margin.right;
      this.innerHeight = plotHeight + margin.top + margin.bottom;
  
  
      // append the svg object to the body of the page
          var svg = d3
          .select(div1)
          .append("svg")
          .attr("width", this.inputWidth)
          .attr("height", this.innerHeight);
  
      const projection = geoMercator().scale(100)
      .translate([this.innerWidth / 2, this.innerHeight / 2]);;
      const pathGenerator = geoPath().projection(projection);
  
      const g = svg.append("g");
  
  
      g.append("path")
        .attr("class", "sphere");
      
      const countryName = tsvData.reduce((accumulator, d) => {
        accumulator[d.iso_n3] = d.name;
        return accumulator;
      }, {});
      
      
     svg.call(d3.zoom().on("zoom", () => 
     { 
       g.attr("transform", d3.event.transform); 
     }
     ));

     
     var color = d3.scaleOrdinal(coronaData.map(d => d.Continent), 
     ["#8dd3c7","#bebada", "#fb8072","#80b1d3","#ffffb3","#fdb462","#b3de69" ]).unknown(null)
     


     var tooltip =g
  .append("div")
  .style("opacity", 0)
  .attr("class", "tooltip")
  .style("background-color", "white")
  .style("border", "solid")
  .style("border-width", "2px")
  .style("border-radius", "5px")
      
     const countries = feature(worldMapTopoJson, worldMapTopoJson.objects.countries);
     //console.log(coronaData);


     
     let mapColorSelection = new Map();
     var temp = coronaData.map(d => [d.CountryOfInterest,d.Continent]);
     
     
     temp.map(d => mapColorSelection.set(d[0],d[1]));

     //console.log(mapColorSelection);
 


      //const countries = topoJsonData.objects.countries;
      g.selectAll('path').data(countries.features)
        .enter().append('path')
          .attr('class', 'country')
          //.attr('d', pathGenerator)
          .attr('d', d=> pathGenerator(d))
          .attr("fill", function(d)
          { 
            var cname = countryName[d.id];

            return color(mapColorSelection.get(cname))}
          )
          .append('title')
          .text(d => countryName[d.id]);


      g.selectAll("path")
      .on("mouseover", onMouseOver) //Add listener for the mouseover event
      .on("mouseout", onMouseOut) //Add listener for the mouseover event
      .on("mousedown", onMouseDown)

      let mapHover2 = new Map();
      coronaData.map(d => mapHover2.set(d.CountryOfInterest,d.Index));


      var IndicationArray = this.IndicationArray;

      var SelectionArray = this.SelectionArray;


      //console.log(IndicationArray);
      var mouseoverstatus = false;
      var mousedownstatus = false;


     function onMouseOver(d:any)
     {

    //   console.log(d.properties.name)
    //   //console.log(this);
    d3.select("title")
    .style("left", (d3.event.pageX) + 10 + "px")
    .style("top", (d3.event.pageY ) + "px")






        mouseoverstatus = true;
        var idx = mapHover2.get(  d.properties.name  ) ;
        //console.log(idx);

        if(idx == undefined){

        }else{
        //console.log(coronaData[idx as number].Hover);
        IndicationArray[idx] = true;
        //console.log(IndicationArray)
        localParentControl.getProxy().getLiveProperty("Indication").setValue(IndicationArray);
        }

     }

     function onMouseOut(d:any)
     {
     
      

      var idx = mapHover2.get(  d.properties.name  ) ;
      //console.log(idx);

      if(idx == undefined){

      }else{
      //console.log(coronaData[idx as number].Hover);
      IndicationArray[idx] = false;
        //console.log(IndicationArray)
        localParentControl.getProxy().getLiveProperty("Indication").setValue(IndicationArray);
      }



     }

     function onMouseDown(d:any)
     {


      SelectionArray = localParentControl.getProxy().getLiveProperty("Selection").getValue();
        //mousedownstatus = true;

        var idx = mapHover2.get(  d.properties.name  ) ;
      //console.log(idx);

      if (idx == undefined) {
      } else 
      {
        //console.log(coronaData[idx as number].Hover);
        if (SelectionArray[idx] == false) {
          SelectionArray[idx] = true;
        } else {
          SelectionArray[idx] = false;
        }

        //console.log(IndicationArray)
        localParentControl
          .getProxy()
          .getLiveProperty("Selection")
          .setValue(SelectionArray);
      }





     }



     function colorLegend(selection, props){
      const {
        color,
        circleRadius,
        spacing,
        textOffset
      } = props;
    
      const groups = selection.selectAll('g')
        .data(color.domain());
      const groupsEnter = groups
        .enter().append('g')
          .attr('class', 'tick');
      groupsEnter
        .merge(groups)
          .attr('transform', (d, i) =>
            `translate(0, ${i * spacing})`
          );
      groups.exit().remove();
    
      groupsEnter.append('circle')
        .merge(groups.select('circle'))
          .attr('r', circleRadius)
          .attr('fill', color)
          .attr("stroke", "black");
    
      groupsEnter.append('text')
        .merge(groups.select('text'))
          .text(d => d)
          .attr('dy', '0.32em')
          .attr('x', textOffset);
    }



    

  
  svg.append('g')
      .attr('transform', `translate(20,150)`)
      .call(colorLegend, {
        color,
        circleRadius: 10,
        spacing: 30,
        textOffset: 10
      });
  


  };
  renderPlot(tsvData, worldMapTopoJson,coronaData);
  document.body.appendChild(div1);

    this.makeDraggable();

  }

}









