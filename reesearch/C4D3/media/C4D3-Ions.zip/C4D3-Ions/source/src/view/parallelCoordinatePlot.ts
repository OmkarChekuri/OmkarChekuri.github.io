
//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.
import * as d3 from 'd3';
import { Draggable } from '../miscellaneous/Draggable.js';
import { printClass } from '../LP/printClass.js';
import { ControlParallelCoordinatePlot } from './ControlParallelCoordinatePlot.js';
import { D3ZoomEvent } from 'd3';
type typeOfValue = string | number | boolean | undefined | null  | Array<boolean> | Array<any>;

export class ParallelCoordinatePlotClass
{
  private width: number = 960;
  private height: number = 480;
  parallelCoordinatePlotName: string;

  private  LocalData: d3.DSVParsedArray<{
    Index: number;
    selectionStatus: boolean;
    Country: string;
    T: number;
    Z: number;
    ActiveCases: number;
    CasesPerMil: number;
    DeathsPerMil: number;
}>;
  //private static xAxis;
  //private static Axis;
  public parentControl: ControlParallelCoordinatePlot;
  inputWidth:number;
  inputHeight:number;

  plotWidth: number;
  plotHeight: number;
  canvasWidth:number;
  yAxis: d3.Selection<SVGGElement, unknown, null, undefined>;
  xAxis: d3.Selection<SVGGElement, unknown, null, undefined>;
  glyph:d3.SymbolType;
  innerWidth: number;
  innerHeight: number;
  xTrans:number;
  yTrans:number;
  previousX: number;
  previousY: any;
  horizontal: number;
  vertical: number;
  xPos:number;
  yPos:number;
  color: d3.ScaleLinear<string, string>;
  Data: any[];
  dims: any;
  helper: any[];
  colorIndex: number;
  parentWindow: HTMLDivElement;
  //margin: { top: number; right: number; bottom: number; left: number; };

  constructor(control: ControlParallelCoordinatePlot, data:Array<any>, name: string, xPos:number,yPos:number, horizontal:number, vertical:number,
    inputWidth:number,inputHeight:number,helper:Array<any>,color:number, dims:Array<any>)
  {
    if (printClass.printStatus) console.log("I am in constructor of ParallelCoordinatePlotClass");
    this.parallelCoordinatePlotName = name;
    this.xPos=xPos;
    this.yPos=yPos;
    this.horizontal = horizontal;
    this.vertical = vertical;
    this.inputWidth = inputWidth;
    this.inputHeight = inputHeight;
    this.parallelCoordinatePlotName = name;
    this.parentControl = control;
   
    this.Data = data;
    this.helper = helper;
    this.colorIndex = color;
    
    this.dims = dims;

    this.render(control);
    this.previousX =0;
    this.previousY =0;

  }
  makeDraggable()
  {
    //create instance of a Draggable class
    var D1 = new Draggable();
    var temp = this.parallelCoordinatePlotName;
    //const myElement: HTMLElement | null = document.getElementById(this.name);
    //check if the element that needs to be made draggable exist, else throw error        
    try
    {

      //if we remove the function() before D1.dragElement then this keyword refers to the html element that we are adding the 
      //event listener on , otherwise this keyword refers to the sliderClass object
      //document.getElementById( SliderClass.sliderControlName + "header")!
      //    .addEventListener('mousedown', D1.dragElement(document.getElementById( this.sliderControlName)), false);

      document.getElementById(this.parallelCoordinatePlotName +"header" )!
        .addEventListener('mousedown', function ()
        { D1.dragElement(document.getElementById(temp)); }, false);
    }
    catch (error)
    {
      throw Error("The Element by id " + this.parallelCoordinatePlotName + " do not exist");
    }
  }

  //************************
  // Getters and Setters
  //************************

  getTranslateX(): typeOfValue
  {
    return this.height;
  }

  getTranslateY(): typeOfValue
  {
    return this.width;
  }

  setSize(value: typeOfValue)
  {
    //console.log("set Size method of parallelCoordinatePlot");
    if (printClass.printStatus) console.log(value);
    
    var temp = value as number;
    //console.log();
    d3.select(`#${this.parallelCoordinatePlotName}`)
    .select("svg")
    .select("g")
    .selectAll("circle")
    .attr("r", temp / 10);

    if (printClass.printStatus) console.log("successfully updated the variable");
    /*  else{
         throw Error("Value not in bounds")
     } */
  }


  
  setOpacity(value: typeOfValue)
  {

    //console.log("setOpacity of ParallelCoordinatePlot");
    var temp = value as number;
    //console.log(temp);

    d3.selectAll("circle").attr("fill-opacity", `${temp/100 }`);


  }



  setIndication(value: Array<any>)
  {
    //console.log("Indication in" + this.parallelCoordinatePlotName);
    var color = this.color;
    if (this.LocalData == undefined)
    {

    }
    else
    {
      
      d3.select(`#${this.parallelCoordinatePlotName}`).select("svg").selectAll("path")
        .data(this.LocalData)
        .attr("fill", function (d,index)
        {         
          //console.log(d.CountryOfInterest)
          return value[index] == true?color(d.Continent):"grey";
        });
    }


  }




  setSelection(value: Array<any>)
  {
    //console.log("serdddt in" + this.parallelCoordinatePlotName);
var color = this.color;
    if (this.LocalData == undefined)
    {

    }
    else
    {
      
      d3.select(`#${this.parallelCoordinatePlotName}`).select("svg").selectAll("path")
        .data(this.LocalData)
        .attr("fill", function (d,index)
        {
          return value[index] == true? color(d.Continent):"grey";
        })
        .attr("stroke-width", function (d,index)
        {
          return value[index] == true? 3:0.2;
        })
        .attr("opacity", function (d,index)
        {
          return value[index] == true?1 : 1;
        });
    }


  }


  private render(parentControl: ControlParallelCoordinatePlot): void
  {
    var localParentControl = parentControl;

    var parentWindow = this.parentWindow;

    //create a div element to hold ParallelCoordinatePlot
    var div1: HTMLDivElement = document.createElement("div");
    div1.id = this.parallelCoordinatePlotName;
    div1.className = "parallelCoordinatePlot"
    var numberPattern = /\d+/g;
    //this.canvasWidth = 360;
    var offset = 20;
    //div1.style.left = (parseInt(this.parallelCoordinatePlotName.match(numberPattern).toString()) -1) *( this.inputWidth + offset) +offset + "px";
    //div1.style.left = Math.random()*2000 + "px";

    

    div1.style.left = this.xPos+ "px";
    div1.style.top  = this.yPos + "px";


    //create a closable icon
    var div0: HTMLButtonElement = document.createElement("button");
    div0.id = "close";
    div0.innerHTML = "X";
    div0.title = "close";
    div0.onclick = function () { div0.parentNode.parentNode.removeChild(div0.parentNode); return false; };
    //div1.appendChild(div0);


    //create a div header for the parallelCoordinatePlot
    var div2 = document.createElement("div");
    div2.id = div1.id + "header";
    div2.className = "parallelCoordinatePlotheader"
    //div2.textContent = div1.id;

    //make the div header a child to the div element
    div1.appendChild(div2);

    //console.log("I am printing D3 Object in ParallelCoordinatePlotClass");
    var d3obj = d3;
    //console.log(d3obj);


    //console.log("check0")

    
var data = this.Data;

    
   const renderplot = (data:any) =>{

    //console.log(data);


   //var dimensions = d3.keys(data[0]).filter(function(d,index) { return (index>0)&&(index<4) })
    //output (3) ["X", "Y", "Z"]
    var dimensions =  this.dims

   //console.log(dimensions);
   var colArray = d3.keys(data[0]).filter(function(d,index) { return d })
    //var colArray = ["d.Index","d.selectionStatus","d.T","d.X","d.Y","d.Z"];
   //console.log(colArray);
    

   
      
      this.LocalData = data;
      var margin = { top: 50, right: 30, bottom: 30, left: 60 };
      this.plotWidth = this.inputWidth - margin.left - margin.right;
      this.plotHeight = this.inputHeight - margin.top - margin.bottom;
      this.innerWidth = this.plotWidth + margin.left + margin.right;
      this.innerHeight =  this.plotHeight + margin.top + margin.bottom; 
      //this.plotWidth = this.plotWidth;
      //this.plotHeight = this.plotHeight;

      var yScale = {};
      var i;
      var name: string;

    //console.log("check1")

      for (i in dimensions) {
        name = dimensions[i]
       
        if ( name == "Continent")
        {
          yScale[name] = d3.scalePoint()
          .domain( data.map(function(d) {
            //console.log(d[name]);
            return d[name]; }) )
          .range([this.plotHeight, 0])
        }else{
        yScale[name] = d3.scaleLinear()
          .domain( d3.extent(data, function(d) { return d[name]; }) )
          .range([this.plotHeight, 0])
        }
        //console.log(yScale[name]);
    
      }

      //console.log("check2")
      // append the svg object to the body of the page
       var svg = d3
                .select(div1)
                .append("svg")
                .attr("width", this.innerWidth)
                .attr("height", this.innerHeight);


      //create a group element for the rest of the plot
       var axisGroup = svg
                  .attr("fill", "orange")
                  .append("g")

                  .attr("class", "axisGroupClass")
                  .attr(
                      "transform",
                      "translate(" + margin.left + "," + margin.top + ")"
                    );

      //console.log("check3")
            // Add grey background lines for context.
        // var background = svg.append("g")
        // .attr("class", "background")
        // .selectAll("path")
        // .data(data)
        // .enter().append("path")
        // .attr("d", path);

        // // Add blue foreground lines for focus.
        // var foreground = svg.append("g")
        // .attr("class", "foreground")
        // .selectAll("path")
        // .data(data)
        // .enter().append("path")
        // .attr("d", path);              


      // Build the X scale -> it find the best position for each Y axis
      var xScale = d3.scalePoint()
      .range([0, this.plotWidth])
      .padding(0.1)
      .domain(dimensions);

      
      //console.log("check3_1")
      // The path function take a row of the csv as input, and return x and y coordinates of the line to draw for this raw.
      function path(d) {
        return d3.line()(dimensions.map(function(p) { return [xScale(p), yScale[p](d[p])]; }));
      }

      //console.log("check3_2")
      
      var colorIndex= this.colorIndex ;
      var item = this.helper[0];

      let color: any;
      if(item(data[0],colorIndex).__proto__ == String.prototype)
      {
         color = d3.scaleOrdinal(data.map((d: any) => (item(d,colorIndex))), ["#8dd3c7","#bebada", "#fb8072","#80b1d3","#ffffb3","#fdb462","#b3de69" ]).unknown(null)
      }else if(item(data[0],colorIndex).__proto__ == Number.prototype)
      {
         color = d3.scaleLinear<string>(d3.extent(data, (d) => (item(d,colorIndex))), ["red", "black"]).unknown(null)
      }

      //var color = d3.scaleOrdinal(data.map((d: any) => (d.Continent)), 
      //["#8dd3c7","#bebada", "#fb8072","#80b1d3","#ffffb3","#fdb462","#b3de69" ]).unknown(null)



      //console.log("check4")



      this.color = color;


     // color(d.T);

      // Draw the lines
  axisGroup
  .selectAll("myPath")
  .data(data)
  .enter().append("path")
  .attr("d",  path)
  .style("fill", "none")
  .style("stroke", function (d) { return color(item(d,colorIndex));; })
  .style("opacity", 1)

      


  // Draw the axis:
  axisGroup.selectAll("myAxis")
    // For each dimension of the dataset I add a 'g' element:
    .data(dimensions).enter()
    .append("g")
    // I translate this element to its right position on the x axis
    .attr("transform", function(d) { return "translate(" + xScale(d) + ")"; })
    // And I build the axis with the call function
    .each(function(d,index) { 
      
     return d3.select(this).call(d3.axisLeft().scale(yScale[d]))//: d3.select(this).call(d3.axisRight().scale(yScale[d]))
    
    
    })
    // Add axis title
    .append("text")
      .style("text-anchor", "center")
      .attr("y", -9)
      .text(function(d) { return d; })
      .style("fill", "black")
      .style("font-size", 15)
      .style("font-weight", 100)

           

    };

    renderplot(data);
    document.body.appendChild(div1);
    this.makeDraggable();

  }

}









