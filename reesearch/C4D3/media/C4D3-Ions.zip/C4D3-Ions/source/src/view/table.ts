//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

//removed active cases from table- 6/6/2020
//commented value checks in set value 06/29/2020
import * as d3 from "d3";
import { Draggable } from "../miscellaneous/Draggable.js";
import { printClass } from "../LP/printClass.js";
import { ControlTable } from "../control/ControlTable.js";
import { typeOfValue } from "../index.js";
//type typeOfValue = string | number | boolean | undefined | null;

export class TableClass {
         private width: number = 960;
         private height: number = 480;
         //plotWidth:number;
         //plotHeight:number;
         tableControlName: string;
         private static dataRows: number;
         //private static LocalData: any[] = [];

         //private static dataCopy: any;

         public parentControl: ControlTable;
         xPos: number;
         yPos: number;
         inputWidth: any;
         inputHeight: any;
         //Data: Array<any>;
         //rowdata: d3.Selection<HTMLTableRowElement, any, HTMLTableSectionElement, unknown>;
         LocalData: any;
         rows: d3.Selection<
           HTMLTableRowElement,
           any,
           HTMLTableSectionElement,
           unknown
         >;

         //SelectionData: any;
         //IndicationData: any;
          SelectionArray:any;
          IndicationArray:any;
          parentWindow: HTMLDivElement;


         constructor(control: ControlTable,name: string,data: Array<any>,xPos: number,yPos: number,inputWidth: number,inputHeight: number)
          {
           if (printClass.printStatus)
             console.log("I am in constructor of tableClass");
           this.tableControlName = name;
           this.parentControl = control;
           this.xPos = xPos;
           this.yPos = yPos;
           this.inputWidth = inputWidth;
           this.inputHeight = inputHeight;
           //this.Data = data;
           //console.log(data)
           this.LocalData = data;
           //IndicationArray = new Array(data1.length);
           //IndicationArray.fill(false,0);

           this.SelectionArray = new Array(data[0].length);
           this.SelectionArray.fill(false,0);

          //console.log(this.SelectionArray)


           this.IndicationArray = new Array(data[0].length);
           this.IndicationArray.fill(false,0);
           
          



           this.render(control, data);
         }
         makeDraggable() {
           //create instance of a Draggable class
           var D1 = new Draggable();
           var temp = this.tableControlName;
          
           try {
             
             document
               //.getElementById(this.tableControlName + "header")!
               .getElementById(this.tableControlName + "header" )!
               .addEventListener(
                 "mousedown",
                 function () {
                   D1.dragElement(document.getElementById(temp));
                 },
                 false
               );
           } catch (error) {
             throw Error(
               "The Element by id " + this.tableControlName + " do not exist"
             );
           }
         }

         //************************
         // Getters and Setters
         //************************

         getHeight(): typeOfValue {
           return this.height;
         }

         getWidth(): typeOfValue {
           return this.width;
         }

         setHeight(value: typeOfValue) {
           if (printClass.printStatus)
             console.log("set Height method of table");
           if (printClass.printStatus) console.log(value);

           //**************************need to implement fire property changed method**********************************
           //this.updateUI();
           if (printClass.printStatus) console.log(this.tableControlName);

           var temp = value as number;

           if (printClass.printStatus) console.log(temp);

           if (printClass.printStatus) console.log();
           d3.select("g")
             .selectAll("circle")
             .attr("r", temp / 10);

           if (printClass.printStatus)
             console.log("successfully updated the variable");
           /*  else{
          throw Error("Value not in bounds")
      } */
         }

         setWidth(value: typeOfValue) {
           if (printClass.printStatus)
             console.log("set width method of Canvas");
           if (printClass.printStatus) console.log(value);
           //if(value>=this.min && value <=this.min){
           //this.width = value;

           //**************************need to implement fire property changed method**********************************
           //this.updateUI();
           if (printClass.printStatus) console.log(this.tableControlName);

           var temp = value as number;

           var xcale = d3.scaleTime().range([0, temp * 50]);
           var xAxis = d3.axisBottom(xcale);
           d3.select(".x-axis").call(xAxis);

           if (printClass.printStatus)
             console.log("successfully updated the variable");
           /*  else{
          throw Error("Value not in bounds")
      } */
         }

         setOpacity(value: typeOfValue) {
           if (printClass.printStatus) console.log("setOpacity of table");
           var temp = value as number;

           d3.select("rect").attr("fill-opacity", `${temp / 100}`);
         }


        setSelection(SelData:any)
        {

          
          if(SelData.length==0){
             
          }else{
            this.SelectionArray = SelData;

            this.updateTable_Selection(this.LocalData,SelData, "Selection")
            

          }
        } 


         updateTable_Selection(dataTable: any[],PropData:any, property:string ) {
           
           var tablebody = d3
             .select(`#${this.tableControlName}`)
             .select("table")
             .select("tbody");

           this.rows = tablebody.selectAll("tr").data(dataTable);

           var cells = this.rows
             .selectAll("td")
             .data(function (d) {
               //console.log(d);
               return Object.values(d);
             })
             .text(function (d) {
               return d;
             })
             

           this.rows
               .style("color", function (d, index) {
              
               if( PropData[index]==true){
                 //console.log(this)
                return "red";
             } else {
               return null;
             }
             })
             
             
         }


         setIndication(IndData:any)
         {
 
         //console.log("Hovering")  
           if(IndData.length==0){
           //console.log("inIndication")
           //console.log(IndData);
         }else{
           this.IndicationArray = IndData;
           this.updateTable_Indication(this.LocalData,IndData, "Indication")
 
         }
 
 
         } 
 

         updateTable_Indication(dataTable: any[],PropData:any, property:string ) {
          //var tablebody = d3.select("#table1");
          //console.log(dataTable);
          var tablebody = d3
            .select(`#${this.tableControlName}`)
            .select("table")
            .select("tbody");

          this.rows = tablebody.selectAll("tr").data(dataTable);

          var cells = this.rows
            .selectAll("td")
            .data(function (d) {
              //console.log(d);
              return Object.values(d);
            })
            .text(function (d) {
              return d;
            })
            

          this.rows
             .attr("class", function (d, index) {
             // d.SelectStatus = (dataTable[index].SelectStatus);
             //console.log("background changed");
             if(PropData[index]==true){
               return "hovered";
            } else {
              return "nothovered";
            }
          })
          
        }

        setHoverSelection(data: any) {
          
        }

        updateTable(dataTable: any[],PropData:any, property:string ) {
          //var tablebody = d3.select("#table1");
          //console.log(dataTable);
          var tablebody = d3
            .select(`#${this.tableControlName}`)
            .select("table")
            .select("tbody");

          this.rows = tablebody.selectAll("tr").data(dataTable);

          var cells = this.rows
            .selectAll("td")
            .data(function (d) {
              //console.log(d);
              return Object.values(d);
            })
            .text(function (d) {
              return d;
            });

          this.rows
           
            .attr("class", function (d, index) {
             
             if(property=="Indication" && PropData[index]==true){
               return "hovered";
            } else {
              return "nothovered";
            }
          })
           .style("font-family", function (d, index) {
              
               if(property=="Selection" && PropData[index]==true){
                return "cursive";
             } else {
               return "serif";
             }
               
             })
            .style("color", function (d, index) {
             
              if(property=="Selection" && PropData[index]==true){
                //console.log(this)
               return "red";
            } else {
              return null;
            }
            })
            
        }

         private render(parentControl: ControlTable, Data: any[]): void {
           var localParentControl = parentControl;

           
           //create a div element to hold table
           var div1: HTMLDivElement = document.createElement("div");
           div1.id = this.tableControlName;
           //console.log(div1.id);
           div1.className = "table";
           
           div1.style.left = this.xPos + "px";
           div1.style.top = this.yPos + "px";

           

           //create a div header for the table
           var div2 = document.createElement("div");
           div2.id = div1.id + "header";
           div2.className = "tableheader";
          

           //make the div header a child to the div element
           div1.appendChild(div2);

           let data1 = Data[0];
         

           var IndicationArray = this.IndicationArray;

           var SelectionArray = this.SelectionArray
           
           localParentControl.getProxy().getLiveProperty("Selection").setValue(SelectionArray);

           this.LocalData = [];
           //console.log(this.LocalData);
           this.LocalData = data1;
           //console.log(this.LocalData);

           const renderTable = (data: any[]) => {
             //console.log(data);
             var LocalData = data;
             

             var margin = { top: 60, right: 30, bottom: 30, left: 60 };
             var plotWidth = this.inputWidth - margin.left - margin.right;
             var plotHeight = this.inputHeight - margin.top - margin.bottom;

             var table = d3
               .select(div1)
               .append("table")
               .style("border-collapse", "collapse")
               .style("border", "0.5px solid black")
               .attr("width", plotWidth + margin.left)
               .attr("height", plotHeight + margin.top + margin.bottom)
               .attr(
                 "transform",
                 "translate(" + margin.left + "," + margin.top + ")"
               )
               .attr("border", 1);

             var header = table.append("thead").append("tr");

             //console.log(Object.keys(data));
             header
               .selectAll("th")
               .data(Object.keys(data[0]))
               .enter()
               .append("th")
               .text(function (d) {
                 return d;
               })
               .style("font-size", "14px");

             var tablebody = table.append("tbody");

             this.rows = tablebody
               .selectAll("tr")
               .data(data)
               .enter()
               .append("tr")
               .style("font-family", "serif")
               .style("font-size", "13px");


          
           

            var color = d3.scaleOrdinal( data.map((d: any) => (d.Continent)),
      ["#8dd3c7","#bebada", "#fb8072","#80b1d3","#ffffb3","#fdb462","#b3de69" ]).unknown(null)



             var cells = this.rows
               .selectAll("td") // each row has data associated; we get it and enter it for the cells.
               .data(function (d) {
                 //console.log(Object.values(d));
                 return Object.values(d);
               })
               .enter()
               .append("td")
               .text(function (d) {
                 return d;
               })
               .style("background", function(d,index){
                
                if(index == 2)
                {
                  //console.log( d + " " +color(d));
                  return color(d)
                }
                else{
                  return null;
                }
               });;








             var mouseoverstatus = false;
             var mousedownstatus = false;
             this.rows
               .on("mouseover", function (d,index) {
                 //console.log("mouseover")
                 updateMouseOver(d,index);
               })
               .on("mouseout", function (d,index) {
                //console.log("mouseout")
                 updateMouseOut(d,index);
               })
               .on("mousedown", function (d,index) {
                //console.log("mousedown")
                 updateMouseDown(d,index);
               })
               .on("mouseup", function (d) {
                //console.log("mouseup")
                 mousedownstatus = false;
               })
               


            

             function updateMouseOver(d: any,index:number) {
               
              mouseoverstatus = true;
              IndicationArray[index] = true;
              localParentControl.getProxy().getLiveProperty("Indication").setValue(IndicationArray);
               //localParentControl.getProxy().getLiveProperty("Data").setValue(data);
               updateDrag(d,index);
             }

             function updateMouseOut(d: any,index:number) {
               IndicationArray[index] = false;
               localParentControl.getProxy().getLiveProperty("Indication").setValue(IndicationArray);
               //localParentControl.getProxy().getLiveProperty("Data").setValue(data);
             }

             function updateMouseDown(d: any,index:number) {
               mousedownstatus = true;
               updateDrag(d,index);
             }

             function updateDrag(d:any,index:number) {
               if (mousedownstatus == true && mouseoverstatus == true) {

                
                 SelectionArray = localParentControl.getProxy().getLiveProperty("Selection").getValue();

                 if(SelectionArray[index] ==false){
                  
                  SelectionArray[index] = true;
                  
                }
                 else{
                   
                  SelectionArray[index] = false;
                 
                 }

                localParentControl.getProxy().getLiveProperty("Selection").setValue(SelectionArray);
                
               }
             }
           };

           renderTable(data1);

           //this.dataCopy = dat;
           document.body.appendChild(div1);
           this.makeDraggable();
         }
       }

