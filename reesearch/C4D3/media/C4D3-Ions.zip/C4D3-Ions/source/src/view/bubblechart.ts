//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import * as d3 from 'd3';
import { Draggable } from '../miscellaneous/Draggable.js';
import { printClass } from '../LP/printClass.js';
import { ControlBubblechart } from '../control/ControlBubblechart.js';
import { D3ZoomEvent } from 'd3';
type typeOfValue = string | number | boolean | undefined | null | Array<boolean> | Array<any>;

export class BubbleChartClass
{
  private width: number = 960;
  private height: number = 480;
  bubblechartControlName: string;

  private LocalData: d3.DSVParsedArray<{}>;
  //private static xAxis;
  //private static Axis;
  public parentControl: ControlBubblechart;
  inputWidth: number;
  inputHeight: number;

  //plotWidth: number;
  //plotHeight: number;
  canvasWidth: number;
  yAxis: d3.Selection<SVGGElement, unknown, null, undefined>;
  xAxis: d3.Selection<SVGGElement, unknown, null, undefined>;
  glyph: d3.SymbolType;
  innerWidth: number;
  innerHeight: number;
  xTrans: number;
  yTrans: number;
  previousX: number;
  previousY: any;
  horizontal: number;
  vertical: number;
  xPos: number;
  yPos: number;
  showHoriz: boolean = true;
  showVerti: boolean = true;
  yScale: d3.ScaleLinear<number, number>;
  xScale: d3.ScaleLinear<number, number>;
  Data:Array<any>;
  bubblechart: d3.Selection<SVGGElement, unknown, null, undefined>;
  helper: any[];
  colorIndex: number;
  circleSizeIndex: number;
  textIndex: number;


  SelectionArray:any;
  IndicationArray:any;
  colorscheme: d3.ScaleOrdinal<string, unknown>;
  parentWindow: HTMLDivElement;

  //margin: { top: number; right: number; bottom: number; left: number; };

  constructor(control: ControlBubblechart,data:Array<any>, name: string, xPos: number, yPos: number, inputWidth: number, inputHeight: number,
     helper:Array<any>,color:number,size:number,text:number)
  {
    if (printClass.printStatus) console.log("I am in constructor of BubbleChartClass");
    this.bubblechartControlName = name;
    this.inputWidth = inputWidth;
    this.inputHeight = inputHeight;
    this.bubblechartControlName = name;
    this.colorIndex = color;
    this.circleSizeIndex = size;
    this.textIndex = text;
    

this.SelectionArray = new Array(data.length);
           this.SelectionArray.fill(false,0);

this.IndicationArray = new Array(data.length);
           this.IndicationArray.fill(false,0);


    this.parentControl = control;
    

    this.previousX = 0;
    this.previousY = 0;
    this.xPos = xPos;
    this.yPos = yPos;
    this.Data = data;
    this.helper = helper;
    this.render(control);

  }
  makeDraggable()
  {
    //create instance of a Draggable class
    var D1 = new Draggable();
    var temp = this.bubblechartControlName;
         
    try
    {

      document.getElementById(this.bubblechartControlName + "header")!
        .addEventListener('mousedown', function ()
        { D1.dragElement(document.getElementById(temp)); }, false);
    }
    catch (error)
    {
      throw Error("The Element by id " + this.bubblechartControlName + " do not exist");
    }
  }

  //************************
  // Getters and Setters
  //************************

  getTranslateX(): typeOfValue
  {
    return this.height;
  }

  getTranslateY(): typeOfValue
  {
    return this.width;
  }

 

  

  setOpacity(value: typeOfValue)
  {
    var temp = value as number;
    d3.selectAll("circle").attr("fill-opacity", `${temp / 100}`);
  }

  setSelection(value: Array<any>)
  {

   
    var color = this.colorscheme;
    
    if (this.LocalData == undefined){
      console.log("undefined")
    }
    else
    {
      d3.select(`#${this.bubblechartControlName}`).select("svg").selectAll("circle")
       
        .attr("fill", function (d,index) {        
          return value[index] == true ? "#cccccc" : color(d.Continent);})
       
    }
  }

  setIndication(value: Array<any>)
  {
    
         
    if (this.LocalData == undefined){    }
    else
    {

      d3.select(`#${this.bubblechartControlName}`)
        .select("svg").selectAll("circle")
        .data(this.LocalData)
         .attr("stroke",function (d,index){return value[index] == true?"white":null; })
        .attr("stroke-width", function (d,index){return value[index] == true? 6:0.5; });


    }
        


    
  } 

  
  private render(parentControl: ControlBubblechart): void
  {
    var localParentControl = parentControl;

    var parentWindow = this.parentWindow;
    //create a div element to hold bubblechart
    var div1: HTMLDivElement = document.createElement("div");
    div1.id = this.bubblechartControlName;
    div1.className = "bubblechart"
    var numberPattern = /\d+/g;
    //this.canvasWidth = 360;
    var offset = 20;
    //div1.style.left = (parseInt(this.bubblechartControlName.match(numberPattern).toString()) -1) *( this.inputWidth + offset) +offset + "px";
    //div1.style.left = Math.random()*2000 + "px";

    div1.style.left = this.xPos + "px";
    div1.style.top = this.yPos + "px";

    //create a closable icon
    // var div0: HTMLButtonElement = parentWindow.document.createElement("button");
    // div0.id = "close";
    // div0.innerHTML = "X";
    // div0.title = "close";
    // div0.onclick = function () { div0.parentNode.parentNode.removeChild(div0.parentNode); return false; };
    //div1.appendChild(div0);


    //create a div header for the bubblechart
    var div2 = document.createElement("div");
    div2.id = div1.id + "header";
    div2.className = "bubblechartheader";
    //div2.textContent = div1.id;

    //make the div header a child to the div element
    div1.appendChild(div2);



    var data = this.Data;

    const renderPlot = (data:any ) =>
    {
      
      var colArray = Object.keys(data[0]);
      var colorIndex= this.colorIndex ;
      var circleSizeIndex = this.circleSizeIndex ;
      

      var item = this.helper[0];
      
      function Label(index:number){  return  colArray[index] + "→"; }
    
      

      this.LocalData = data;
      var margin = { top: 60, right: 15, bottom: 60, left: 60 };
      var plotWidth = this.inputWidth - margin.left - margin.right;
      var plotHeight = this.inputHeight - margin.top - margin.bottom;
      this.innerWidth = plotWidth + margin.left + margin.right;
      this.innerHeight = plotHeight + margin.top + margin.bottom;

      var width = this.innerWidth;
      var height = this.innerHeight;
      var IndicationArray = this.IndicationArray;
      var SelectionArray = this.SelectionArray


      // append the svg object to the body of the page
      var svg = d3
        .select(div1)
        .append("svg")
        .attr("class","vertical")
        //.attr("fill", )
        .attr("width", this.innerWidth)
        .attr("height", this.innerHeight)
        
        var dropdown = d3.select(div1)
        .insert("select", "svg")
        .attr("id","sizeSelector")
        .attr('transform', `translate(120,30)`)
        .on("change", changed);


        
        var dropDownArrar = [{variable: "Radius:CasesPerMillion", Index:"8"},
                            {variable: " Radius:DeathsPerMillion", Index:"9"},
                            {variable: " Radius:TestsPerMillion", Index:"6"}]

        dropdown
            .selectAll("option")
            .data(dropDownArrar)
            .enter().append("option")
            .text(function(d) { return d.variable; })
            .attr("value", function (d) { return d.Index; })  

      function changed(d:any) {

             
              console.log(d3.select(this).property("value"));
              var index =d3.select(this).property("value"); 

              var circleSize1 = d3.scaleSqrt()
              .domain(d3.extent(data, function(d){ return(item(d,index))}))
              .range([ 0, 30]);

              svg.selectAll("circle")
              .data(data)
              .attr("r", function(d) {
                return   circleSize1(item(d,index))
              })


              var simulation1 = d3.forceSimulation()
              .force("x", d3.forceX(width/2).strength(0.1))
              .force("y", d3.forceY(height/1.7).strength(0.1))
              .force("collide", d3.forceCollide(function(d){
                return circleSize1(item(d,index)) +1;
              })) 
        
              simulation1.nodes(data)
              .on('tick',ticked);


            }
        

        var circleSize = d3.scaleSqrt()
        .domain(d3.extent(data, function(d){ return(item(d,circleSizeIndex))}))
        .range([ 0, 30]);


      var color = d3.scaleOrdinal(data.map(function(d: any){return (d.Continent)}), 
      ["#8dd3c7","#bebada", "#fb8072","#80b1d3","#ffffb3","#fdb462","#b3de69" ]).unknown(null)

      this.colorscheme = color;

      var simulation = d3.forceSimulation()
      .force("x", d3.forceX(width/2).strength(0.1))
      .force("y", d3.forceY(height/1.7).strength(0.1))
      .force("collide", d3.forceCollide(function(d){
        return circleSize(item(d,circleSizeIndex)) +1;
      })) 



        var circles = svg.selectAll(".country")
        .data(data)
        .attr("id", `"${this.bubblechartControlName}leaf"`)
        .enter().append("circle")
        .attr("class","country")
        .attr("r", function(d) {
          return   circleSize(item(d,circleSizeIndex))
        })
        .attr("fill", function(d){
          return color(item(d,colorIndex))
        })
        .on("mouseover", function(d,index){
          onMouseOver(d,index)
        }) 
        .on("mouseout", function(d,index){
          onMouseOut(d,index)
        }) 
        .on("mousedown", function(d,index){
          onMouseDown(d,index)
        }) 
        

        var mouseoverstatus = false;
        var mousedownstatus = false;

       function onMouseOver(d:any,index:number){

        
        mouseoverstatus = true;
        IndicationArray[index] = true;
        localParentControl.getProxy().getLiveProperty("Indication").setValue(IndicationArray);


       }


       function onMouseOut(d:any,index:number){
        
        IndicationArray[index] = false;
        localParentControl.getProxy().getLiveProperty("Indication").setValue(IndicationArray);
      }


      function onMouseDown(d:any,index:number){
       
        SelectionArray = localParentControl.getProxy().getLiveProperty("Selection").getValue();

        if (SelectionArray[index] == false) {
          SelectionArray[index] = true;
        } else {
          SelectionArray[index] = false;
        }
        console.log(SelectionArray)
        localParentControl.getProxy().getLiveProperty("Selection").setValue(SelectionArray);



      }




        simulation.nodes(data)
        .on('tick',ticked);

      function ticked()
      {
        circles
          .attr("cx", function (d)
          {
            return d.x;
          })
          .attr("cy", function (d)
          {
            return d.y;
          })
        
        }




        function colorLegend(selection:any, props:any){
          const {
            color,
            side,
            spacing,
            textOffset
          } = props;
        
          const groups = selection.selectAll('g')
            .data(color.domain());
          const groupsEnter = groups
            .enter().append('g')
              .attr('class', 'tick');
          groupsEnter
            .merge(groups)
              .attr('transform', (d: any, i: number) =>
                `translate( 0,${i * spacing[i]})`
              );
          groups.exit().remove();
        
          groupsEnter.append('rect')
              .merge(groups.select('rect'))
                .attr('width', side)
                .attr('height', side)
                .attr('x', 0)
                .attr('y', -8)
                .attr('fill', color)
                .attr("stroke","black");
      
          groupsEnter.append('text')
            .merge(groups.select('text'))
              .text((d: any) => d)
              .attr('dy', '0.32em')
              .attr('x', textOffset);
        }
  
      svg.append('g')
          .attr('transform', `translate(10,10)`)
          .call(colorLegend, {
            color,
            side:15,
            spacing: [20,20,20,20,20,20,20],
            textOffset: 20
          });

  



    d3.select("#selectButton").on("change", function(d) {
            // recover the option that has been chosen
            var selectedOption = d3.select(this).property("value")
           
        })   




    };


    renderPlot(data);
    document.body.appendChild(div1);

    this.makeDraggable();

  }

}



