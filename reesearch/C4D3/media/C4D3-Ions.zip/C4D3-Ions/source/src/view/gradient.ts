

//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.


import * as d3 from 'd3';
import { Draggable } from '../miscellaneous/Draggable.js';
import { printClass } from '../LP/printClass.js';
import { ControlGradient } from '../control/ControlGradient.js';
import { D3ZoomEvent } from 'd3';
type typeOfValue = string | number | boolean | undefined | null | Array<boolean> | Array<any>;

export class GradientClass
{
  setSelection(arg0: any[])
  {
      //throw new Error("Method not implemented.");
  }
  private width: number = 960;
  private height: number = 480;
  gradientControlName: string;

  //private static xAxis;
  //private static Axis;
  public parentControl: ControlGradient;
  inputWidth: number;
  inputHeight: number;

  //plotWidth: number;
  //plotHeight: number;
  canvasWidth: number;
  yAxis: d3.Selection<SVGGElement, unknown, null, undefined>;
  xAxis: d3.Selection<SVGGElement, unknown, null, undefined>;
  glyph: d3.SymbolType;
  innerWidth: number;
  innerHeight: number;
  xTrans: number;
  yTrans: number;
  previousX: number;
  previousY: any;
  horizontal: number;
  vertical: number;
  xPos: number;
  yPos: number;
  showHoriz: boolean = true;
  showVerti: boolean = true;
  yScale: d3.ScaleLinear<number, number>;
  xScale: d3.ScaleLinear<number, number>;
  helper: any[];
  Data: any[];
  //margin: { top: number; right: number; bottom: number; left: number; };

  constructor(control: ControlGradient, name: string, data:Array<any>, xPos: number, yPos: number, 
    horizontalAxisIndex: number,  inputWidth: number, inputHeight: number,
    showHoriz: boolean, showVerti: boolean,helper:Array<any>)
  {
    if (printClass.printStatus) console.log("I am in constructor of GradientClass");
    this.gradientControlName = name;
    //this.glyph = symbol;// as unknown as d3.SymbolType;
    this.horizontal = horizontalAxisIndex;
    this.inputWidth = inputWidth;
    this.inputHeight = inputHeight;
    this.gradientControlName = name;
    this.parentControl = control;
    this.helper = helper;
    this.Data = data;
    if (printClass.printStatus) console.log("let's see");
    if (printClass.printStatus) console.log(control);

    this.previousX = 0;
    this.previousY = 0;
    this.xPos = xPos;
    this.yPos = yPos;
    this.showHoriz = showHoriz;
    this.showVerti = showVerti;
    this.render(control);

  }
  makeDraggable()
  {
    //create instance of a Draggable class
    var D1 = new Draggable();
    var temp = this.gradientControlName;
    //const myElement: HTMLElement | null = document.getElementById(this.name);
    //check if the element that needs to be made draggable exist, else throw error        
    try
    {

       document.getElementById(this.gradientControlName + "header")!
        .addEventListener('mousedown', function ()
        { D1.dragElement(document.getElementById(temp)); }, false);
    }
    catch (error)
    {
      throw Error("The Element by id " + this.gradientControlName + " do not exist");
    }
  }

  //************************
  // Getters and Setters
  //************************

  getTranslateX(): typeOfValue
  {
    return this.height;
  }

  getTranslateY(): typeOfValue
  {
    return this.width;
  }

  
  private render(parentControl: ControlGradient): void
  {
    var localParentControl = parentControl;


    //create a div element to hold gradient
    var div1: HTMLDivElement = document.createElement("div");
    div1.id = this.gradientControlName;
    div1.className = "gradient"
    var numberPattern = /\d+/g;
    //this.canvasWidth = 360;
    var offset = 20;
    //div1.style.left = (parseInt(this.gradientControlName.match(numberPattern).toString()) -1) *( this.inputWidth + offset) +offset + "px";
    //div1.style.left = Math.random()*2000 + "px";

    div1.style.left = this.xPos + "px";
    div1.style.top = this.yPos + "px";

    //create a closable icon
    var div0: HTMLButtonElement = document.createElement("button");
    div0.id = "close";
    div0.innerHTML = "X";
    div0.title = "close";
    div0.onclick = function () { div0.parentNode.parentNode.removeChild(div0.parentNode); return false; };
    //div1.appendChild(div0);


    //create a div header for the gradient
    var div2 = document.createElement("div");
    div2.id = div1.id + "header";
    div2.className = "gradientheader";
    //div2.textContent = div1.id;

    //make the div header a child to the div element
    div1.appendChild(div2);

    var data = this.Data;
    var item = this.helper[0];
    


    const renderPlot = (data: any) => {
      //console.log(data);

      var colArray = Object.keys(data[0]);
      var horizontal = this.horizontal ;
      var vertical = this.vertical ;
      var item = this.helper[0];

      var SelectionArray = new Array(data.length);
      SelectionArray.fill(false,0);

      this.LocalData = data;
      var plotWidth = this.inputWidth 
      var plotHeight = this.inputHeight
     

      // append the svg object to the body of the page
      var svg = d3
        .select(div1)
        .append("svg")
        .attr("fill", "orange")
        .attr("width", plotWidth)
        .attr("height", plotHeight);

     
      //create a linear xScale
      var xScale = d3
        .scaleLinear()
        .domain(d3.extent(data, function (d) { return item(d,horizontal); }))
        .range([0, plotWidth])
        

      this.xScale = xScale;

      this.xAxis = svg
        .append("g")
        .attr("transform", "translate(0," + plotHeight + ")");



        this.xAxis.call(d3.axisBottom(xScale));


      var color = d3
        .scaleLinear<string>()
        .domain(d3.extent(data, function (d) { return item(d,horizontal); }))
        .range(["red", "black"]);


        //https://www.visualcinnamon.com/2016/05/smooth-color-legend-d3-svg-gradient.html
       var defs = svg.append("defs");

      var gradient = defs
        .append("linearGradient")
        .attr("id", "svgGradient")
        .attr("x1", "0%")
        .attr("y1", "0%")
        .attr("x2", "100%")
        .attr("y2", "0%");

      gradient
        .append("stop")
        //.data(data)
        .attr("class", "start")
        .attr("offset", "0%")
        //.attr("stop-color",function(d){return color(d.T)})
        .attr("stop-color", "red")
        .attr("stop-opacity", 1);

      gradient
        .append("stop")
        //.data(data)
        .attr("class", "end")
        .attr("offset", "100%")
        //.attr("stop-color",function(d){return color(d.T)})
        .attr("stop-color", "black")
        .attr("stop-opacity", 1);

      svg
        .append("rect")
        .attr("width", plotWidth)
        .attr("height", plotHeight)
        .style("fill", "url(#svgGradient)");



      //brushed over the gradient
      function brushed() {
        
        const selection = d3.event.selection;
        const [x0, x1] = selection;

        console.log()

        console.log(selection);
        console.log([xScale.invert(x0), xScale.invert(x1)] )

        var SelectionArray = data.map(function(d: { T: number; })     
        {
          return  d.T >= xScale.invert(x0) && d.T <= xScale.invert(x1)
        })
        
                 
        localParentControl.getProxy().getLiveProperty("Selection")
          .setValue(SelectionArray);
      }

      var brush = d3.brushX().on(" start brush  ", brushed);

      // Add the brushing
      svg.append("g").call(brush);
    };

    renderPlot(data);
    document.body.appendChild(div1);

    this.makeDraggable();

  }

}









