/*    C4D3 is free software: you can redistribute it and/or modify it under
 the terms of the GNU Affero General Public License as published by the Free
 Software Foundation, either version 3 of the License, or (at your option) any
 later version.

 This file is distributed in the hope that it will be useful, but WITHOUT
 ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 details.

 You should have received a copy of the GNU Affero General Public License
 along with this program. If not, see <http://www.gnu.org/licenses/>. */

step 1: navigate to C4D3-Ions folder

step 2: install typescript globally by using the command "npm install -g typescript".

step 3: run npm install

step 4: run "tsc -w"

step 5: run "npm start"

step 6: close the window with address http://127.0.0.1:8080/

step 7:install live server plugin in vscode if not installed

step 8: rightclick on the  "index.html" file in build folder and select run with live server.

step 7: Go to source folder and create/modify the existing view classes in the view folder or 
control classes in the control as necessary



The source folder contains the following
- index.ts file that is necessary for building the visualization.
- control folder with controls for the views
- LP folder with coordination architecture 
- view folder for creating wrappers for D3 views
- other helper functions for UI management in miscellaneous folder


The build folder contains the following
- index.ts file that is necessary for building the visualization.
- dst folder compiled typescript files 
- other files for loading the webpage