//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.


import { Variable } from "./LP/Variable.js";
import { Prototype } from "./LP/Prototype.js";
import { ControlSlider } from "./control/ControlSlider.js";
import { ControlPixel } from "./control/ControlPixel.js";
import { ControlCanvas } from "./control/ControlCanvas.js";
import { printClass } from "./LP/printClass.js";
import { ControlScatterplot } from "./control/ControlScatterplot.js";
import { ControlTable } from "./control/ControlTable.js";
import { ControlParallelCoordinatePlot } from "./control/ControlParallelCoordinatePlot";
import * as d3 from "d3";
import { ControlGradient } from "./control/ControlGradient.js";
import { ControlMap } from "./control/ControlMap.js";
import { ControlBubblechart } from "./control/ControlBubbleChart.js";
export type typeOfValue = string | number | boolean | undefined | null | Array<boolean> | Array<any>;
type controlType = "slider" | "pixel" | "canvas" | "textArea"|"bubblechart" | "scatterplot" | "gradient" | "map" | "bargraph" | "table" | "insetScatterplot" | "parallelCoordinatePlot";

let sliderCounter: number = 0;
let pixelCounter: number = 0;

function createControl(controlName: controlType, data: Array<any>, name: string, xPos?: number, yPos?: number,
    symbol?: d3.SymbolType, horizontalAxes?: number, verticalAxes?: number,
    inputWidth?: number, inputHeight?: number, showHoriz?: boolean, showVerti?: boolean, helper?:Array<any>,color?:number,size?:number,text?:number,dims?:Array<any>)
{
    if (printClass.printStatus) console.log("Next Step: Control Creation**************(( " + controlName + " ))**************");
    if (controlName == "slider")
    {
        let sliderControl = new ControlSlider(name, xPos, yPos);
        return sliderControl;
    }
    else if (controlName == "pixel")
    {
        let pixelControl = new ControlPixel(name);
        return pixelControl;
    }
    else if (controlName == "canvas")
    {
        let canvasControl = new ControlCanvas(name);
        return canvasControl;
    }
    else if (controlName == "scatterplot")
    {
        let scatterplotControl = new ControlScatterplot(name, data, xPos, yPos, horizontalAxes, verticalAxes, inputWidth, inputHeight,
             showHoriz, showVerti,helper,color,size,text);
        return scatterplotControl;
    }
    else if (controlName == "map")
    {
        let mapControl = new ControlMap(name, data, xPos, yPos, inputWidth, inputHeight);
        return mapControl;
    }
    else if (controlName == "bubblechart")
    {
        let bubblechartControl = new ControlBubblechart(name, data, xPos, yPos, inputWidth, inputHeight,helper,color,size,text);
        return bubblechartControl;
    }
    else if (controlName == "gradient")
    {
        let gradientControl = new ControlGradient(name, data, xPos, yPos, horizontalAxes, inputWidth, inputHeight, helper);
        return gradientControl;
    }
    
    else if (controlName == "table")
    {
        let tableControl = new ControlTable(name, data, xPos, yPos, inputWidth, inputHeight);
        return tableControl;
    }
    else if (controlName == "parallelCoordinatePlot")
    {
        let parallelCoordinatePlotControl = new ControlParallelCoordinatePlot(name,data, xPos, yPos, inputWidth, inputHeight,helper,color,dims);
        return parallelCoordinatePlotControl;
    }
    else
    {
        throw Error("Control Doesnot exist yet")
    }
}




function createVariable(variableName: string, value: typeOfValue, classtype: any)
{
    if (printClass.printStatus) console.log("Next Step:Variable Creation*************(( " + variableName + " ))***********");
    if (printClass.printStatus) console.log(value);
    
    let CUR_TAG: string = "Value";

    //if you don't want to pass parameters use placeholder undefined
    let CUR_VALUE: Prototype = new Prototype(classtype, CUR_TAG, undefined, undefined);
    if (printClass.printStatus) console.log(CUR_VALUE);
    let variable = new Variable(CUR_VALUE, variableName, value);

    return variable;

}


function bindVariable(control: ControlPixel | ControlSlider | ControlBubblechart|ControlCanvas | ControlScatterplot | ControlGradient | ControlTable |  ControlParallelCoordinatePlot | ControlMap, property: string, variable: Variable)
{
   
   
    if (printClass.printStatus) console.log("Next step: Binding (( " + variable.name + " )) to (( " + control.ControlName + " ))");
    control.proxy.setVariable(property, variable);
   
}



//Define Control Types
let Slider_type: controlType = "slider";
let Pixel_type: controlType = "pixel";
let Scatterplot_type: controlType = "scatterplot";
let Gradient_type: controlType = "gradient";
let Table_type: controlType = "table";
let Map_type: controlType = "map";
let BarGraph_type: controlType = "bargraph";
let ParallelCoordinatePlot_type: controlType = "parallelCoordinatePlot";
let Bubblechart_type: controlType = "bubblechart";


//Load Data sets
Promise.all([d3.tsv("./data/110m.tsv"),
d3.json("./data/countries-110m.json"),
d3.csv("./data/covid1907082020.csv", ({ Index, CountryOfInterest, TotalCases, TotalDeaths, 
    CasesPerMil, DeathsPerMil, TotalTests, TestsPerMil, Population, Continent,RandomX,RandomY }, index) =>
    ({
        Index: +index,
        
        CountryOfInterest: CountryOfInterest,
        Continent: Continent,
        TotalCases: +(TotalCases.replace(/,/g, "")),
        TotalDeaths: +(TotalDeaths.replace(/,/g, "")),
        TotalTests: +(TotalTests.replace(/,/g, "")),
        TestsPerMil: +(TestsPerMil.replace(/,/g, "")),
        Population: +(Population.replace(/,/g, "")),
        CasesPerMillion: +(CasesPerMil.replace(/,/g, "")),
        DeathsPerMillion: +(DeathsPerMil.replace(/,/g, "")),
        
        
    }))
]).then(
([tsvData, worldMapTopoJson, covid19Data]) =>
{

    let covid19Variables = { Index: 0,
                            CountryOfInterest: 1,
                            Continent: 2,
                            TotalCases: 3,
                            TotalDeaths: 4,
                            TotalTests: 5,
                            TestsPerMil: 6,
                            Population: 7,
                            CasesPerMil:8,
                            DeathsPerMil:9,
                        
                        };

    let IonsVariables = { Index:0, T: 1, X: 2, Y: 3, Z: 4 };

    //lookup for items
    function covid19Axes(d:{Index:number,CountryOfInterest: string, Continent: string,TotalCases: number, TotalDeaths: number, TestsPerPopulation:number,
                            TotalTests: number, TestsPerMil: number, Population: number, CasesPerMillion:number,DeathsPerMillion:number,X_Value:number,Y_Value:number }, idx: number)
                            {
                                

                                if (idx == 0){ return d.Index }
                                else if (idx == 1) {return d.CountryOfInterest}
                                else if (idx == 2) {return d.Continent}
                                else if (idx == 3) {return d.TotalCases}
                                else if (idx == 4) {return d.TotalDeaths}
                                else if (idx == 5) {return d.TotalTests}
                                else if (idx == 6) {return d.TestsPerMil}
                                else if (idx == 7) {return d.Population}
                                else if (idx == 8) {return d.CasesPerMillion}
                                else if (idx == 9) {return d.DeathsPerMillion}
                                
                            }




    //Create covid19 visualization
    function covid19Example(){
            
        let Top = 150
        let Left = 30;
        let ScatterWidth = 300;
        let ScatterHeight = 250;
        let TableWidth = 325;
        let TableHeight = 2*ScatterHeight +5;
        let MapWidth = 2*ScatterWidth ;
        var parentName = "covid19Viz"

        let Selection_1 = createVariable("Selection_1", [], Array.prototype);
        let Selection_2 = createVariable("Selection_2", [], Array.prototype);
        let Selection_3 = createVariable("Selection_3", [], Array.prototype);
        let Indication_1 = createVariable("Indication_1", [], Array.prototype);
        let Data_1 = createVariable("Data_1", covid19Data, Array.prototype);
        
        //variables for axis
        let Translation_1 = createVariable("Translation_1", [0], Array.prototype);
        let Translation_2 = createVariable("Translation_2", [0], Array.prototype);
        let Translation_3 = createVariable("Translation_3", [0], Array.prototype);


        let scatterplot1 = createControl( Scatterplot_type, covid19Data, "SP-1", Left, Top, null,   covid19Variables.TestsPerMil,covid19Variables.CasesPerMil,
        ScatterWidth, ScatterHeight, true, true,[covid19Axes],covid19Variables.Continent,covid19Variables.Population,covid19Variables.CountryOfInterest );
        bindVariable(scatterplot1, "xTranslate", Translation_1);
        bindVariable(scatterplot1, "yTranslate", Translation_3);
        bindVariable(scatterplot1, "Selection", Selection_1);
        bindVariable(scatterplot1, "Indication", Indication_1);
        //bindVariable(scatterplot1, "Zoom", variable9);

        let scatterplot2 = createControl(Scatterplot_type, covid19Data, "SP-2", Left , Top + ScatterHeight ,null,  covid19Variables.DeathsPerMil,covid19Variables.TestsPerMil,
        ScatterWidth, ScatterHeight, true, true,[covid19Axes],covid19Variables.Continent,covid19Variables.Population,covid19Variables.CountryOfInterest  );
        bindVariable(scatterplot2, "xTranslate", Translation_2);
        bindVariable(scatterplot2, "yTranslate", Translation_1);
        bindVariable(scatterplot2, "Indication", Indication_1);
        bindVariable(scatterplot2, "Selection", Selection_2);


        let table10 = createControl(Table_type, [covid19Data], "TableView",  Left + ScatterWidth +2 , Top, null, null, null, 
        TableWidth, TableHeight  ,null,null, null,null,null,null);
        bindVariable(table10, "Selection", Selection_2);
        bindVariable(table10, "Indication", Indication_1);

        let Map1 = createControl(Map_type, [tsvData, worldMapTopoJson, covid19Data], "Map", Left + ScatterWidth + TableWidth -26, Top , d3.symbolDiamond, IonsVariables.Z, IonsVariables.Y,
        MapWidth, 2*ScatterHeight , false, false,null,null,null,null);
        bindVariable(Map1, "Data", Data_1);
        bindVariable(Map1, "Selection", Selection_1);
        bindVariable(Map1, "Indication", Indication_1);


        let bubblechart1 = createControl(Bubblechart_type, covid19Data, "BC-1",Left+ ScatterWidth + TableWidth +MapWidth -25 , Top , null,   null, null,
        ScatterWidth*1.2, TableHeight -20 , true, true,[covid19Axes],covid19Variables.Continent,covid19Variables.CasesPerMil,covid19Variables.CountryOfInterest  );
        bindVariable(bubblechart1, "Selection", Selection_3);
        bindVariable(bubblechart1, "Indication", Indication_1);
        
        
         let parallelCoordinatePlot1 = createControl(ParallelCoordinatePlot_type,covid19Data ,"PCP-1", ScatterWidth + TableWidth +1.6*MapWidth ,Top,null, null,null ,
         TableWidth, 2*ScatterHeight  ,null,null, [covid19Axes],covid19Variables.Continent,null,null, ["Continent","DeathsPerMillion","CasesPerMillion"]);
         bindVariable(parallelCoordinatePlot1, "Selection", Selection_2);
         bindVariable(parallelCoordinatePlot1, "Indication", Indication_1);
    
    }

       
    covid19Example();
    

    

}
);



