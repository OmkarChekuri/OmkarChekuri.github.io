
//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Prototype } from "../LP/Prototype.js";
import { Control } from "../LP/Control.js";
import { ControlProxy } from "../LP/ControlProxy.js";
import { LiveProperty } from "../LP/LiveProperty.js";
import { LivePropertyEvent } from "../LP/LivePropertyEvent.js";
import { VariableEvent } from "../LP/VariableEvent.js";

//import { typeOfValue } from "../index.js";
import { printClass } from "../LP/printClass.js";
import { ControlInfo } from "../LP/ControlInfo.js";
import { MapClass } from "../view/map.js";
type typeOfValue = string | number | boolean | undefined | null;

//******************************************************************************
// class ControlSlider
//******************************************************************************

export class ControlMap implements Control
{
   
    //**********************************************************************
    // Public Class Members (Properties)
    //**********************************************************************
   
   
   
   
   
    public CTAG_Size: string = "Size"; 
    public CTAG_Opacity: string = "Opacity";  
    public CTAG_Selection: string = "Selection"; 
    public CTAG_Indication: string = "Indication";
    public CTAG_Data: string = "Data"; 
    public CTAG_Zoom: string = "Zoom"; 
      


    
    public TYPE_Size: Prototype = new Prototype(Number.prototype, this.CTAG_Size, 0);
    public TYPE_Opacity: Prototype = new Prototype(Number.prototype, this.CTAG_Opacity, 0);
    public TYPE_Selection: Prototype = new Prototype(Array.prototype, this.CTAG_Selection, [false]);
    public TYPE_Indication: Prototype = new Prototype(Array.prototype, this.CTAG_Indication, [false]);
    public TYPE_Data: Prototype = new Prototype(Array.prototype, this.CTAG_Data, []);
    public TYPE_Zoom: Prototype = new Prototype(Array.prototype, this.CTAG_Zoom, [null,null]);

    public proxy: ControlProxy;

    public map: MapClass;

    public live_property_xTranslate:LiveProperty;
    public live_property_yTranslate:LiveProperty;
    public live_property_Size:LiveProperty;
    public live_property_Opacity:LiveProperty;
    public live_property_Selection:LiveProperty;
    public live_property_Indication:LiveProperty;
    public live_property_Data:LiveProperty;

    public ControlName: string ;


   

    //**********************************************************************
    // Constructors and Finalizer
    //**********************************************************************

    constructor(name: string, data:Array<any>, xPos:number,yPos:number, inputWidth:number,inputHeight:number )
    {
        if(printClass.printStatus) console.log("I am in constructor of ControlMap");
       
        this.proxy = new ControlProxy(this);

        
        
        //create live property
        
        this.live_property_Opacity = this.proxy.add(this.CTAG_Opacity, this.TYPE_Opacity, true); 
        this.live_property_Selection = this.proxy.add(this.CTAG_Selection, this.TYPE_Selection, true);  
        this.live_property_Size = this.proxy.add(this.CTAG_Size, this.TYPE_Size, true);
        this.live_property_Indication = this.proxy.add(this.CTAG_Indication, this.TYPE_Indication, true);       
        this.live_property_Data = this.proxy.add(this.CTAG_Data, this.TYPE_Data, true);             
        
       
        this.ControlName = name;
        this.map = new MapClass(this, name, data,xPos,yPos,inputWidth,inputHeight);
        if(printClass.printStatus) console.log(name);

        

        
    }




    //**********************************************************************
    // Public Methods (Properties)
    //**********************************************************************



    


    public getColor(): string
    {
        return (this.proxy.getValue(this.CTAG_Opacity) as string);
    }

    public getProxy():ControlProxy
    {
        return this.proxy;
    }

    public setColor(value: typeOfValue): void
    {
        if(printClass.printStatus) console.log("setColor method of ControlMap")
        this.proxy.setValue(this.CTAG_Opacity, value);
        //this.canvas.setValue(value);
    }



    

   
    //**********************************************************************
    // Override Methods (LivePropertyListener)
    //**********************************************************************

    public propertyChanged(e: LivePropertyEvent): void
    {

        if(printClass.printStatus) console.log("propertyChanged method of controlMap");
        if(printClass.printStatus) console.log(e);
        var	tag:string = e.getLiveProperty().getTag();
        if(printClass.printStatus) console.log(tag);

        var    ve:VariableEvent = e.getVariableEvent()!;
       
            
            if(tag == this.CTAG_Opacity)
            {
                if(printClass.printStatus) console.log("controlMap opacity")
               
                   this.map.setOpacity(e.getLiveProperty().getVariable().getValue());
                  
            }
            
            else if(tag == this.CTAG_Data)
            {
                if(printClass.printStatus) console.log("ControlMap Data")
                


                   this.map.setHoverSelection(e.getLiveProperty().getVariable().getValue());
                   
            }
            else if(tag == this.CTAG_Selection)
            {
                if(printClass.printStatus) console.log("ControlMap Data")
                

                   this.map.setSelection(e.getLiveProperty().getVariable().getValue());
                   // this.slider.setValue(90);
            }
            else if(tag == this.CTAG_Indication)
            {
                if(printClass.printStatus) console.log("ControlMap Data")
                //console.log(e.getLiveProperty().variable.getPrototype().value)    
                //var	value:typeOfValue = this.getValue();
                //if(printClass.printStatus) console.log(value);

                //if (this.slider.getValue() != value)
                   //console.log(e.getLiveProperty().getVariable().getValue());


                   this.map.setIndication(e.getLiveProperty().getVariable().getValue());
                   // this.slider.setValue(90);
            }
            // else if(tag == this.CTAG_Zoom)
            // {
            //     if(printClass.printStatus) console.log("hurray ControlMap Zoom")
            //     //console.log(e.getLiveProperty().variable.getPrototype().value)    
            //     //var	value:typeOfValue = this.getValue();
            //     //if(printClass.printStatus) console.log(value);

            //     //if (this.slider.getValue() != value)
            //        //console.log(e.getLiveProperty().getVariable().getValue());


            //        this.map.setZoom(e.getLiveProperty().getVariable().getValue() as Array<any>);
            //        // this.slider.setValue(90);
            // }
        //} 


    }

    public propertyChangeToUpdateUI(value: typeOfValue): void
    {

        //if(printClass.printStatus) console.log(e);
        //this.canvas.setValue(value);
        if(printClass.printStatus) console.log(value);

    }






    //**********************************************************************
    // Private Methods (Graphics)
    //**********************************************************************



    describe(): ControlInfo
    {
        throw new Error("Method not implemented.");
    }
    dispose(): void
    {
        throw new Error("Method not implemented.");
    }



    
    



}

//******************************************************************************


