
//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Prototype } from "../LP/Prototype.js";
import { Control } from "../LP/Control.js";
import { ControlProxy } from "../LP/ControlProxy.js";
import { LiveProperty } from "../LP/LiveProperty.js";
import { LivePropertyEvent } from "../LP/LivePropertyEvent.js";
import { VariableEvent } from "../LP/VariableEvent.js";
import { CanvasClass } from "../view/canvas.js";
//import { typeOfValue } from "../index.js";
import { printClass } from "../LP/printClass.js";
import { ControlInfo } from "../LP/ControlInfo.js";
type typeOfValue = string | number | boolean | undefined | null;

//******************************************************************************
// class ControlSlider
//******************************************************************************

export class ControlCanvas implements Control
{
   
    //**********************************************************************
    // Public Class Members (Properties)
    //**********************************************************************
   
   
   
   
    public CTAG_Height: string = "Height";  
    public CTAG_Width: string = "Width";  

    public TYPE_Height: Prototype = new Prototype(Number.prototype, this.CTAG_Height, 0);
    public TYPE_Width: Prototype = new Prototype(Number.prototype, this.CTAG_Width, 0);

    public proxy: ControlProxy;

    public canvas: CanvasClass;

    public live_property1:LiveProperty;
    public live_property2:LiveProperty;

    public ControlName: string ;


   

    //**********************************************************************
    // Constructors and Finalizer
    //**********************************************************************

    constructor(name: string)
    {
        //Create Control Proxy
       
        this.proxy = new ControlProxy(this);

        

        //create live property
        this.live_property1 = this.proxy.add(this.CTAG_Height, this.TYPE_Height, true);
        this.live_property2 = this.proxy.add(this.CTAG_Width, this.TYPE_Width, true);              
        
        if(printClass.printStatus) console.log(this.live_property1);
        if(printClass.printStatus) console.log(this.live_property2);
        
        this.ControlName = name;
        this.canvas = new CanvasClass(name);
        if(printClass.printStatus) console.log(name);

          

        
    }




    //**********************************************************************
    // Public Methods (Properties)
    //**********************************************************************



    public getHeight(): number
    {
        return (this.proxy.getValue(this.CTAG_Height)) as number;
    }

    public setHeight(value: typeOfValue): void
    {
        this.proxy.setValue(this.CTAG_Height, value);
        //this.canvas.setValue(value);
    }

    public getWidth(): number
    {
        return (this.proxy.getValue(this.CTAG_Width)) as number;
    }

    public setWidth(value: typeOfValue): void
    {
        this.proxy.setValue(this.CTAG_Width, value);
        //this.canvas.setValue(value);
    }

   

    //**********************************************************************
    // Override Methods (LivePropertyListener)
    //**********************************************************************

    public propertyChanged(e: LivePropertyEvent): void
    {


        if(printClass.printStatus) console.log("propertyChanged method of controlSlider");
        if(printClass.printStatus) console.log(e);
        var		tag:string = e.getLiveProperty().getTag();
        if(printClass.printStatus) console.log(tag);

        var    ve:VariableEvent = e.getVariableEvent()!;
        if(printClass.printStatus) console.log(ve);   //this value should not be null
        if(printClass.printStatus) console.log(ve.getType());
        if(printClass.printStatus) console.log(VariableEvent.VALUE_CHANGED);


        
            
            if (tag == this.CTAG_Height)
            {
                if(printClass.printStatus) console.log("ControlCanvas height")
                if(printClass.printStatus) console.log(e.getLiveProperty().variable.getPrototype().value)    
                
                   if(printClass.printStatus) console.log(e.getLiveProperty().getVariable().getValue());
                   this.canvas.setHeight(e.getLiveProperty().getVariable().getValue() as number);
                  
            }
            else if(tag == this.CTAG_Width)
            {
                if(printClass.printStatus) console.log("ControlCanvas Width")
                if(printClass.printStatus) console.log(e.getLiveProperty().variable.getPrototype().value)    
               

                //if (this.slider.getValue() != value)
                   if(printClass.printStatus) console.log(e.getLiveProperty().getVariable().getValue());


                   this.canvas.setWidth(e.getLiveProperty().getVariable().getValue() as number);
                  
            }
      

    }







    //**********************************************************************
    // Private Methods (Graphics)
    //**********************************************************************



    describe(): ControlInfo
    {
        throw new Error("Method not implemented.");
    }
    dispose(): void
    {
        throw new Error("Method not implemented.");
    }



    
    



}

//******************************************************************************


