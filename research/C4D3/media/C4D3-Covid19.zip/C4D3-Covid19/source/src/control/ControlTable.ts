//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Prototype } from "../LP/Prototype.js";
import { Control } from "../LP/Control.js";
import { ControlProxy } from "../LP/ControlProxy.js";
import { LiveProperty } from "../LP/LiveProperty.js";
import { LivePropertyEvent } from "../LP/LivePropertyEvent.js";
import { VariableEvent } from "../LP/VariableEvent.js";
import { TableClass } from "../view/table.js";
import { typeOfValue } from "../index.js";
import { printClass } from "../LP/printClass.js";
import { ControlInfo } from "../LP/ControlInfo.js";
//type typeOfValue = string | number | boolean | undefined | null;

//******************************************************************************
// class ControlSlider
//******************************************************************************

export class ControlTable implements Control
{
    
    //**********************************************************************
    // Public Class Members (Properties)
    //**********************************************************************
   
   
   
   
    public CTAG_Height: string = "Height";  
    public CTAG_Width: string = "Width"; 
    public CTAG_Opacity: string = "Opacity"; 
    public CTAG_Selection: string = "Selection"; 
    public CTAG_Indication: string = "Indication";
     public CTAG_Data: string = "Data"; 


    public TYPE_Height: Prototype = new Prototype(Number.prototype, this.CTAG_Height, 0);
    public TYPE_Width: Prototype = new Prototype(Number.prototype, this.CTAG_Width, 0);
    public TYPE_Opacity: Prototype = new Prototype(Number.prototype, this.CTAG_Opacity, 0);
    public TYPE_Selection: Prototype = new Prototype(Array.prototype, this.CTAG_Selection, [false]);
    public TYPE_Indication: Prototype = new Prototype(Array.prototype, this.CTAG_Indication, []);
    public TYPE_Data: Prototype = new Prototype(Array.prototype, this.CTAG_Data, []);

    public proxy: ControlProxy;

    public table: TableClass;

    public live_property_Height:LiveProperty;
    public live_property_Width:LiveProperty;
    public live_property_Selection:LiveProperty;
    public live_property_Opacity:LiveProperty;
    public live_property_Indication:LiveProperty;
    public live_property_Data:LiveProperty;


    public ControlName: string ;


   

    //**********************************************************************
    // Constructors and Finalizer
    //**********************************************************************

    constructor(name: string, data:Array<any>,xPos:number,yPos:number, inputWidth:number,inputHeight:number)
    {
        if(printClass.printStatus) console.log("I am in constructor of ControlTable");
        //Create Control Proxy
        //if(printClass.printStatus) console.log(this.TYPE_VALUE);
        this.proxy = new ControlProxy(this);

        
        
        //create live property
        this.live_property_Height = this.proxy.add(this.CTAG_Height, this.TYPE_Height, true);
        this.live_property_Width = this.proxy.add(this.CTAG_Width, this.TYPE_Width, true);  
        this.live_property_Opacity = this.proxy.add(this.CTAG_Opacity, this.TYPE_Opacity, true);  
        this.live_property_Selection = this.proxy.add(this.CTAG_Selection, this.TYPE_Selection, true);
        this.live_property_Indication = this.proxy.add(this.CTAG_Indication, this.TYPE_Indication, true);          
        this.live_property_Data = this.proxy.add(this.CTAG_Data, this.TYPE_Data, true);        
        
       
        
        this.ControlName = name;
        this.table = new TableClass(this,name, data, xPos,yPos, inputWidth,inputHeight);
        if(printClass.printStatus) console.log(name);

             

        
    }




    //**********************************************************************
    // Public Methods (Properties)
    //**********************************************************************



    public getHeight(): typeOfValue
    {
        return (this.proxy.getValue(this.CTAG_Height));
    }

    public setHeight(value: typeOfValue): void
    {
        if(printClass.printStatus) console.log("setHeight method of ControlTable")
        this.proxy.setValue(this.CTAG_Height, value);
        
    }


    public getColor(): typeOfValue
    {
        return (this.proxy.getValue(this.CTAG_Opacity));
    }

    public setColor(value: typeOfValue): void
    {
        if(printClass.printStatus) console.log("setColor method of ControlTable")
        this.proxy.setValue(this.CTAG_Opacity, value);
       
    }

    public getProxy():ControlProxy
    {
        //if(printClass.printStatus) 
        //console.log("getProxy method of ControlTable" )
        return this.proxy;
    }

    public getWidth(): typeOfValue
    {
        return (this.proxy.getValue(this.CTAG_Width));
    }

    public setWidth(value: typeOfValue): void
    {
        if(printClass.printStatus) console.log("setWidth method of ControlTable")
        this.proxy.setValue(this.CTAG_Width, value);
        //this.canvas.setValue(value);
    }

    
    //**********************************************************************
    // Override Methods (LivePropertyListener)
    //**********************************************************************

    public propertyChanged(e: LivePropertyEvent): void
    {

        if(printClass.printStatus) console.log("propertyChanged method of ControlTable");
        if(printClass.printStatus) console.log(e);
        var	tag:string = e.getLiveProperty().getTag();
        if(printClass.printStatus) console.log(tag);

        var    ve:VariableEvent = e.getVariableEvent()!;
      
            
            if (tag == this.CTAG_Height)
            {
                if(printClass.printStatus) console.log("hurray ControlTable height")
               
                   this.table.setHeight(e.getLiveProperty().getVariable().getValue());
                   
            }
            else if(tag == this.CTAG_Width)
            {
                if(printClass.printStatus) console.log("hurray ControlTable Width")
                  this.table.setWidth(e.getLiveProperty().getVariable().getValue());
                   
            }
            else if(tag == this.CTAG_Opacity)
            {
                if(printClass.printStatus) console.log("hurray ControlTable opacity")
              
                   this.table.setOpacity(e.getLiveProperty().getVariable().getValue());
                  
            }
            else if(tag == this.CTAG_Selection)
            {
                if(printClass.printStatus) console.log("hurray ControlTable Selection")
              
                   this.table.setSelection(e.getLiveProperty().getVariable().getValue());
                   
            }
            else if(tag == this.CTAG_Indication)
            {
                if(printClass.printStatus) console.log("hurray ControlTable Hover")
               

                   this.table.setIndication(e.getLiveProperty().getVariable().getValue());
                   
            }
            else if(tag == this.CTAG_Data)
            {
                if(printClass.printStatus) console.log("hurray ControlTable Data")
               
                   this.table.setHoverSelection(e.getLiveProperty().getVariable().getValue());
                 
            }
       


    }

    //**********************************************************************
    // Private Methods (Graphics)
    //**********************************************************************



    describe(): ControlInfo
    {
        throw new Error("Method not implemented.");
    }
    dispose(): void
    {
        throw new Error("Method not implemented.");
    }



    
    



}

//******************************************************************************


