//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Prototype } from "../LP/Prototype.js";
import { Control } from "../LP/Control.js";
import { ControlProxy } from "../LP/ControlProxy.js";
import { LivePropertyEvent } from "../LP/LivePropertyEvent.js";
import { VariableEvent } from "../LP/VariableEvent.js";
import { PixelClass } from "../view/pixel.js";
//import { typeOfValue } from "../index.js";
import { LiveProperty } from "../LP/LiveProperty.js";
import { printClass } from "../LP/printClass.js";
import { ControlInfo } from "../LP/ControlInfo.js";
type typeOfValue = string | number | boolean | undefined | null;
//for testing
type Callback = ()=>void;
 

//******************************************************************************
// class ControlSlider
//******************************************************************************

export class ControlPixel implements Control
{
    //**********************************************************************
    // Public Class Members (Properties)
    //**********************************************************************
    
    public  CTAG_VALUE: string = "Value";

    public  TYPE_VALUE: Prototype = new Prototype(Number.prototype, this.CTAG_VALUE, 0);

    public proxy: ControlProxy;

    public Pixel: PixelClass;
    
    public live_property:LiveProperty;

    public ControlName:string ;

    

    //**********************************************************************
    // Constructors and Finalizer
    //**********************************************************************

    constructor(name:string)
    {

        this.proxy = new ControlProxy(this);


        this.live_property = this.proxy.add(this.CTAG_VALUE, this.TYPE_VALUE, true);
        this.ControlName = name;
        this.Pixel = new PixelClass(name);

        //create the variables pproxy and ttag to be used in add event listener as we cannot use this 
        //keyword to access the current class i.e control slider inside the add event listener method.
        var pproxy = this.proxy;
        var ttag = this.CTAG_VALUE

        document.getElementById("myValue" + name).addEventListener("input", function()
        {pproxy.getLiveProperty(ttag).setValue(parseInt((this as HTMLInputElement).value));} );

    }

  

 
    //**********************************************************************
    // Public Methods (Properties)
    //**********************************************************************



    public 	getValue():typeOfValue
    {
        return (this.proxy.getValue(this.CTAG_VALUE) as typeOfValue);
    }

    public setValue(value:typeOfValue):void
    {
        this.proxy.setValue(this.CTAG_VALUE, value);
        this.Pixel.setValue(value);
    }

    //**********************************************************************
    // Override Methods (ChangeListener)
    //**********************************************************************

    public stateChanged( e:Event):void
    {
       var  value:typeOfValue = this.Pixel.getValue();

        if (value != this.getValue())
            this.setValue(value);
    }

    //**********************************************************************
    // Override Methods (LivePropertyListener)
    //**********************************************************************

    public 		propertyChanged( e:LivePropertyEvent):void
    {
        if(printClass.printStatus) console.log("I am in property changed method of control Pixel");
        if(printClass.printStatus) console.log(e);
        var		tag:string = e.getLiveProperty().getTag();
        if(printClass.printStatus) console.log(tag);

        var    ve:VariableEvent = e.getVariableEvent()!;
        if(printClass.printStatus) console.log(ve);     

       
            
            if (tag == this.CTAG_VALUE)
            {
                
                if(printClass.printStatus) console.log(e.getLiveProperty().variable.getPrototype().value)    
               
                this.Pixel.setValue(e.getLiveProperty().getVariable().getValue() as typeOfValue);
               
            }
       
    }


    //**********************************************************************
    // Private Methods (Graphics)
    //**********************************************************************


 
    describe(): ControlInfo
    {
        throw new Error("Method not implemented.");
    }
    dispose(): void
        {
            throw new Error("Method not implemented.");
        }



       

}

//******************************************************************************


