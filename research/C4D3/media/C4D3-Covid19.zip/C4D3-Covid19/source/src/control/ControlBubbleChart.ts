
//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Prototype } from "../LP/Prototype.js";
import { Control } from "../LP/Control.js";
import { ControlProxy } from "../LP/ControlProxy.js";
import { LiveProperty } from "../LP/LiveProperty.js";
import { LivePropertyEvent } from "../LP/LivePropertyEvent.js";
import { VariableEvent } from "../LP/VariableEvent.js";

//import { typeOfValue } from "../index.js";
import { printClass } from "../LP/printClass.js";
import { ControlInfo } from "../LP/ControlInfo.js";
import { BubbleChartClass } from "../view/bubblechart.js";
type typeOfValue = string | number | boolean | undefined | null;

//******************************************************************************
// class ControlSlider
//******************************************************************************

export class ControlBubblechart implements Control
{
   
    //**********************************************************************
    // Public Class Members (Properties)
    //**********************************************************************
   
   
   
   
    public CTAG_xTranslate: string = "xTranslate";  
    public CTAG_yTranslate: string = "yTranslate"; 
    public CTAG_Size: string = "Size"; 
    public CTAG_Opacity: string = "Opacity";  
    public CTAG_Selection: string = "Selection"; 
    public CTAG_Indication: string = "Indication";       
    public CTAG_Data: string = "Data"; 
    public CTAG_Zoom: string = "Zoom"; 
      

    public TYPE_xTranslate: Prototype = new Prototype(Array.prototype, this.CTAG_xTranslate, [null,null]);
    public TYPE_yTranslate: Prototype = new Prototype(Array.prototype, this.CTAG_yTranslate, [null,null]);
    public TYPE_Size: Prototype = new Prototype(Number.prototype, this.CTAG_Size, 0);
    public TYPE_Opacity: Prototype = new Prototype(Number.prototype, this.CTAG_Opacity, 0);
    public TYPE_Selection: Prototype = new Prototype(Array.prototype, this.CTAG_Selection, [false]);
    public TYPE_Indication: Prototype = new Prototype(Array.prototype, this.CTAG_Indication, [false]);
    public TYPE_Data: Prototype = new Prototype(Array.prototype, this.CTAG_Data, []);
    public TYPE_Zoom: Prototype = new Prototype(Array.prototype, this.CTAG_Zoom, [null,null]);
    

    public proxy: ControlProxy;

    public bubblechart: BubbleChartClass;

    public live_property_xTranslate:LiveProperty;
    public live_property_yTranslate:LiveProperty;
    public live_property_Size:LiveProperty;
    public live_property_Opacity:LiveProperty;
    public live_property_Selection:LiveProperty;
    public live_property_Indication:LiveProperty;
    public live_property_Data:LiveProperty;
    public live_property_Zoom:LiveProperty;

    public ControlName: string ;


   

    //**********************************************************************
    // Constructors and Finalizer
    //**********************************************************************

    constructor(name: string, data:Array<any> ,xPos:number,yPos:number, inputWidth:number,inputHeight:number,
         helper:Array<any>,color:number,size:number,text:number)
    {
        if(printClass.printStatus) console.log("Constructor of Controlbubblechart");
       
        this.proxy = new ControlProxy(this);

        
        
        //create live property
        this.live_property_xTranslate = this.proxy.add(this.CTAG_xTranslate, this.TYPE_xTranslate, true);
        this.live_property_yTranslate = this.proxy.add(this.CTAG_yTranslate, this.TYPE_yTranslate, true);  
        this.live_property_Opacity = this.proxy.add(this.CTAG_Opacity, this.TYPE_Opacity, true); 
        this.live_property_Selection = this.proxy.add(this.CTAG_Selection, this.TYPE_Selection, true);  
        this.live_property_Indication = this.proxy.add(this.CTAG_Indication, this.TYPE_Indication, true);  
        this.live_property_Size = this.proxy.add(this.CTAG_Size, this.TYPE_Size, true);
        this.live_property_Data = this.proxy.add(this.CTAG_Data, this.TYPE_Data, true);
        this.live_property_Zoom = this.proxy.add(this.CTAG_Zoom, this.TYPE_Zoom, true);              
        
        
        
        this.ControlName = name;
        //console.log(data)
        this.bubblechart = new BubbleChartClass(this,data, name,xPos,yPos,inputWidth,inputHeight,helper,color,size,text);
        if(printClass.printStatus) console.log(name);

        

        
    }




    //**********************************************************************
    // Public Methods (Properties)
    //**********************************************************************



    public getTranslateX(): typeOfValue
    {
        return (this.proxy.getValue(this.CTAG_xTranslate) as typeOfValue ) ;
    }

    public setTranslateX(value: typeOfValue): void
    {
       console.log("setTranslateX method of Controlbubblechart")
        this.proxy.setValue(this.CTAG_xTranslate, value);
        //this.canvas.setValue(value);
    }


    public getColor(): typeOfValue
    {
        return (this.proxy.getValue(this.CTAG_Opacity) as typeOfValue) ;
    }

    public getProxy():ControlProxy
    {
        return this.proxy;
    }

    public setColor(value: typeOfValue): void
    {
        if(printClass.printStatus) console.log("setColor method of Controlbubblechart")
        this.proxy.setValue(this.CTAG_Opacity, value);
        //this.canvas.setValue(value);
    }



    public getTranslateY(): typeOfValue
    {
        return (this.proxy.getValue(this.CTAG_yTranslate) as typeOfValue);
    }

    public setTranslateY(value: typeOfValue): void
    {
        console.log("setTranslateY method of Controlbubblechart")
        this.proxy.setValue(this.CTAG_yTranslate, value);
        //this.canvas.setValue(value);
    }

   
    //**********************************************************************
    // Override Methods (LivePropertyListener)
    //**********************************************************************

    public propertyChanged(e: LivePropertyEvent): void
    {

        if(printClass.printStatus) console.log("propertyChanged method of controlbubblechart");
        if(printClass.printStatus) console.log(e);
        var	tag:string = e.getLiveProperty().getTag();
        if(printClass.printStatus) console.log(tag);

        var    ve:VariableEvent = e.getVariableEvent()!;
       

            if(tag == this.CTAG_Opacity)
            {
                if(printClass.printStatus) console.log("controlbubblechart opacity")
                


                   this.bubblechart.setOpacity(e.getLiveProperty().getVariable().getValue());
                   
            }
            else if(tag == this.CTAG_Selection)
            {
                if(printClass.printStatus) console.log("Controlbubblechart Selection")
               
                   this.bubblechart.setSelection(e.getLiveProperty().getVariable().getValue() as Array<any>);
                  
            }
            else if(tag == this.CTAG_Indication)
            {
                if(printClass.printStatus) console.log("Controlbubblechart Indication")
                

                   this.bubblechart.setIndication(e.getLiveProperty().getVariable().getValue() as Array<any>);
                  
            }
            


    }






    //**********************************************************************
    // Private Methods (Graphics)
    //**********************************************************************



    describe(): ControlInfo
    {
        throw new Error("Method not implemented.");
    }
    dispose(): void
    {
        throw new Error("Method not implemented.");
    }



    
    



}

//******************************************************************************


