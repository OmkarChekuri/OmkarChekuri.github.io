//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

//Draggable class to make the html div elements draggable
//source : https://www.w3schools.com/howto/howto_js_draggable.asp


export class Draggable
{
 
  dragElement(elmnt: HTMLElement | null)
  {
    if (elmnt == null)
    {
      
    } else
    {
      var pos1 = 0,
        pos2 = 0,
        pos3 = 0,
        pos4 = 0;
      if (document.getElementById(elmnt.id ))
      {
        /* if present, the header is where you move the DIV from:*/
        document.getElementById(
          elmnt.id 
        )!.onmousedown = dragMouseDown;
      } else
      {
        /* otherwise, move the DIV from anywhere inside the DIV:*/
        elmnt.onmousedown = dragMouseDown;
      }

      function dragMouseDown(e: MouseEvent)
      {
        e = e || window.event as MouseEvent;
        e.preventDefault();
        // get the mouse cursor position at startup:
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        // call a function whenever the cursor moves:
        document.onmousemove = elementDrag;
      }

      function elementDrag(e: MouseEvent)
      {
        e = e || window.event as MouseEvent;
        e.preventDefault();
        // calculate the new cursor position:
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        // set the element's new position:
        elmnt!.style.top = elmnt!.offsetTop - pos2 + "px";
        elmnt!.style.left = elmnt!.offsetLeft - pos1 + "px";
      }

      function closeDragElement()
      {
        /* stop moving when mouse button is released:*/
        document.onmouseup = null;
        document.onmousemove = null;
      }
    }
  }
}
 
