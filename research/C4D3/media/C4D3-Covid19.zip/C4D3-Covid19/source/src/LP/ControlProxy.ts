
//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Disposable } from "./Disposable.js";
import { Control } from "./Control.js";
import { ControlInfo } from "./ControlInfo.js";
import { LivePropertyListener } from "./LivePropertyListener.js";
import { ControlEvent } from "./ControlEvent.js";
import { Prototype } from "./Prototype.js";
import { SharedFlag } from "./SharedFlag.js";
import { LiveProperty } from "./LiveProperty.js";
import { Variable } from "./Variable.js";
import { ControlListener } from "./ControlListener.js";
import { typeOfValue } from "../index.js";
import { printClass } from "./printClass.js";
//type typeOfValue = string | number | boolean | undefined | null;


export class ControlProxy implements Disposable
{
	//**********************************************************************
	// Public Class Members
	//**********************************************************************

	/* static const 	MUTATOR_PROTOTYPE: Prototype =
		new Prototype(LexicalMutation.class, "Mutator", null); */

	//**********************************************************************
	// Private Members
	//**********************************************************************

	// State (internal) variables
	private control: Control;			// Parent control
	private info: ControlInfo;		// Immutable copy
	private tags: any[] = [];			//prototype names
	private map = new Map();				// Tag->LiveProperty

	// Working (transient) variables
	//private const event: StateEvent;
	private interacting: boolean | null = null;
	private lastInteractionTime: number | null = null;
	private lastUpdateTime: number | null = null;

	private metaFocusingFlag: SharedFlag;
	private metaEditingFlag: SharedFlag;

	// Event Multicasters
	private controlListeners: any[] = [];
	private stateListeners: any[] = [];


	//**********************************************************************
	// Constructors and Finalizer
	//**********************************************************************

	constructor(control: Control)
	{

		//if(printClass.printStatus) console.log("Hi I am in control proxy");
		//if(printClass.printStatus) console.log(control);
		this.control = control;

		this.info = new ControlInfo(this);
		this.tags = [];
		this.map = new Map();

		//event = new StateEvent(this);

		this.metaFocusingFlag = new SharedFlag();
		this.metaEditingFlag = new SharedFlag();

		//this.controlListeners = [4];
		//this.stateListeners = [4];

		if(printClass.printStatus) console.log("Second: ControlProxy Object Created");
		//if(printClass.printStatus) console.log(this);
	}

	//**********************************************************************
	// Getters and Setters
	//**********************************************************************

	public getControl(): Control
	{
		return this.control;
	}

	//**********************************************************************
	// Public Methods (Control)
	//**********************************************************************

	public describe(): ControlInfo
	{
		return this.info;
	}

	//**********************************************************************
	// Public Methods (Properties)
	//**********************************************************************

	/**
	 * Returns a vector of all tags, in the order added.
	 */
	public getTags(): any[]
	{
		var s: string[] = [];

		s = this.tags;

		return s;
	}

	/**
	 * Returns the number of tags.
	 */
	public getTagCount(): number
	{
		return this.tags.length;
	}

	/**
	 * Returns the tag at the specified index.
	 */
	public getTagAt(index: number): string
	{
		return this.tags[index];
	}

	/**
	 * Returns where a tag is in the vector of all tags, or -1 if absent.
	 */
	public getIndexOfTag(tag: string): number
	{
		return this.tags.indexOf(tag);
	}

	/**
	 * Returns the LiveProperty associated with the specified tag, or null if
	 * none exists.
	 *
	 * @param		tag		the name of the LiveProperty to retrieve
	 */
	public getLiveProperty(tag: string): LiveProperty
	{
		if(printClass.printStatus) console.log(ControlProxy.map.get(tag));
		if(printClass.printStatus) console.log("getLiveProperty method of ControlProxy")
		if(printClass.printStatus) console.log(this.map.get(tag));
		return this.map.get(tag);
	}

	/**
	 * Returns a vector of all LiveProperties, in the order added.
	 */
	public getLiveProperties(): LiveProperty[]
	{
		var properties: LiveProperty[] = [];
		var i = 0;
		for (i = 0; i < properties.length; i++)
			properties[i] = this.map.get(this.tags[i]);

		return properties;
	}

	/**
	 * Returns the property at the specified index.
	 */
	public getPropertyAt(index: number): LiveProperty
	{
		return this.map.get(this.tags[index]);
	}

	/**
	 * Convenience method to register a listener with all current properties.
	 * This does NOT automatically handle future addition and removal of
	 * properties to the control. (Use ControlListener to detect such changes.)
	 */
	public addLivePropertyListener(l: LivePropertyListener): void
	{
		var n: number = this.tags.length;
		var i: number;
		for (i = 0; i < n; i++)
		{
			var tag: string = this.tags[i];
			var property: LiveProperty = this.map.get(tag);

			property.addLivePropertyListener(l);
		}
	}

	/**
	 * Convenience method to deregister a listener with all current properties.
	 * This does NOT automatically handle future addition and removal of
	 * properties to the control. (Use ControlListener to detect such changes.)
	 */
	public removeLivePropertyListener(l: LivePropertyListener): void
	{
		var n: number = this.tags.length;
		var i: number;
		for (i = 0; i < n; i++)
		{
			var tag: string = this.tags[i];
			var property: LiveProperty = this.map.get(tag);

			property.removeLivePropertyListener(l);
		}
	}

	add(tag: string, prototype: Prototype, interactive: boolean): LiveProperty
	{
		
		if (interactive)
		{
			if (this.map.has(tag))
				throw new Error("Duplicate tag: " + tag);

			var property: LiveProperty = new LiveProperty(this.control, tag, prototype,
				interactive);
			
			this.tags.push(tag);
			//if(printClass.printStatus) console.log("I am in here ");
			this.map.set(tag, property);
			if(printClass.printStatus) console.log(this.map.get(tag));					//sending undefined value
			property.addLivePropertyListener(this.control);
			//if(printClass.printStatus) console.log("Hi")
			this.firePropertyAdded(new ControlEvent(this.control, property));




			return property;
		}
		else
		{

			if (this.map.has(tag))
				throw new Error("Duplicate tag: " + tag);

			var property: LiveProperty = new LiveProperty(this.control, tag, prototype,
				false);

				this.tags.push(tag);
				this.map.set(tag, property);
			property.addLivePropertyListener(this.control);
			this.firePropertyAdded(new ControlEvent(this.control, property));



			return property;
		}

	}





	public remove(tag: string): void
	{
		var property: LiveProperty = this.map.get(tag);

		if (property == null)
			throw new Error("Unknown tag: " + tag);

		

		property.removeLivePropertyListener(this.control);
		this.map.delete(tag);
		this.tags.splice(this.tags.indexOf(tag), 1);
		this.firePropertyRemoved(new ControlEvent(this.control, property));

		property.dispose();
	}

	public removeAll(): void
	{
		while (this.tags.length > 0)
			this.remove(this.tags[this.tags.length - 1]);
	}

	//**********************************************************************
	// Public Methods (Properties, Variable Access)
	//********************************************************************* 

	public getVariable(tag: string): Variable | null
	{
		return this.getLiveProperty(tag).getVariable();
	}

	public setVariable(tag: string, variable: Variable): void
	{
		
		
		if(printClass.printStatus) console.log("setVariable Method of ControlProxy");
		if(printClass.printStatus) console.log(this.getLiveProperty(tag));
		if(printClass.printStatus) console.log(variable);
		this.getLiveProperty(tag).setVariable(variable);
		//if(printClass.printStatus) console.log(this.getLiveProperty(tag));
	}

	public getName(tag: string): String
	{
		return this.getLiveProperty(tag).getName();
	}

	public setName(tag: string, name: string): void
	{
		this.getLiveProperty(tag).setName(name);
	}

	public getValue(tag: string): typeOfValue
	{
		var value: typeOfValue = this.getLiveProperty(tag).getValue();

		return value;
	}

	public setValue(tag: string, value: typeOfValue): void
	{
		console.log("is my server working");
		this.getLiveProperty(tag).setValue(value);
	}

	//**********************************************************************
	// Public Methods (Properties, Locking)
	//**********************************************************************

	public isLocked(): boolean
	{
		var n: number = this.tags.length;
		var i: number;
		for (i = 0; i < n; i++)
		{
			var tag: string = this.tags[i].toString();
			var property: LiveProperty = this.map.get(tag);

			if (property.getInteractive() && !property.isLocked())
				return false;
		}

		return true;
	}

	
	//**********************************************************************
	// Public Methods (Events)
	//**********************************************************************

	/**
	 * Registers the specified ControlListener to receive ControlEvents
	 * whenever a LiveProperty is added to or removed from this this.
	 */
	public addControlListener(l: ControlListener): void
	{
		this.controlListeners.push(l);
	}

	/**
	 * Unregisters the specified ControlListener.
	 */
	public removeControlListener(l: ControlListener): void
	{

		this.controlListeners.splice(this.controlListeners.indexOf(l.toString()), 1);

	}


	//**********************************************************************
	// Override Methods (Disposable)
	//**********************************************************************

	public dispose(): void
	{
		while (this.tags.length > 0)
		{
			var tag: string = this.tags[this.tags.length - 1].toString();

			if (!tag.endsWith(".Mutator"))
				this.remove(tag);
		}

		this.controlListeners.splice(0, this.controlListeners.length);
		this.stateListeners.splice(0, this.stateListeners.length);
	}

	//**********************************************************************
	// Private Methods (Events)
	//**********************************************************************

	private firePropertyAdded(e: ControlEvent): void
	{
		//if(printClass.printStatus) console.log("I am in firePropertyAdded method of this");
		var n: number = this.controlListeners.length;
		var i: number;
		for (i = 0; i < n; i++)
			(this.controlListeners[i]).propertyAdded(e);
	}

	private firePropertyRemoved(e: ControlEvent): void
	{
		var n: number = this.controlListeners.length;
		var i: number;
		for (i = 0; i < n; i++)
			(this.controlListeners[i]).propertyRemoved(e);
	}

	private fireStateChanged(): void
	{
		var n: number = this.stateListeners.length;
		var i: number;
		for (i = 0; i < n; i++)
			(this.stateListeners[i]).stateChanged(event);
	}
}

	//******************************************************************************

