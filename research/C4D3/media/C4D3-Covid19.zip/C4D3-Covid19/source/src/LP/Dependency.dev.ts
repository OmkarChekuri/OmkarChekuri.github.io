//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Disposable } from "./Disposable.js";
import { LivePropertyListener } from "./LivePropertyListener.js";
import { LiveProperty } from "./LiveProperty.js";
import { LivePropertyEvent } from "./LivePropertyEvent.js";
import { VariableEvent } from "./VariableEvent.js";



	export class Dependency	implements Disposable, LivePropertyListener
	{
		//**********************************************************************
		// Private Members
		//**********************************************************************

		// State (internal) variables
		private  	src:LiveProperty;
		private  	dst:LiveProperty;

		//**********************************************************************
		// Constructors and Finalizer
		//**********************************************************************

		constructor( src:LiveProperty,  dst:LiveProperty)
		{
			if (!dst.getPrototype().isAssignableFrom(src.getPrototype()))
				throw new Error("Incompatible property types");

			this.src = src;
			this.dst = dst;

			dst.setVariable(src.getVariable());
			src.addLivePropertyListener(this);
		}

		//**********************************************************************
		// Getters and Setters
		//**********************************************************************

		public 		getSrcLiveProperty():LiveProperty
		{
			return this.src;
		}

		public 		getDstLiveProperty():LiveProperty
		{
			return this.dst;
		}

		//**********************************************************************
		// Override Methods (Disposable)
		//**********************************************************************

		public 		dispose():void
		{
			this.src.removeLivePropertyListener(this);
		}

		//**********************************************************************
		// Override Methods (LivePropertyListener)
		//**********************************************************************

		public propertyChanged( e:LivePropertyEvent):void
		{
			if (e.getSource() != this.src)
				return;

			var	ve:VariableEvent|null = e.getVariableEvent();

			if (ve != null)
				this.dst.setVariable(ve.getVariable);
		}
	}

	//******************************************************************************

