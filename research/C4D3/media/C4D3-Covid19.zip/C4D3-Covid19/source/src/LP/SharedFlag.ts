
//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

//******************************************************************************
// class SharedFlag
//******************************************************************************



export class SharedFlag
{
	//**********************************************************************
	// Private Members
	//**********************************************************************

	// State (internal) variables
	private set:any[] = [];

	//**********************************************************************
	// Constructors and Finalizer
	//**********************************************************************

    public SharedFlag()
	{
		this.set = new Array(4);
	}

	//**********************************************************************
	// Public Methods
	//**********************************************************************

	/**
	 * Returns the overall state of the shared flag; that is, returns
	 * <CODE>true</CODE> if one or more associated object have indicated that
	 * it is <CODE>true</CODE>.
	 */



	public 	getState( obj?:Object):boolean
	{
		if(obj){
			return !(this.set.indexOf(obj.toString()));
		}
		else{
			return !(this.set.length<1);
		}
		
		
		
	}

	/**
	 * Associates an object with a particular state of the shared flag. On
	 * return, indicates whether the overall state of the flag changed as a
	 * result of the association.
	 *
	 * @param		b		the state of the flag according to the object
	 * @param		object	an object
	 * @return		whether or not the flag's shared state changed
	 */
	public 	setState( b:boolean,  obj:object):boolean
	{
				var changed:boolean = false;

		if (b)
		{
			if (Array.isArray(this.set)  && this.set.length)
			{
				this.set.push(obj);
				changed = true;
			}
			else if (!this.set.indexOf(obj))              /////need to check the logic again : omkar
			{
				this.set.push(obj);
			}
		}
		else
		{
			if (this.set.splice(this.set.indexOf(obj),1) && (Array.isArray(this.set)  && this.set.length))
				changed = true;
		}

		return changed;
	}
}

//******************************************************************************


 