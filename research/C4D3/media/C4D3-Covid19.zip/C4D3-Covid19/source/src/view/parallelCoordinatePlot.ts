//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import * as d3 from 'd3';
import { Draggable } from '../miscellaneous/Draggable.js';
import { printClass } from '../LP/printClass.js';
import { ControlParallelCoordinatePlot } from './ControlParallelCoordinatePlot.js';
import { D3ZoomEvent } from 'd3';
type typeOfValue = string | number | boolean | undefined | null  | Array<boolean> | Array<any>;

export class ParallelCoordinatePlotClass
{
  private width: number = 960;
  private height: number = 480;
  parallelCoordinatePlotName: string;

  private  LocalData: d3.DSVParsedArray<{
    Index: number;
    selectionStatus: boolean;
    Country: string;
    T: number;
    Z: number;
    ActiveCases: number;
    CasesPerMil: number;
    DeathsPerMil: number;
}>;
  //private static xAxis;
  //private static Axis;
  public parentControl: ControlParallelCoordinatePlot;
  inputWidth:number;
  inputHeight:number;

  plotWidth: number;
  plotHeight: number;
  canvasWidth:number;
  yAxis: d3.Selection<SVGGElement, unknown, null, undefined>;
  xAxis: d3.Selection<SVGGElement, unknown, null, undefined>;
  glyph:d3.SymbolType;
  innerWidth: number;
  innerHeight: number;
  xTrans:number;
  yTrans:number;
  previousX: number;
  previousY: any;
  horizontal: number;
  vertical: number;
  xPos:number;
  yPos:number;
  color: d3.ScaleLinear<string, string>;
  Data: any[];
  dims: any;
  helper: any[];
  colorIndex: number;
  parentWindow: HTMLDivElement;
  //margin: { top: number; right: number; bottom: number; left: number; };

  constructor(control: ControlParallelCoordinatePlot, data:Array<any>, name: string, xPos:number,yPos:number, 
    inputWidth:number,inputHeight:number,helper:Array<any>,color:number, dims:Array<any>)
  {
    if (printClass.printStatus) console.log("I am in constructor of ParallelCoordinatePlotClass");
    this.parallelCoordinatePlotName = name;
    this.xPos=xPos;
    this.yPos=yPos;
    this.inputWidth = inputWidth;
    this.inputHeight = inputHeight;
    this.parallelCoordinatePlotName = name;
    this.parentControl = control;
    if (printClass.printStatus) console.log("let's see");
    if (printClass.printStatus) console.log(control);
    this.Data = data;
    this.helper = helper;
    this.colorIndex = color;
    this.dims = dims;

    this.render(control);
    this.previousX =0;
    this.previousY =0;

  }
  makeDraggable()
  {
    //create instance of a Draggable class
    var D1 = new Draggable();
    var temp = this.parallelCoordinatePlotName;
    
    //check if the element that needs to be made draggable exist, else throw error        
    try
    {

      document.getElementById(this.parallelCoordinatePlotName +"header" )!
        .addEventListener('mousedown', function ()
        { D1.dragElement(document.getElementById(temp)); }, false);
    }
    catch (error)
    {
      throw Error("The Element by id " + this.parallelCoordinatePlotName + " do not exist");
    }
  }

  //************************
  // Getters and Setters
  //************************

  getTranslateX(): typeOfValue
  {
    return this.height;
  }

  getTranslateY(): typeOfValue
  {
    return this.width;
  }

  setSize(value: typeOfValue)
  {
    //console.log("set Size method of parallelCoordinatePlot");
    if (printClass.printStatus) console.log(value);
    
    var temp = value as number;
    //console.log();
    d3.select(`#${this.parallelCoordinatePlotName}`)
    .select("svg")
    .select("g")
    .selectAll("circle")
    .attr("r", temp / 10);

    if (printClass.printStatus) console.log("successfully updated the variable");
    /*  else{
         throw Error("Value not in bounds")
     } */
  }


  translateX(value: Array<any>)
  {
    var horizontal = this.horizontal+2; 
     var vertical = this.vertical+2;

    function horiz(d: { T: any; X?: any; Y?: any; Z?: any; }){
      //console.log("hh is "+ hh);
     if(horizontal ==2)
     {return d.T}
     else if(horizontal ==3)
      {return d.X;}
     else if(horizontal ==4)
      {return d.Y}
     else if(horizontal ==5)
      {return d.Z}
   
     }

     function verti(d: { T: any; X: any; Y: any; Z: any; }){
       if(vertical ==2)
       {return d.T}
       else if(vertical ==3)
        {return d.X;}
       else if(vertical ==4)
        {return d.Y}
       else if(vertical ==5)
        {return d.Z}
     
       }

    var newX = value[0];
    var xScale = value[2];

    var change =  value[0] -this.previousX ;
    var directionHorizontal;
    if(change >=0)
    {
      
      directionHorizontal = 1
    }
    else{
      
      directionHorizontal = -1
    }
       
      
        if (newX == 0 || newX == undefined)
        {
          //console.log("undefined");
        }
        else
        {
          var shift = directionHorizontal*(xScale.invert(this.previousX))-directionHorizontal*(xScale.invert(change));
          xScale.domain([xScale.domain()[0] + shift , xScale.domain()[1] + shift]);
          this.xAxis.call(d3.axisBottom(xScale));
           
          //Update the ParallelCoordinatePlot based on new zoom event
          d3.select(`#${this.parallelCoordinatePlotName}`)
            .select("svg").select('g')
            .selectAll("circle")
            .attr('cx', function (d: { T: any; }) { return xScale(horiz(d)) });
           
          this.previousX = value[0]
    
        } 
    
        

  }


  translateY(value: Array<any>)
  {

    var horizontal = this.horizontal +2; 
     var vertical = this.vertical+2;

    function horiz(d: { T: any; X: any; Y: any; Z: any; }){
      //console.log("hh is "+ hh);
     if(horizontal ==2)
     {return d.T}
     else if(horizontal ==3)
      {return d.X;}
     else if(horizontal ==4)
      {return d.Y}
     else if(horizontal ==5)
      {return d.Z}
   
     }

     function verti(d: { Z: any; T?: any; X?: any; Y?: any; }){
       if(vertical ==2)
       {return d.T}
       else if(vertical ==3)
        {return d.X;}
       else if(vertical ==4)
        {return d.Y}
       else if(vertical ==5)
        {return d.Z}
     
       }
    //console.log("translateY method of parallelCoordinatePlot");
    //console.log("Hurray" + this.parallelCoordinatePlotName);

    var change =  value[0] -this.previousY ;
    var directionVertical;
   
    if(change >=0)
    {
      //console.log("positive direction");
      directionVertical = 1
    }
    else{
      //console.log("negative direction");
      directionVertical = -1
    }
       
        var newY = value[0];
        var yScale = value[3];
    
        if (newY == 0 || newY == undefined)
        {
          //console.log("undefined");
        }
        else
        {

          var shift = directionVertical*(yScale.invert(this.previousY))-directionVertical*(yScale.invert(change));
          yScale.domain([yScale.domain()[0] + shift , yScale.domain()[1] + shift]);
          this.yAxis.call(d3.axisLeft(yScale));
            
          //Update the ParallelCoordinatePlot based on new zoom event
          d3.select(`#${this.parallelCoordinatePlotName}`)
            .select("svg").select('g')
            .selectAll("circle")
            .attr('cy', function (d: { Z: any; }) { return yScale(verti(d)) });
             
          this.previousY = value[0]
        } 

  }

  setOpacity(value: typeOfValue)
  {  
    var temp = value as number;
   
    d3.selectAll("circle").attr("fill-opacity", `${temp/100 }`);

  }



  setIndication(value: Array<any>)
  {
    
    var color = this.color;
    if (this.LocalData == undefined)
    {

    }
    else
    {
      
      d3.select(`#${this.parallelCoordinatePlotName}`).select("svg").selectAll("path")
        .data(this.LocalData)
        .attr("fill", function (d,index)
        {         
          //console.log(d.CountryOfInterest)
          return value[index] == true?color(d.Continent):"grey";
        });
    }


  }




  setSelection(value: Array<any>)
  {
    
var color = this.color;
    if (this.LocalData == undefined)
    {

    }
    else
    {
      
      d3.select(`#${this.parallelCoordinatePlotName}`).select("svg").selectAll("path")
        .data(this.LocalData)
        .attr("fill", function (d,index)
        {
          return value[index] == true? color(d.Continent):"grey";
        })
        .attr("stroke-width", function (d,index)
        {
          return value[index] == true? 3:0.2;
        })
        .attr("opacity", function (d,index)
        {
          return value[index] == true?1 : 1;
        });
    }


  }

  setZoom(value: Array<any>)
  {

   

    var horizontal = this.horizontal +2; 
     var vertical = this.vertical +2;
     var item = this.helper[0];

    

    var newX = value[0];
    var newY= value[1];

    if (newX == 0 && newY == undefined)
    {

    }
    else
    {

      this.xAxis.call(d3.axisBottom(newX));
      this.yAxis.call(d3.axisLeft(newY));

      //Update the ParallelCoordinatePlot based on new zoom event
      d3.select(`#${this.parallelCoordinatePlotName}`)
        .select("svg").select('g')
        .selectAll("circle")
        .attr('cx', function (d: { T: any; }) { return newX(item(d,horizontal)) })
        .attr('cy', function (d: { Z: any; }) { return newY(item(d,vertical)) });

    }

  }



  private render(parentControl: ControlParallelCoordinatePlot): void
  {
    var localParentControl = parentControl;

    var parentWindow = this.parentWindow;

    //create a div element to hold ParallelCoordinatePlot
    var div1: HTMLDivElement = document.createElement("div");
    div1.id = this.parallelCoordinatePlotName;
    div1.className = "parallelCoordinatePlot"
    var numberPattern = /\d+/g;
    //this.canvasWidth = 360;
    var offset = 20;
    //div1.style.left = (parseInt(this.parallelCoordinatePlotName.match(numberPattern).toString()) -1) *( this.inputWidth + offset) +offset + "px";
    //div1.style.left = Math.random()*2000 + "px";

    

    div1.style.left = this.xPos+ "px";
    div1.style.top  = this.yPos + "px";


    //create a closable icon
    var div0: HTMLButtonElement = document.createElement("button");
    div0.id = "close";
    div0.innerHTML = "X";
    div0.title = "close";
    div0.onclick = function () { div0.parentNode.parentNode.removeChild(div0.parentNode); return false; };
    //div1.appendChild(div0);


    //create a div header for the parallelCoordinatePlot
    var div2 = document.createElement("div");
    div2.id = div1.id + "header";
    div2.className = "parallelCoordinatePlotheader"
    //div2.textContent = div1.id;

    //make the div header a child to the div element
    div1.appendChild(div2);

  
    
var data = this.Data;

    
   const renderplot = (data:any) =>{

   
    var dimensions =  this.dims

   //console.log(dimensions);
   var colArray = d3.keys(data[0]).filter(function(d,index) { return d })
   
      this.LocalData = data;
      var margin = { top: 50, right: 10, bottom: 30, left: 60 };
      this.plotWidth = this.inputWidth - margin.left - margin.right;
      this.plotHeight = this.inputHeight - margin.top - margin.bottom;
      this.innerWidth = this.plotWidth + margin.left + margin.right;
      this.innerHeight =  this.plotHeight + margin.top + margin.bottom; 
      
      var yScale = {};
      var i;
      var name: string;

    //console.log("check1")

      for (i in dimensions) {
        name = dimensions[i]
       
        if ( name == "Continent")
        {
          yScale[name] = d3.scalePoint()
          .domain( data.map(function(d) {
            //console.log(d[name]);
            return d[name]; }) )
          .range([this.plotHeight, 0])
        }else{
        yScale[name] = d3.scaleLinear()
          .domain( d3.extent(data, function(d) { return d[name]; }) )
          .range([this.plotHeight, 0])
        }
        //console.log(yScale[name]);
    
      }

      //console.log("check2")
      // append the svg object to the body of the page
       var svg = d3
                .select(div1)
                .append("svg")
                .attr("width", this.innerWidth)
                .attr("height", this.innerHeight);


      //create a group element for the rest of the plot
       var axisGroup = svg
                  .attr("fill", "orange")
                  .append("g")

                  .attr("class", "axisGroupClass")
                  .attr(
                      "transform",
                      "translate(" + margin.left + "," + margin.top + ")"
                    );

    
      // Build the X scale -> it find the best position for each Y axis
      var xScale = d3.scalePoint()
      .range([0, this.plotWidth])
      .padding(0.1)
      .domain(dimensions);

      
      
      // The path function take a row of the csv as input, and return x and y coordinates of the line to draw for this raw.
      function path(d) {
        return d3.line()(dimensions.map(function(p) { return [xScale(p), yScale[p](d[p])]; }));
      }

      
      
      var colorIndex= this.colorIndex ;
      var item = this.helper[0];

      let color: any;
      if(item(data[0],colorIndex).__proto__ == String.prototype)
      {
         color = d3.scaleOrdinal(data.map((d: any) => (item(d,colorIndex))), ["#8dd3c7","#bebada", "#fb8072","#80b1d3","#ffffb3","#fdb462","#b3de69" ]).unknown(null)
      }else if(item(data[0],colorIndex).__proto__ == Number.prototype)
      {
         color = d3.scaleLinear<string>(d3.extent(data, (d) => (item(d,colorIndex))), ["red", "black"]).unknown(null)
      }

      

      this.color = color;


     

      // Draw the lines
  axisGroup
  .selectAll("myPath")
  .data(data)
  .enter().append("path")
  .attr("d",  path)
  .style("fill", "none")
  .style("stroke", function (d) { return color(item(d,colorIndex));; })
  .style("opacity", 1)

      


  // Draw the axis:
  axisGroup.selectAll("myAxis")
    // For each dimension of the dataset I add a 'g' element:
    .data(dimensions).enter()
    .append("g")
    // I translate this element to its right position on the x axis
    .attr("transform", function(d) { return "translate(" + xScale(d) + ")"; })
    // And I build the axis with the call function
    .each(function(d,index) { 
      
     return d3.select(this).call(d3.axisLeft().scale(yScale[d]))//: d3.select(this).call(d3.axisRight().scale(yScale[d]))
    
    
    })
    // Add axis title
    .append("text")
      .style("text-anchor", "center")
      .attr("y", -9)
      .text(function(d) { return d; })
      .style("fill", "black")
      .style("font-size", 13)
      .style("font-weight", 100)

           

    };

    renderplot(data);
    document.body.appendChild(div1);
    this.makeDraggable();

  }

}









