
//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

import { Draggable } from "../miscellaneous/Draggable.js";
//import { typeOfValue } from "../index.js";
import { Eventing } from "../LP/Eventing.js";
import { printClass } from "../LP/printClass.js";

//type Callback = ()=>void;
type typeOfValue = string | number | boolean | undefined | null;
export class CanvasClass 
{
    //events:{[key:string]:Callback[]} ={};

    //**********************************************************************
    // Private Class Members
    //**********************************************************************

    name: string = "canvas";
    private height: typeOfValue;
    private width: typeOfValue;
    private canvasControlName: string;
    
    //**********************************************************************
    // Constructor
    //**********************************************************************

    constructor( name: string) 
    {
                
        this.height = 400;
        this.width = 400;
        
        this.canvasControlName = name;
        this.updateUI();

        if(printClass.printStatus) console.log("rectangle object created");
        //if(printClass.printStatus) console.log(this);

    }
    

    
    //************************
    // Getters and Setters
    //************************

    getHeight(): typeOfValue
    {
        return this.height;
    }

    getWidth(): typeOfValue
    {
        return this.width;
    }



    setHeight(value: number)
    {
        
        if(printClass.printStatus) console.log("set Height method of Canvas");
        if(printClass.printStatus) console.log(value);
        //if(value>=this.min && value <=this.min){
        this.height = value;

        //**************************need to implement fire property changed method**********************************
        //this.updateUI();
        if(printClass.printStatus) console.log(this.canvasControlName);
        const IPelement = document.getElementById("myCanvas" + this.canvasControlName) as HTMLCanvasElement;
        //IPelement.height = this.height*4;

        var temp = this.height as number;
        IPelement.height =temp*4 ;
        IPelement.getContext("2d").fillRect(0,0,temp*4,temp*4);
        
        
        if(printClass.printStatus) console.log("successfully updated the variable");
        /*  else{
             throw Error("Value not in bounds")
         } */
    }


    setWidth(value: number)
    {
        
        if(printClass.printStatus) console.log("set width method of Canvas");
        if(printClass.printStatus) console.log(value);
        //if(value>=this.min && value <=this.min){
        this.width = value;

        //**************************need to implement fire property changed method**********************************
        //this.updateUI();
        if(printClass.printStatus) console.log(this.canvasControlName);
        const IPelement = document.getElementById("myCanvas" + this.canvasControlName) as HTMLCanvasElement;
        var temp = this.width as number;
        IPelement.width = temp*4;
        IPelement.getContext("2d").fillRect(0,0,temp*4,temp*4);

        

        if(printClass.printStatus) console.log("successfully updated the variable");
        /*  else{
             throw Error("Value not in bounds")
         } */
    }

    getName()
    {
        return this.name;
    }

    setName(name: string)
    {

        this.name = name;

    }

    //******************
    //public Methods
    //*****************

    updateUI()
    {



        //create a div element to hold slider
        var div1: HTMLDivElement = document.createElement("div");
        div1.id =  this.canvasControlName;
        div1.className = "canvas"
        var numberPattern = /\d+/g;
        div1.style.left = (parseInt(this.canvasControlName.match(numberPattern).toString())-1)*400 + "px"; 
        //div1.style.left = Math.random()*2000 + "px";

        //create a closable icon
        var div0:HTMLButtonElement = document.createElement("button");
        div0.id = "close";
        div0.innerHTML = "X";
        div0.title = "close";
        div0.onclick = function(){div0.parentNode.parentNode.removeChild(div0.parentNode); return false;};
        div1.appendChild(div0);


        //create a div header for the slider
        var div2 = document.createElement("div");
        div2.id = div1.id + "header";
        div2.className = "canvasheader"
        div2.textContent = div1.id;

        //make the div element a child to the header
        div1.appendChild(div2);

        //Add additional information to the control and append it
        var h = document.createElement("h2");
        //h.textContent = "Rectangle size based on the slider";
        div1.appendChild(h);

        //if(printClass.printStatus)     console.log(this.canvasControlName);
        //create a slider inside the div element and make it a child
        var canvas_ = document.createElement('canvas');
        canvas_.id = "myCanvas" + this.canvasControlName;
        canvas_.height = 400;
        canvas_.width = 400;
        canvas_.getContext("2d").fillStyle = "green";
        canvas_.getContext("2d").fillRect(0,0,canvas_.height,canvas_.width);



        div1.appendChild(canvas_);

        //add the div element to the document body
        document.body.appendChild(div1);


        //call the make draggable function
        this.makeDraggable();
       

        
        return this;


    }

    getSUpport(){
        if(printClass.printStatus) console.log("support Recieved");
    }

    makeDraggable()
    {
        //create instance of a Draggable class
        var D1 = new Draggable();
        var temp = this.canvasControlName;
        
        //check if the element that needs to be made draggable exist, else throw error        
        try
        {

             document.getElementById( this.canvasControlName + "header")!
                .addEventListener('mousedown', function()
                {D1.dragElement(document.getElementById( temp));}, false);
        }
        catch (error)
        {
            throw Error("The Element by id " + this.canvasControlName + " do not exist");
        }
    }


 




}

