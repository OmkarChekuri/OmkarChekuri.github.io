//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.


import * as d3 from 'd3';
import { Draggable } from '../miscellaneous/Draggable.js';
import { printClass } from '../LP/printClass.js';
import { ControlScatterplot } from '../control/ControlScatterplot.js';
import { D3ZoomEvent } from 'd3';
type typeOfValue = string | number | boolean | undefined | null | Array<boolean> | Array<any>;

export class ScatterplotClass
{

  private width: number = 960;
  private height: number = 480;
  scatterplotControlName: string;

  private LocalData: d3.DSVParsedArray<{}>;
  //private static xAxis;
  //private static Axis;
  public parentControl: ControlScatterplot;
  inputWidth: number;
  inputHeight: number;

  //plotWidth: number;
  //plotHeight: number;
  canvasWidth: number;
  yAxis: d3.Selection<SVGGElement, unknown, null, undefined>;
  xAxis: d3.Selection<SVGGElement, unknown, null, undefined>;
  glyph: d3.SymbolType;
  innerWidth: number;
  innerHeight: number;
  xTrans: number;
  yTrans: number;
  previousX: number;
  previousY: any;
  horizontal: number;
  vertical: number;
  xPos: number;
  yPos: number;
  showHoriz: boolean = true;
  showVerti: boolean = true;
  yScale: d3.ScaleLinear<number, number>;
  xScale: d3.ScaleLinear<number, number>;
  Data:Array<any>;
  scatter: d3.Selection<SVGGElement, unknown, null, undefined>;
  helper: any[];
  colorIndex: number;
  circleSizeIndex: number;
  textIndex: number;
  color: d3.ScaleOrdinal<string, unknown>;
  plotHeight: any;
  plotWidth: any;
  

  constructor( control: ControlScatterplot,data:Array<any>, name: string, xPos: number, yPos: number, 
    horizontalAxisIndex: number, verticalAxisIndex: number, inputWidth: number, inputHeight: number,
    showHoriz: boolean, showVerti: boolean, helper:Array<any>,color:number,size:number,text:number)
  {
    if (printClass.printStatus) console.log("I am in constructor of ScatterplotClass");
    this.scatterplotControlName = name;
    this.horizontal = horizontalAxisIndex;
    this.vertical = verticalAxisIndex;
    this.inputWidth = inputWidth;
    this.inputHeight = inputHeight;
    this.scatterplotControlName = name;
    this.colorIndex = color;
    this.circleSizeIndex = size;
    this.textIndex = text;
    




    this.parentControl = control;
    if (printClass.printStatus) console.log("let's see");
    if (printClass.printStatus) console.log(control);

    this.previousX = 0;
    this.previousY = 0;
    this.xPos = xPos;
    this.yPos = yPos;
    this.showHoriz = showHoriz;
    this.showVerti = showVerti;
    this.Data = data;
    this.helper = helper;
    this.render(control);

  }
  makeDraggable()
  {
    //create instance of a Draggable class
    var D1 = new Draggable();
    var temp = this.scatterplotControlName;
         
    try
    {

     

      document.getElementById(this.scatterplotControlName + "header")!
        .addEventListener('mousedown', function ()
        { D1.dragElement(document.getElementById(temp)); }, false);
    }
    catch (error)
    {
      throw Error("The Element by id " + this.scatterplotControlName + " do not exist");
    }
  }

  //************************
  // Getters and Setters
  //************************

  getTranslateX(): typeOfValue
  {
    return this.height;
  }

  getTranslateY(): typeOfValue
  {
    return this.width;
  }

  setSize(value: typeOfValue)
  {
    if (printClass.printStatus) console.log(value);
    var temp = value as number;
    d3.select(`#${this.scatterplotControlName}`)
      .select("svg")
      .select("g")
      .selectAll("circle")
      .attr("r", temp / 10);

    if (printClass.printStatus) console.log("successfully updated the variable");
    /*  else{
         throw Error("Value not in bounds")
     } */
  }


  translateX(value: Array<any>)
  {
    var horizontal = this.horizontal ;
    var newX = value[0];
    var item = value[2];
    var xScale = this.xScale;

    var change = value[0] - this.previousX;
    var directionHorizontal = change>=0?-1:1;

    if (newX == 0 || newX == undefined){
      //console.log("undefined");
    }else{
      var shift = directionHorizontal * (xScale.invert(this.previousX)) - directionHorizontal * (xScale.invert(change));
      xScale.domain([xScale.domain()[0] + shift, xScale.domain()[1] + shift]);
      this.xAxis.call(d3.axisBottom(xScale));

      //Update the scatterplot based on new zoom event
      d3.select(`#${this.scatterplotControlName}`)
        .select("svg").select('g')
        .selectAll("circle")
        .attr('cx', function (d: { T: any; }) { return xScale(item(d,horizontal)) });

        this.previousX = value[0]
    }
    //updating the class variable again
    this.xScale = xScale;
  }


  translateY(value: Array<any>)
  {

    var vertical = this.vertical;
    var change = value[0] - this.previousY;
    var item = value[2];
    var directionVertical = change >= 0?1:-1;        // 1 = +ve direction, -1 = -ve direction

    var newY = value[0];
    //extracting the yscale
    var yScale = this.yScale;

    if (newY == 0 || newY == undefined){
      //console.log("undefined");
    }else{

      var shift = directionVertical * (yScale.invert(this.previousY)) - directionVertical * (yScale.invert(change));
      yScale.domain([yScale.domain()[0] + shift, yScale.domain()[1] + shift]);
      this.yAxis.call(d3.axisLeft(yScale));

      //Update the scatterplot based on new zoom event
      d3.select(`#${this.scatterplotControlName}`)
        .select("svg").select('g')
        .selectAll("circle")
        .attr('cy', function (d: { Z: any; }) { return yScale(item(d,vertical)) });

      this.previousY = value[0]
    }
    //updating the class variable again
    this.yScale = yScale;
  }

  setOpacity(value: typeOfValue)
  {
    var temp = value as number;
    d3.selectAll("circle").attr("fill-opacity", `${temp / 100}`);
  }

  setSelection(value: Array<any>)
  {

      
    if (this.LocalData == undefined){}
    else
    {
      d3.select(`#${this.scatterplotControlName}`).select("svg").selectAll("circle")
        .data(this.LocalData)
        //.attr("fill", function (d,index) { return value[index] == true ? "black" : null;})
        .attr("stroke", function (d,index) { return value[index] == true ? "black" : "black";})
        .attr("stroke-width", function (d,index) { return value[index] == true ? 3 : 0.1;});
    }
  }

  setIndication(value: Array<any>)
  {

    var colorIndex= this.colorIndex ;
     
    var item = this.helper[0];
    var color = this.color;
  
    
    if (this.LocalData == undefined){    }
    else
    {      
      d3.select(`#${this.scatterplotControlName}`).select("svg").selectAll("circle")
        .data(this.LocalData)
        .style("fill", function (d,index)
        { return value[index] == true?"black": color(item(d,colorIndex));; })
       

        this.scatter
        .selectAll("text")
        .attr("font-size", function (d,index)
        { return value[index] == true?15:null; })
        .attr("font-weight", "bold" )

        


    }
  } 


  setBrushY(arg0: any[])
  {
      throw new Error("Method not implemented.");
  }
  setBrushX(arg0: any[])
  {
      throw new Error("Method not implemented.");
  }
  setyRange(yRange: Array<number>)
  {
    var vertical = this.vertical;
    var item = this.helper[0];
    var plotHeight = this.plotHeight;
    if(yRange[0]== null){

    }
    else{
    //console.log(yRange)  
    var yScale = this.yScale;
    var Domain = [yRange[0],yRange[1]]
   
    yScale.domain(Domain)
        //.domain(d3.extent(data, function (d){ return `d.${colArray[horizontal]}`; }))
        .range([plotHeight, 0])
        
    

    this.yScale = yScale;  

        this.yAxis.call(d3.axisLeft(yScale));

        this.scatter
        .selectAll("circle")
        .attr('cy', function (d: { Z: any; }) {
          if(item(d,vertical)>yRange[0] &&  item(d,vertical)<yRange[1])
            {
            return yScale(item(d,vertical)) 
            }else{
              return -plotHeight;
            }
        })
        
        
        
        ;

    }
      
  }
  setxRange(xRange: Array<number>)
  {
    var horizontal = this.horizontal;
    var item = this.helper[0];
    var plotWidth = this.plotWidth;
    var plotHeight = this.plotHeight;
    
    if(xRange[0]== null){}
    else{
      //console.log(xRange)  
      var xScale = this.xScale;
      var Domain = [xRange[0],xRange[1]];
      xScale.domain(Domain)
            .range([0, plotWidth])
            
   
      this.xScale = xScale;  
      this.xAxis.call(d3.axisBottom(xScale))
      .selectAll("text")  
        .style("text-anchor", "end")
        .attr("dx", "-.8em")
        .attr("dy", ".15em")
        .attr("transform", "rotate(-45)");
      //Update the scatterplot based on new zoom event


      this.axisGroup
          .selectAll("circle")
          .attr('cx', function (d: { T: any; }) { 
            
            if(item(d,horizontal)>xRange[0] &&  item(d,horizontal)<xRange[1])
            {
            return xScale(item(d,horizontal)) 
            }else{
              return -plotWidth;
            }
          });



      
    }
  }
  setZoom(arg0: any[])
  {
      throw new Error("Method not implemented.");
  }
  setHoverSelection(arg0: string | number | boolean | boolean[])
  {
      throw new Error("Method not implemented.");
  }

  

  private render(parentControl: ControlScatterplot): void
  {

    var div0 = document.createElement("div");
    div0.className = "covid19";
    div0.id = "covid19"
   

    
    var localParentControl = parentControl;
    var div1: HTMLDivElement = document.createElement("div");
    div1.id = this.scatterplotControlName;
    div1.className = "scatterplot"

    console.log(document.getElementsByClassName("content"));
       
    div1.style.left =  this.xPos + "px";
    div1.style.top = this.yPos + "px";

    div0.appendChild(div1)
    
    //create a div header for the scatterplot
    var div2 = document.createElement("div");
    div2.id = div1.id + "header";
    div2.className = "scatterplotheader";
    //div2.textContent = div1.id;

    //make the div header a child to the div element
    div1.appendChild(div2);

 
    var data = this.Data;

    const renderPlot = (data:any ) =>
    {
      //console.log(data);
      var IndicationArray = new Array(data.length);
           IndicationArray.fill(false,0);

           var SelectionArray = new Array(data.length);
           SelectionArray.fill(false,0);

      var colArray = Object.keys(data[0]);
      //console.log("ScatterPlot Render Method");
      //console.log(colArray);

      var horizontal = this.horizontal ;
      var vertical = this.vertical ;
      var colorIndex= this.colorIndex ;
      var circleSizeIndex = this.circleSizeIndex ;
      var textIndex =  this.textIndex ;

     

      var item = this.helper[0];
      //console.log(item);
      
      function Label(index:number){  return  colArray[index] + "→"; }
    
      

      this.LocalData = data;
      var margin = { top: 20, right: 15, bottom: 60, left: 60 };
      var plotWidth = this.inputWidth - margin.left - margin.right;
      var plotHeight = this.inputHeight - margin.top - margin.bottom;
      this.innerWidth = plotWidth + margin.left + margin.right;
      this.innerHeight = plotHeight + margin.top + margin.bottom;
      this.plotWidth = plotWidth;
      this.plotHeight = plotHeight;


      // append the svg object to the body of the page
      var svg = d3
        .select(div1)
        .append("svg")
        //.attr("fill", )
        .attr("width", this.innerWidth)
        .attr("height", this.innerHeight);



      //create a group element for the rest of the plot
      var axisGroup = svg

        .append("g")
        .attr("class", "axisGroupClass")
        .attr(
          "transform",
          "translate(" + margin.left + "," + margin.top + ")"
        );

        var labelsGroup = svg
          //.attr("fill", "orange")
          .append("g")
          .attr("class", "labelGroupClass")
          .attr(
            "transform",
            "translate(" + margin.left + "," + margin.top + ")"
          );

      //create a linear xScale
      var xScale = d3
        .scaleLinear()
        .domain(d3.extent(data, function (d){return  item(d,horizontal); }))
        //.domain(d3.extent(data, function (d){ return `d.${colArray[horizontal]}`; }))
        .range([0, plotWidth])
        .nice();


      this.xScale = xScale;  

      this.xAxis = axisGroup
        .append("g")
        .attr("transform", "translate(0," + plotHeight + ")")
        

      if (this.showHoriz)
      {
        //append the xAxis to group 
        
        this.xAxis.call(d3.axisBottom(xScale))
        .selectAll("text")  
        .style("text-anchor", "end")
        .attr("dx", "-.8em")
        .attr("dy", ".15em")
        .attr("transform", "rotate(-45)");
        
        labelsGroup
          .append("text")
          .text(Label(horizontal))
          //.attr("fill", "black")
          .attr("text-anchor", "middle")
          .style("font-size", 15)
          .style("font-weight", 1000)
          .attr(
            "transform",
            `translate(${plotWidth * 0.5}, ${
            plotHeight + margin.top + margin.bottom/2
            }) rotate(0)`
          );
      }



      //create a linear yScale
      var yScale = d3.scaleLinear()
        .domain(d3.extent(data, function (d){ return item(d,vertical);}))
        .range([plotHeight, 0])
        //.nice();

      this.yScale = yScale;  

      this.yAxis = axisGroup.append("g")
      
      
      if (this.showVerti)
      {
        //append the yAxis to group
        this.yAxis.call(d3.axisLeft(yScale));

        labelsGroup
          .append("text")
          .text(Label(vertical))
          //.attr("fill", "black")
          .attr("text-anchor", "middle")
          .style("font-size", 15)
          .style("font-weight", 1000)
          .attr(
            "transform",
            `translate(${-margin.left /1.3}, ${
            plotHeight * 0.5
            }) rotate(-90)`
          );



      }


      
      let color: any;
      if(item(data[0],colorIndex).__proto__ == String.prototype)
      {
         color = d3.scaleOrdinal(data.map((d: any) => (item(d,colorIndex))), ["#8dd3c7","#bebada", "#fb8072","#80b1d3","#ffffb3","#fdb462","#b3de69" ]).unknown(null)
      }else if(item(data[0],colorIndex).__proto__ == Number.prototype)
      {
         color = d3.scaleLinear<string>(d3.extent(data, (d) => (item(d,colorIndex))), ["red", "black"]).unknown(null)
      }
      

      this.color = color;

     
      
      if (circleSizeIndex == null)
      {
        
          //var circleSize = d3.scaleLinear().range([2]);   
         var circleSize= function circleSize(d:any){
            return 2;
          }

      }
      else{
        var circleSize = d3.scaleLinear().domain(d3.extent(data, (d) => item(d,circleSizeIndex))).range([5, 10]);
      }


      // Add a clipPath: everything out of this area won't be drawn.
      var clip = axisGroup.append("defs").append("SVG:clipPath")
        .attr("id", `"${this.scatterplotControlName}clip"`)
        .append("SVG:rect")
        .attr("width", plotWidth)
        .attr("height", plotHeight)
        .attr("x", 0)
        .attr("y", 0);



      // Create the scatter variable: where both the circles and the brush take place
      this.scatter = axisGroup.append('g')
               .attr("clip-path", `"url(#${this.scatterplotControlName}clip)"`)
     
      const t = axisGroup.transition().duration(750);

      this.scatter
        .selectAll("circle")
        .data(data)
        .attr("class", "cir")
        .join(
          enter => enter.append("circle")
            .attr("fill", function(d) { return color(item(d,colorIndex)); })
            .attr("stroke","black")
            .attr("cx", function (d) { return xScale(item(d,horizontal)); })
            .attr("cy", function (d) { return yScale(item(d,vertical)); })
            .attr("r", 0)
            .style("opacity", 0.8)
            .call(enter => enter.transition(t)
              .attr("r", d => circleSize(item(d,circleSizeIndex))))
            .append('title')
              .text(d => item(d,textIndex)),
          update => update
            .attr("fill", "black")
            .style("opacity", 1)
            .attr("stroke","black")
            .attr("r",  d => 2),

          exit => exit
            .attr("fill", "brown")
            .call(exit => exit.transition(t)
              .attr("r", 0)
              .remove())
        )

        this.scatter
        .append("g")
        .attr("font-family", "sans-serif")
        .attr("font-size", 0)
        .selectAll("text")
        .data(data)
        .join("text")
        .attr("dy", "0.35em")
        .attr("x", function (d) { return xScale(item(d,horizontal)) +7; })
        .attr("y", function (d) { return yScale(item(d,vertical)); })
        .text(d => item(d,textIndex))

        this.scatter
        .selectAll("circle")
        .append('title')
        .attr("pointer-events", "none")
        .text(function(d, i)
                {
                   //console.log(d);
                   var info  = "";
                   for (var key in data[i])
                   {
                     info  = info +  key + " = " + data[i][key] + "\n";
                     
                   }
                   return info ; })
        
        .on("mouseover", onMouseOver) //Add listener for the mouseover event
        .on("mouseout", onMouseOut);

        svg.on("mouseout", function(){
          d3.select("rect").attr("fill-opacity",0);
        })


      //mouseover event handler function
      function onMouseOver(d: any)
      {
        console.log("mouseover");
        // this keyword refers to the mouseover item
        var circle = d3.select(this);
        var textOffseteHeight = 12;
        circle
          .raise()
          .transition() // adds animation
          .duration(100)
          .attr("stroke", "black")
          .attr("stroke-width", 1)
          .style("opacity", 1)
          .attr("r", textOffseteHeight / 1.5);

        d3.select(this)
          .append("text")
          .attr("text-anchor", "middle")
          .attr('class', 'val')
          .style("fill", "black")
          .attr('x', () => (d3.event.pageX))
          .attr('y', () => (d3.event.pageY))
          .style("font-size", 15)
          .style("font-weight", 1000)
          .text(() => item(d,textIndex));
      }

      function onMouseOut(data: any, i: any)
      {
        d3.select(this)
          .transition() // adds animation
          .duration(100)
          .attr("r", 2.5)
          .attr("stroke", null)
          .attr("stroke-width", 2)
          .style("opacity", 0.7);

        d3.selectAll(".val").remove();
      }

      

      // Set the zoom and Pan features: how much you can zoom, on which part, and what to do when there is a zoom
      var zoom = d3.zoom()
        .scaleExtent([.5, 20])  // This control how much you can unzoom (x0.5) and zoom (x20)
        .extent([[0, 0], [plotWidth, plotHeight]])
        .on("zoom", updateChart);

      //This add an invisible rect on top of the chart area. This rect can recover pointer events: necessary to understand when the user zoom
      var zoomRect = axisGroup.append("rect")
        .attr("cursor", "move")
        .attr("pointer-events", "all")
        .attr("width", plotWidth)
        .attr("height", plotHeight)
        .style("fill", "white")
        .style("opacity", 0.1)
        .call(zoom);

      

      // A function that updates the chart when the user zoom and thus new boundaries are available
      function updateChart()
      {
        // recover the new scale
        var xTranslate = d3.event.transform.x;
        var yTranslate = d3.event.transform.y;
        const scale = d3.event.transform.k;
        //console.log(d3.event.transform.x);
        var newX = d3.event.transform.rescaleX(xScale);
        var newY = d3.event.transform.rescaleY(yScale);

        
        //console.log(Math.abs(xTranslate));
        const w = 660 - margin.left - margin.right;


        localParentControl.getProxy().getLiveProperty("xTranslate").setValue([xTranslate]);
        localParentControl.getProxy().getLiveProperty("yTranslate").setValue([yTranslate]);
       

      }


      var myArrayTable: any[] = [];

      //brushed over the scatterplot       
      function brushed()
      {

        this.querySelector(".selection").setAttribute("fill-opacity",0.3);
        myArrayTable = [];
        const selection = d3.event.selection;

        if (selection === null)
        {
          d3.selectAll("circle").data(data).attr("stroke", null);
        } else
        {
          //console.log( x0 + " " + x1 + " " + y0 +  " " + y1);
          const [[x0, y0], [x1, y1]] = selection;
          d3.selectAll("circle")
            .data(data)
            .attr("stroke", (d,index) =>
            {
              if (
                x0 <= xScale(item(d,horizontal)) &&
                xScale(item(d,horizontal)) <= x1 &&
                y0 <= yScale(item(d,vertical)) &&
                yScale(item(d,vertical)) <= y1
              )
              {
                // console.log(index);
                SelectionArray[index] = true;
  
                return "null";
              } else
              {
                SelectionArray[index] = false;
                return null;
              }
            })

        }

        //create an array of all the selection statuses of the data
        if (printClass.printStatus) console.log("In scatterplot");
        if (printClass.printStatus) console.log(localParentControl);
        //localParentControl.getProxy().getLiveProperty("Data").setValue(data);
        localParentControl.getProxy().getLiveProperty("Selection").setValue(SelectionArray);

      }



      var brush = d3
        .brush()
        .extent([
          [-margin.left / 2, -margin.top / 2],
          [plotWidth + margin.right / 2, plotHeight + margin.bottom / 2],
        ])
        .on(" start brush  ", brushed)
        .on("end", function(){
          this.querySelector(".selection").setAttribute("fill-opacity", "0.2" ); 
        });

      // Add the brushing
      axisGroup.append("g").call(brush);
    };


    renderPlot(data);
    document.body.appendChild(div1);

    this.makeDraggable(); 

  }

}
































