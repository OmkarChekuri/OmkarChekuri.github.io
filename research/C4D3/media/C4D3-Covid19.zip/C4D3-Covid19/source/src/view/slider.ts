//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

//inspired from Jslider class
import { Draggable } from "../miscellaneous/Draggable.js";
//import { typeOfValue } from "../index.js";
import { Eventing } from "../LP/Eventing.js";
import { printClass } from "../LP/printClass.js";
type typeOfValue = string | number | boolean | undefined | null;


//type Callback = ()=>void;

export class SliderClass  extends Eventing
{
    //events:{[key:string]:Callback[]} ={};

    //**********************************************************************
    // Private Class Members
    //**********************************************************************

    name: string = "slider";
    private max: number;
    private min: number;
    private value: typeOfValue;
    private sliderControlName: string;
    //private firstStart:boolean = true;
    xPos:number;
    yPos:number;

    //**********************************************************************
    // Constructor
    //**********************************************************************

    constructor( name: string,xPos:number,yPos:number) 
    {
        super();
        
        //this.tag = tag;
        this.min = 0;
        this.max = 100;
        this.value = 50;
        this.xPos = xPos;
        this.yPos = yPos;

        this.sliderControlName = name;
        this.updateUI();

        if(printClass.printStatus) console.log("slider object created");
        //if(printClass.printStatus) console.log(this);

    }
    

    
    //************************
    // Getters and Setters
    //************************

    getMin(): number
    {
        return this.min;
    }

    getMax(): number
    {
        return this.max;
    }

    getValue(): typeOfValue
    {
        return this.value;
    }

    setValue(value: typeOfValue)
    {
        
        if(printClass.printStatus) console.log("setValue method of Slider");
        //if(value>=this.min && value <=this.min){
        this.value = value;

        //**************************need to implement fire property changed method**********************************
        //this.updateUI();
        if(printClass.printStatus) console.log(this.sliderControlName);
        const IPelement = document.getElementById("myRange" + this.sliderControlName) as HTMLInputElement;
        IPelement.value = this.value as string;
        

        if(printClass.printStatus) console.log("successfully updated the variable");
        /*  else{
             throw Error("Value noot in bounds")
         } */
    }

    getName()
    {
        return this.name;
    }

    setName(name: string)
    {

        this.name = name; 

    }

    //******************
    //public Methods
    //*****************

    updateUI()
    {



        //create a div element to hold slider
        var div1: HTMLDivElement = document.createElement("div");
        div1.id =  this.sliderControlName;
        div1.className = "slider"
        var numberPattern = /\d+/g;
        //div1.style.left = (parseInt(this.sliderControlName.match(numberPattern).toString())-1)*375 +20 + "px"; 
        //div1.style.left = Math.random()*1500 + "px"; 

        div1.style.left =   this.xPos + "px";
        div1.style.top =    this.yPos + "px";

        //create a closable icon
        var div0:HTMLButtonElement = document.createElement("button");
        div0.id = "close";
        div0.innerHTML = "X";
        div0.title = "close";
        div0.onclick = function(){div0.parentNode.parentNode.removeChild(div0.parentNode); return false;};
        div1.appendChild(div0);


        //create a div header for the slider
        var div2 = document.createElement("div");
        div2.id = div1.id + "header";
        div2.className = "sliderheader"
        div2.textContent = div1.id;

        //make the div element a child to the header
        div1.appendChild(div2);

        //Add additional information to the control and append it
        var h = document.createElement("h2");
        //h.textContent = "Font size based on the slider";
        div1.appendChild(h);

        if(printClass.printStatus) console.log(this.sliderControlName);
        //create a slider inside the div element and make it a child
        var slider = document.createElement('input');
        slider.id = "myRange" + this.sliderControlName;
        //console.log(slider.id);
        slider.type = 'range';
        slider.min = "0";
        slider.max = "100";
        //slider.width = 150 +"px";
        slider.value = "this.current";
        slider.step = "1";

        div1.appendChild(slider);

        //add the div element to the document body
        document.body.appendChild(div1);


        //call the make draggable function
        this.makeDraggable();
        //this.attachEventListener(slider.id);
        //if(printClass.printStatus) console.log(this.value);

        //this.firstStart = false;
        return this;


    }



    makeDraggable()
    {
        //create instance of a Draggable class
        var D1 = new Draggable();
        var temp = this.sliderControlName;
       
        //check if the element that needs to be made draggable exist, else throw error        
        try
        {

               document.getElementById( this.sliderControlName + "header")!
                .addEventListener('mousedown', function()
                {D1.dragElement(document.getElementById( temp));}, false);
        }
        catch (error)
        {
            throw Error("The Element by id " + this.sliderControlName + " do not exist");
        }
    }


 




}

