//   C4D3 is free software: you can redistribute it and/or modify it under
// the terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option) any
// later version.

// This file is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.

// You should have received a copy of the GNU Affero General Public License
// along with this program. If not, see <http://www.gnu.org/licenses/>.

//inspired from Jslider class
import { Draggable } from "../miscellaneous/Draggable.js";
//import { typeOfValue } from "../index.js";
import { printClass } from "../LP/printClass.js";

type Callback = ()=>void;
type typeOfValue = string | number | boolean | undefined | null;
export  class PixelClass 
{

   
    events:{[key:string]:Callback[]} ={};

   
    name:string = "pixel";
    private pixelvalue:typeOfValue;
    private pixelControlName:string;
    //static control:ControlPixel;

  //**********************************************************************
    // Constructor
    //**********************************************************************
    constructor(name: string ) 
    {
        

        //PixelClass.control = control;
        this.pixelvalue = 0;
  
        this.pixelControlName = name;
        this.updateUI();

        if(printClass.printStatus) console.log("Third:" +this.name +" object created");
        //if(printClass.printStatus) console.log(this);
        

    }

    
    getValue(): typeOfValue
    {
        return this.pixelvalue;
    }

    setValue(value: typeOfValue)
    {
        //if(value>=this.min && value <=this.min){
        this.pixelvalue = value;

        //**************************need to implement fire property changed method**********************************
        //this.updateUI();
        const element = document.getElementById("myValue" + this.pixelControlName) as HTMLInputElement;
        element.value = this.pixelvalue as string;

        if(printClass.printStatus) console.log("successfully updated the variable");

        return;

        /*  else{
             throw Error("Value not in bounds")
         } */
    }

    getName()
    {
        return this.name;
    }

    set setName(name: string)
    {

        this.name = name;

    }

    updateUI()
    {
 
            
            var div1  = document.createElement("div");
            div1.id =  this.pixelControlName;
            div1.className = "fontvalue"
            var numberPattern = /\d+/g;
            div1.style.left = parseInt(this.pixelControlName.match(numberPattern).toString())*200 + "px"; 
            //console.log(this.pixelControlName.match(numberPattern));


            //create a closable icon
            var div0:HTMLButtonElement = document.createElement("button");
            div0.id = "close";
            div0.title = "close";
            div0.innerHTML = "X";
            div0.onclick = function(){div0.parentNode.parentNode.removeChild(div0.parentNode); return false;};
            div1.appendChild(div0);


            var div2 = document.createElement("div");
            div2.id= div1.id + "header";
            div2.className = "fontvalueheader"
            div2.textContent = div1.id;

            div1.appendChild(div2);

            
            var h = document.createElement("h2");
            h.textContent = "Font size in Pixels";

            div1.appendChild(h);

            if(printClass.printStatus) console.log(this.name);
            var fontControl = document.createElement('input');
            fontControl.id = "myValue" + this.pixelControlName;
            fontControl.type = 'number';
            fontControl.min = "0";
            fontControl.max = "100";
            fontControl.value = "50";
            
            //document.body.appendChild(fontControl); 

            div1.appendChild(fontControl);
            document.body.appendChild(div1);
            this.makeDraggable();

            return this;
           

    }

    makeDraggable()
    {
        var D1 = new Draggable();
        //var D1 = new Draggable();
        var temp = this.pixelControlName;

        try {
            document.getElementById( this.pixelControlName + "header")!
            .addEventListener('mousedown', function(){D1.dragElement(document.getElementById( temp));}, false);
        } catch (error) {
            throw Error("The Element by id " + this.pixelControlName + " do not exist");
        }
        
    }

 


}











